import asyncio
import logging
import os
import sys
import time
import signal
from pyrogram import Client, idle
from pyrogram.errors import AuthKeyUnregistered, SessionRevoked, SessionExpired, UserDeactivated

# 🔥 Config & Plugins Imports
from config import API_ID, API_HASH, BOT_TOKEN
try:
    from config import ZARA_CLIENTS 
except ImportError:
    ZARA_CLIENTS = [] 

try:
    from config import hacker_font
except ImportError:
    def hacker_font(text): return f"\033[1;36m{text}\033[0m"

from core.database import get_all_sessions, remove_session, db

# 🛑 YAHAN TERA AUTO-KILL SCANNER IMPORT HO RAHA HAI
try:
    from startup_scan import run_startup_scan
except ImportError:
    run_startup_scan = None
    print("\033[1;41m[!] CRITICAL WARNING: startup_scan.py missing! Auto-Kill Shield is OFFLINE.\033[0m")

# ==========================================
# 🛑 SMART KERNEL LOGGING & ERROR SILENCER
# ==========================================
logging.basicConfig(
    level=logging.WARNING,
    format="[%(asctime)s] ⚡ %(levelname)s: %(message)s",
    datefmt="%H:%M:%S"
)
logging.getLogger("pyrogram").setLevel(logging.ERROR)
logging.getLogger("pyrogram.session.session").setLevel(logging.CRITICAL) 

def async_exception_handler(loop, context):
    msg = str(context.get("exception", context["message"]))
    if any(x in msg for x in ["Peer id invalid", "ID not found", "Connection closed"]):
        return 
    loop.default_exception_handler(context)

# ==========================================
# ⚡ THE ZARA CLIENT (Optimized for 100+ Nodes)
# ==========================================
class ZaraUserBot(Client):
    def __init__(self, user_id, session_string, manager_bot=None):
        super().__init__(
            name=f"ub_{user_id}",
            api_id=API_ID,
            api_hash=API_HASH,
            session_string=session_string,
            plugins=dict(root="plugins"),
            in_memory=True,
            max_concurrent_transmissions=2, 
            workers=2 
        )
        self.user_id = user_id
        self.manager = manager_bot
        self.db = db

    async def start(self):
        try:
            await super().start()
            print(f"\033[1;32m[+] ɴᴏᴅᴇ ꜱᴇᴄᴜʀᴇᴅ\033[0m ⇛ {self.me.first_name[:15]} \033[1;36m[UID: {self.user_id}]\033[0m")
            return True
        except (AuthKeyUnregistered, SessionRevoked, SessionExpired, UserDeactivated):
            print(f"\033[1;31m[-] ᴅᴇᴀᴅ ɴᴏᴅᴇ ᴩᴜʀɢᴇᴅ\033[0m ⇛ \033[1;35m[UID: {self.user_id}]\033[0m Wiping from Matrix...")
            await remove_session(self.user_id)
            return False
        except Exception as e:
            print(f"\033[1;33m[!] ᴄᴏɴɴᴇᴄᴛɪᴏɴ ꜰᴀɪʟᴇᴅ\033[0m ⇛ [UID: {self.user_id}] Retrying later.")
            return False

# ==========================================
# 🛡️ THE ZARA MANAGER (Supreme Commander)
# ==========================================
class ZaraManagerBot(Client):
    def __init__(self):
        super().__init__(
            name="ZARA_MANAGER",
            api_id=API_ID,
            api_hash=API_HASH,
            bot_token=BOT_TOKEN,
            plugins=dict(root="manager_plugins"),
            in_memory=True
        )
        self.db = db 

    async def start(self):
        await super().start()
        print(f"\033[1;35m[👑] ꜱᴜᴩʀᴇᴍᴇ ᴄᴏᴍᴍᴀɴᴅᴇʀ ᴏɴʟɪɴᴇ\033[0m ⇛ @{self.me.username} ⚡")
        return self

# ==========================================
# 🛰️ SWARM HEARTBEAT MONITOR (ADVANCED)
# ==========================================
KERNEL_START_TIME = time.time()

async def swarm_monitor():
    await asyncio.sleep(5) 
    while True:
        alive_nodes = len(ZARA_CLIENTS)
        uptime_sec = int(time.time() - KERNEL_START_TIME)
        h, rem = divmod(uptime_sec, 3600)
        m, s = divmod(rem, 60)
        uptime_str = f"{h:02d}h {m:02d}m {s:02d}s"
        
        print(f"\n\033[1;36m📡 [ ᴢᴀʀᴀ ʀᴀᴅᴀʀ ᴩɪɴɢ ]\033[0m")
        print(f" ⇛ \033[1;32mꜱᴛᴀᴛᴜꜱ:\033[0m ꜱᴇᴄᴜʀᴇ & ᴀᴄᴛɪᴠᴇ")
        print(f" ⇛ \033[1;33mʟɪᴠᴇ ɴᴏᴅᴇꜱ:\033[0m [ {alive_nodes} ]")
        print(f" ⇛ \033[1;35mꜱʏꜱᴛᴇᴍ ᴜᴩᴛɪᴍᴇ:\033[0m {uptime_str}")
        print("\033[1;30m ⇛ ᴀᴡᴀɪᴛɪɴɢ ɴᴇᴡ ᴛᴀʀɢᴇᴛꜱ...\033[0m")
        
        await asyncio.sleep(600) # Har 10 minute me ping karega

# ==========================================
# 🏁 KERNEL INITIALIZATION (God-Mode Bootloader)
# ==========================================
async def start_zara_system():
    loop = asyncio.get_event_loop()
    loop.set_exception_handler(async_exception_handler)

    os.system('cls' if os.name == 'nt' else 'clear')
    
    # 🔥 CYBERPUNK TERMINAL BANNER 🔥
    print("\033[1;31m")
    print("""
    ███████╗ █████╗ ██████╗ ███████╗
    ╚══███╔╝██╔══██╗██╔══██╗██╔════╝
      ███╔╝ ███████║██████╔╝███████╗
     ███╔╝  ██╔══██║██╔══██╗██╔════╝
    ███████╗██║  ██║██║  ██║██║     
    ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     
    """)
    print("\033[0m\033[1;36m ⇛ ꜱʏꜱᴛᴇᴍ ᴀᴡᴀᴋᴇɴᴇᴅ \033[1;31m|\033[1;36m ʙʏᴩᴀꜱꜱɪɴɢ ᴛᴇʟᴇɢʀᴀᴍ ᴍᴀɪɴꜰʀᴀᴍᴇ... \033[0m\n")
    
    await asyncio.sleep(1) # Fake hacker delay for visual effect

    global ZARA_CLIENTS
    ZARA_CLIENTS.clear() 

    # 1. Start Manager Instantly
    MANAGER_BOT = ZaraManagerBot()
    try:
        await MANAGER_BOT.start()
    except Exception as e:
        print(f"\033[1;41m[ FATAL ERROR ]\033[0m Manager failed to boot! Check Bot Token.\nError: {e}")
        sys.exit(1)

    # 2. Extract Sessions from Database
    try:
        sessions = await get_all_sessions()
        total_sessions = len(sessions)
    except Exception as e:
        print(f"\033[1;31m[ CRITICAL ] Database Load Failed!\033[0m {e}")
        sessions = []
        total_sessions = 0

    print(f"\033[1;33m🔋 ᴅᴀᴛᴀʙᴀꜱᴇ ꜱʏɴᴄᴇᴅ: {total_sessions} ᴅᴏʀᴍᴀɴᴛ ɴᴏᴅᴇꜱ ꜰᴏᴜɴᴅ.\033[0m")
    print("\033[1;30m ⇛ ɪɴɪᴛɪᴀᴛɪɴɢ ʙᴏᴏᴛ ꜱᴇQᴜᴇɴᴄᴇ...\033[0m\n")

    # 3. 🔥 BATCH DEPLOYMENT (Anti-DDoS Shield Active)
    batch_size = 5  
    
    async def boot_node(session_data):
        uid = session_data.get("user_id")
        string = session_data.get("session_string")
        if string:
            ub = ZaraUserBot(uid, string, manager_bot=MANAGER_BOT)
            if await ub.start():
                ZARA_CLIENTS.append(ub) 
                
    for i in range(0, total_sessions, batch_size):
        batch = sessions[i : i + batch_size]
        tasks = [asyncio.create_task(boot_node(session)) for session in batch]
        await asyncio.gather(*tasks)
        
        if i + batch_size < total_sessions:
            print(f"\033[1;30m[ ⏳ ᴄᴏᴏʟɪɴɢ ᴅᴏᴡɴ... ᴀɴᴛɪ-ꜱᴩᴀᴍ ʙʏᴩᴀꜱꜱ ᴀᴄᴛɪᴠᴇ ] ({len(ZARA_CLIENTS)}/{total_sessions})\033[0m")
            await asyncio.sleep(2.5) 

    print(f"\n\033[1;32m🚀 ꜱQᴜᴀᴅ ᴅᴇᴩʟᴏʏᴍᴇɴᴛ ᴄᴏᴍᴩʟᴇᴛᴇ! [ {len(ZARA_CLIENTS)} ] ɴᴏᴅᴇꜱ ᴀʀᴇ ꜰᴜʟʟʏ ᴡᴇᴀᴩᴏɴɪᴢᴇᴅ.\033[0m\n")

    # 4. 🔥 THE STARTUP SCANNER (Kills leavers instantly on boot) 🔥
    if run_startup_scan:
        try:
            await run_startup_scan(MANAGER_BOT)
        except Exception as e:
            print(f"\033[1;31m[!] Scanner Error: {e}\033[0m")

    # 5. Start Heartbeat Monitor
    asyncio.create_task(swarm_monitor())

    # 6. Keep System Alive
    await idle()

    # 7. Graceful Teardown
    print("\033[1;31m\n💀 ᴛᴇᴀʀɪɴɢ ᴅᴏᴡɴ ᴛʜᴇ ᴍᴀᴛʀɪx...\033[0m")
    try: await MANAGER_BOT.stop()
    except: pass
    
    for c in ZARA_CLIENTS:
        try: await c.stop()
        except: pass
    print("\033[1;31m🩸 ꜱʏꜱᴛᴇᴍ ᴏꜰꜰʟɪɴᴇ. ꜱᴇᴇ ʏᴏᴜ ɪɴ ᴛʜᴇ ꜱʜᴀᴅᴏᴡꜱ.\033[0m")

# ==========================================
# 🛑 GRACEFUL SHUTDOWN (Ctrl+C Override)
# ==========================================
def force_stop_handler(signum, frame):
    print("\033[1;41m\n🩸 ᴇᴍᴇʀɢᴇɴᴄʏ ᴋɪʟʟ-ꜱᴡɪᴛᴄʜ ᴀᴄᴛɪᴠᴀᴛᴇᴅ. ᴄʟᴏꜱɪɴɢ ᴀʟʟ ᴄᴏɴɴᴇᴄᴛɪᴏɴꜱ...\033[0m")
    os._exit(0) 

signal.signal(signal.SIGINT, force_stop_handler)

if __name__ == "__main__":
    if not os.path.exists("plugins"): os.makedirs("plugins")
    if not os.path.exists("manager_plugins"): os.makedirs("manager_plugins")

    try:
        asyncio.run(start_zara_system())
    except KeyboardInterrupt:
        pass

