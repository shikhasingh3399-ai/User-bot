import asyncio
import dns.resolver
from motor.motor_asyncio import AsyncIOMotorClient
from config import MONGO_URI, DB_NAME, LOGS, hacker_font


# ====================================================================
# 🧠 𝐙𝐀𝐑𝐀 𝐒𝐘𝐒𝐓𝐄𝐌: 𝐍𝐄𝐔𝐑𝐀𝐋 𝐌𝐄𝐌𝐎𝐑𝐘 (𝐀𝐃𝐕𝐀𝐍𝐂𝐄𝐃 𝐃𝐁 𝐂𝐎𝐑𝐄)
# ====================================================================

# 🔥 TERMUX DNS FIX (BULLETPROOF)
# Agar network slow bhi hua to ye bypass kar dega
try:
    dns.resolver.default_resolver = dns.resolver.Resolver(configure=False)
    dns.resolver.default_resolver.nameservers = ['8.8.8.8', '1.1.1.1'] # Google + Cloudflare (Super Fast)
except Exception as e:
    LOGS.warning(f"DNS Fix Skipped: {e}")

# ==========================================
# 🔌 SAFE CONNECTION MANAGER
# ==========================================
try:
    # serverSelectionTimeoutMS lagaya hai taaki DB atakne par bot na atke
    cli = AsyncIOMotorClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    db = cli[DB_NAME]
    
    # Collections (Folders)
    sessions = db["sessions"]
    filters = db["filters"]
    gbans = db["gbans"]
    sudoers = db["auth_users"]
except Exception as e:
    print(f"❌ FATAL DB ERROR: {e}")
    exit(1) # Agar DB hi connect nahi hui to bot aage nahi badhega

# ==========================================
# 🛠️ HELPER FUNCTIONS (WITH ANTI-CRASH SHIELD)
# ==========================================

async def get_all_sessions():
    """Start hone par saare bots ki session list layega safely"""
    try:
        return await sessions.find({}).to_list(length=None)
    except Exception as e:
        LOGS.error(f"DB Fetch Error (Sessions): {e}")
        return [] # Crash hone ke bajay empty list dega

async def add_session(user_id: int, session_string: str):
    """Naya userbot add karne ke liye (Upsert)"""
    try:
        await sessions.update_one(
            {"user_id": user_id},
            {"$set": {"session_string": session_string}},
            upsert=True
        )
        return True
    except Exception as e:
        LOGS.error(f"DB Add Error: {e}")
        return False

async def remove_session(user_id: int):
    """Agar session expire ho jaye to silently delete karega"""
    try:
        await sessions.delete_one({"user_id": user_id})
        return True
    except Exception:
        return False

# ==========================================
# 🛑 GBAN LOGIC (ZARA BLACKLIST)
# ==========================================

async def is_gbanned(user_id: int):
    """Fast GBAN Check (Every message passes through this)"""
    try:
        found = await gbans.find_one({"user_id": user_id})
        return bool(found)
    except Exception:
        return False # Error me kisi ko randomly ban nahi manega

async def add_gban(user_id: int, reason: str = "ZARA KERNEL PROTOCOL"):
    """Target ko DB me zinda gaad do"""
    try:
        await gbans.update_one(
            {"user_id": user_id},
            {"$set": {"reason": reason}},
            upsert=True
        )
        return True
    except Exception:
        return False

async def remove_gban(user_id: int):
    """Target ko azaad karo"""
    try:
        await gbans.delete_one({"user_id": user_id})
        return True
    except Exception:
        return False

