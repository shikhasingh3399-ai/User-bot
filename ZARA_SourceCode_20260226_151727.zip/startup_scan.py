import asyncio
from pyrogram.errors import UserNotParticipant, FloodWait
from pyrogram.enums import ChatMemberStatus
from config import ZARA_CLIENTS
from core.database import remove_session

async def run_startup_scan(manager_bot):
    # 🔥 ᴛᴇʀɪ ᴅᴏɴᴏ ɢᴄ ɪᴅꜱ ꜱᴇᴛ ʜᴏ ɢᴀʏɪ ʜᴀɪɴ
    MUST_JOIN_CHATS = [-1003544870055, -1002688178004] 
    dead_count = 0
    
    # Terminal me hacker font dikhega
    print("\033[1;33m[ ᴢᴀʀᴀ ʀᴀᴅᴀʀ ] ɪɴɪᴛɪᴀᴛɪɴɢ ʜᴀʀᴅᴄᴏʀᴇ ʟᴇᴀᴠᴇʀ ꜱᴄᴀɴ...\033[0m")
    
    # ZARA_CLIENTS ki copy li hai taaki memory crash na ho
    for bot in ZARA_CLIENTS.copy():
        user_id = getattr(bot, "user_id", None)
        if not user_id: 
            continue
        
        kicked = False
        for chat_id in MUST_JOIN_CHATS:
            try:
                member = await manager_bot.get_chat_member(chat_id, user_id)
                # Agar user left kar chuka hai, ya ban/kick hua hai
                if member.status in [ChatMemberStatus.LEFT, ChatMemberStatus.KICKED, ChatMemberStatus.BANNED]:
                    kicked = True
            except UserNotParticipant:
                # Agar group me hai hi nahi
                kicked = True
            except FloodWait as e:
                # Telegram limit lagaye to bot aaram karega
                await asyncio.sleep(e.value + 2) 
            except Exception:
                pass
            
            if kicked:
                break # Ek bhi GC me nahi hai, to seedha terminate
                
        if kicked:
            # 1. 🔥 INSTANT DEVICE LOGOUT (ASLI HACK) 🔥
            try: 
                # Ab ye sidha Telegram server se session udayega!
                await bot.log_out()
            except Exception: 
                pass
            
            try: 
                ZARA_CLIENTS.remove(bot)
            except: 
                pass
            
            # 2. ᴅᴀᴛᴀʙᴀꜱᴇ ᴇʀᴀꜱᴇ (ᴩᴇʀᴍᴀɴᴇɴᴛ ᴅᴇʟᴇᴛᴇ)
            await remove_session(user_id)
            dead_count += 1
            
            # 3. ꜱɪɢᴍᴀ ᴡᴀʀɴɪɴɢ ɪɴ ꜱᴍᴀʟʟ ᴄᴀᴩꜱ (Inbox me jayegi)
            warning_msg = (
                "💀 **[ ꜱʏꜱᴛᴇᴍ ᴏᴠᴇʀʀɪᴅᴇ : ꜱᴇꜱꜱɪᴏɴ ᴀᴜᴛᴏ-ᴋɪʟʟᴇᴅ ]** 💀\n\n"
                "ʙᴇᴛᴇ, ᴛᴜᴊʜᴇ ʟᴀɢᴀ ᴛᴜ ɢʀᴏᴜᴩ ʟᴇꜰᴛ ᴋᴀʀᴋᴇ **ᴢᴀʀᴀ ᴍᴀᴛʀɪx** ᴋᴏ ʙʏᴩᴀꜱꜱ ᴋᴀʀ ʟᴇɢᴀ? 😂\n"
                "ᴛᴇʀɪ ᴄʜᴀʟᴀᴀᴋɪ ᴩᴀᴋᴅɪ ɢᴀʏɪ ʜᴀɪ.\n\n"
                "🩸 **ᴀᴄᴛɪᴏɴ ᴛᴀᴋᴇɴ ʙʏ ᴋᴇʀɴᴇʟ:**\n"
                "⇛ ᴛᴇʀᴀ ꜱᴇꜱꜱɪᴏɴ ᴛᴇʀᴇ ᴅᴇᴠɪᴄᴇ ꜱᴇ **ʟᴏɢᴏᴜᴛ** ᴍᴀᴀʀ ᴅɪʏᴀ ɢᴀʏᴀ ʜᴀɪ.\n"
                "⇛ ᴛᴇʀᴀ ᴅᴀᴛᴀ ᴅᴀᴛᴀʙᴀꜱᴇ ꜱᴇ ᴩᴇʀᴍᴀɴᴇɴᴛʟʏ ᴇʀᴀꜱᴇ ʜᴏ ᴄʜᴜᴋᴀ ʜᴀɪ.\n\n"
                "ᴀɢʟɪ ʙᴀᴀʀ ꜱʏꜱᴛᴇᴍ ꜱᴇ xᴇʟɴᴇ ꜱᴇ ᴩᴇʜʟᴇ ᴀᴩɴɪ ᴏᴜᴋᴀᴀᴛ ᴅᴇx ʟᴇɴᴀ. **ɢᴀᴍᴇ ᴏᴠᴇʀ!** 🍷"
            )
            try:
                await manager_bot.send_message(user_id, warning_msg)
            except:
                pass
            
            # Terminal pe live update
            print(f"\033[1;31m[ ᴋɪʟʟ ] ɴᴏᴅᴇ {user_id} ʟᴏɢɢᴇᴅ ᴏᴜᴛ ᴀɴᴅ ᴇʀᴀᴅɪᴄᴀᴛᴇᴅ!\033[0m")
            await asyncio.sleep(1) # Har kill ke baad thoda delay taaki server ban na de
                
    print(f"\033[1;32m[ ꜱᴄᴀɴ ᴄᴏᴍᴩʟᴇᴛᴇ ] {dead_count} ʟᴇᴀᴠᴇʀꜱ ʟᴏɢɢᴇᴅ ᴏᴜᴛ ᴀɴᴅ ᴇʀᴀꜱᴇᴅ!\033[0m")

