import asyncio
from pyrogram import Client, filters
from pyrogram.errors import FloodWait, UserAdminInvalid, ChatAdminRequired
from pyrogram.types import Message
from config import OWNER_ID # Teri config se Owner ID lega

# ==========================================
# ☢️ MANAGER BOT: ULTRA-FAST NUKE PROTOCOL
# ==========================================

# Speed Controller (Ek sath kitne logo ko ban marna hai)
# Ise zyada badhana mat warna Telegram bot block kar dega
CONCURRENCY_LIMIT = 15 
sem = asyncio.Semaphore(CONCURRENCY_LIMIT)

async def fast_ban(client, chat_id, user_id):
    """Ye function background me bina ruke ban marega"""
    async with sem:
        try:
            await client.ban_chat_member(chat_id, user_id)
            return "success"
        except FloodWait as e:
            await asyncio.sleep(e.value + 1) # Limit aayi toh ruk jayega
            return "flood"
        except Exception:
            return "failed"

# 🔥 YAHAN TERE DOST KI ID ADD HO GAYI HAI 🔥
@Client.on_message(filters.command("chbanall", prefixes=["/", ".", "!"]) & filters.user([OWNER_ID, 8273113571]))
async def manager_nuke_channel(client: Client, message: Message):
    chat_id = message.chat.id
    
    if message.chat.type in ["private"]:
        return await message.reply("⚠️ **ᴇʀʀᴏʀ:** ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ ᴡᴏʀᴋꜱ ɪɴ ᴄʜᴀɴɴᴇʟꜱ/ɢʀᴏᴜᴩꜱ.")

    status_msg = await message.reply("☢️ `[ ᴍᴀɴᴀɢᴇʀ ᴏᴠᴇʀʀɪᴅᴇ: ɪɴɪᴛɪᴀᴛɪɴɢ ᴜʟᴛʀᴀ-ꜰᴀꜱᴛ ᴇxᴛᴇʀᴍɪɴᴀᴛɪᴏɴ... ]`")

    banned_count = 0
    failed_count = 0
    tasks = []

    try:
        await status_msg.edit("☢️ `[ ʟᴏᴄᴋɪɴɢ ᴛᴀʀɢᴇᴛꜱ... ᴩʀᴇᴩᴀʀɪɴɢ 40ᴋ+ ᴍᴀꜱꜱ ʙᴀɴ ]`")
        
        # Channel/Group se members nikalna
        async for member in client.get_chat_members(chat_id):
            user = member.user
            
            # Khud ko aur admins ko bypass karega
            if user.id == client.me.id or member.status in ["creator", "administrator"]:
                continue
            
            # Ban task ko list me add kar raha hai (background me chalane ke liye)
            task = asyncio.create_task(fast_ban(client, chat_id, user.id))
            tasks.append(task)
            
            # Har 100 targets ke baad execute karega taki RAM crash na ho
            if len(tasks) >= 100:
                results = await asyncio.gather(*tasks)
                
                for res in results:
                    if res == "success": banned_count += 1
                    elif res == "failed": failed_count += 1
                
                tasks = [] # List clear for next batch
                
                # Live update on terminal/chat
                try:
                    await status_msg.edit(f"💀 **ɴᴜᴋᴇ ɪɴ ᴩʀᴏɢʀᴇꜱꜱ (ᴍᴀx ꜱᴩᴇᴇᴅ)...**\n━━━━━━━━━━━━━━━\n🩸 ʙᴀɴɴᴇᴅ: `{banned_count}`\n❌ ꜰᴀɪʟᴇᴅ/ᴀᴅᴍɪɴꜱ: `{failed_count}`")
                except: pass

        # Baki bache hue members ko bhi uda dega
        if tasks:
            results = await asyncio.gather(*tasks)
            for res in results:
                if res == "success": banned_count += 1
                elif res == "failed": failed_count += 1

        final_report = (
            f"☢️ **ᴄʜᴀɴɴᴇʟ ᴇʀᴀᴅɪᴄᴀᴛᴇᴅ (ᴍᴀɴᴀɢᴇʀ ᴍᴏᴅᴇ)** ☢️\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 ᴛᴀʀɢᴇᴛ: `{message.chat.title}`\n"
            f"🩸 ᴛᴏᴛᴀʟ ʙᴀɴɴᴇᴅ: `{banned_count}`\n"
            f"❌ ꜱᴋɪᴩᴩᴇᴅ: `{failed_count}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"💀 `[ ᴏᴩᴇʀᴀᴛɪᴏɴ ᴄᴏᴍᴩʟᴇᴛᴇ ]`"
        )
        await status_msg.edit(final_report)

    except ChatAdminRequired:
        await status_msg.edit("🤬 **ᴏᴜᴋᴀᴀᴛ ᴍᴇ ʀᴇʜ!** ᴍᴀɴᴀɢᴇʀ ʙᴏᴛ ɴᴇᴇᴅꜱ ᴀᴅᴍɪɴ ʀɪɢʜᴛꜱ (ʙᴀɴ ᴜꜱᴇʀꜱ) ʜᴇʀᴇ.")
    except Exception as e:
        await status_msg.edit(f"❌ **ꜱʏꜱᴛᴇᴍ ᴄʀᴀꜱʜ:** {str(e)}")

