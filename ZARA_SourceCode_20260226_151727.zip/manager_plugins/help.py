import time
import random
import asyncio
import unicodedata
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery

# 🛠️ CONFIG IMPORT
try:
    from config import OWNER_ID
except ImportError:
    print("❌ CRITICAL: 'config.py' or 'OWNER_ID' not found!")
    exit(1)

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

# ==========================================
# ⏳ SYSTEM METRICS
# ==========================================
START_TIME = time.time()

def get_uptime():
    seconds = int(time.time() - START_TIME)
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    if days > 0: return f"{days}d {hours}h {minutes}m"
    elif hours > 0: return f"{hours}h {minutes}m"
    else: return f"{minutes}m {seconds}s"

def make_bar(percent):
    done = int(percent / 10)
    return "█" * done + "░" * (10 - done)

# ==========================================
# 🏁 DASHBOARD GENERATOR (DYNAMIC UI)
# ==========================================
def get_dashboard_text(user, ping_ms):
    # 🔥 FAKE DYNAMIC RESOURCES (Looks 100% Real)
    cpu = round(random.uniform(15.2, 89.7), 1)
    ram = round(random.uniform(35.5, 92.3), 1)
        
    uptime = get_uptime()
    time_now = datetime.now().strftime('%H:%M:%S')
    user_link = f"[{user.first_name}](tg://user?id={user.id})"
    
    # 🔥 REMOVED DOUBLE "ACCESS GRANTED"
    txt = f"              `⏳ {time_now}`\n\n"
    txt += f"     ╭── ⚡ **{sm('ZARA SYSTEM')}**\n"
    txt += f"**{sm('CONTROLLER')}**\n"
    txt += f"     │\n"
    txt += f"     ├── 👤 **{sm('MASTER IDENTITY')}**\n"
    txt += f"     │    ├── **{sm('USER')}**: {user_link}\n"
    txt += f"     │    ╰── **{sm('UID')}**: `{user.id}`\n"
    txt += f"     │\n"
    txt += f"     ├── ⚙️ **{sm('SYSTEM DIAGNOSTICS')}**\n"
    txt += f"     │    ├── **{sm('STATUS')}**: **ONLINE** 🟢\n"
    txt += f"     │    ├── **{sm('UPTIME')}**: `{uptime}`\n"
    txt += f"     │    ├── **{sm('LATENCY')}**: `{ping_ms} ms`\n"
    txt += f"     │    ╰── **{sm('SERVER')}**: `Termux-Android`\n"
    txt += f"     │\n"
    txt += f"     ├── 📊 **{sm('RESOURCE UTILIZATION')}**\n"
    txt += f"     │    ├── **{sm('CPU')}**: `{make_bar(cpu)}` {cpu}%\n"
    txt += f"     │    ╰── **{sm('RAM')}**: `{make_bar(ram)}` {ram}%\n"
    txt += f"     │\n"
    txt += f"     ╰── 🛡 **{sm('SECURITY LEVEL')}**:\n"
    txt += f"          **{sm('MAXIMUM (ROOT)')}**\n\n"
    txt += f"💎 **{sm('POWERED BY REFLEX x ZARA')}**"
    
    return txt

# ==========================================
# 🎮 BUTTONS
# ==========================================
def get_buttons():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(f"☢ {sm('OVERRIDE')} ☢", callback_data="magic_alert"),
            InlineKeyboardButton(f"📂 {sm('PROTOCOLS')}", callback_data="help_menu")
        ],
        [
            InlineKeyboardButton(f"🏢 {sm('DATABASE 1')}", url="https://t.me/BMW_USERBOT_II"),
            InlineKeyboardButton(f"🏢 {sm('DATABASE 2')}", url="https://t.me/REFLXHACKING")
        ],
        [InlineKeyboardButton(f"👑 {sm('SYSTEM OWNER')} 👑", user_id=OWNER_ID)]
    ])

# ==========================================
# 🚀 START COMMAND (REAL PING & ANIMATION)
# ==========================================
@Client.on_message(filters.command("start", prefixes=["!", "/"]))
async def start_zara(client, message: Message):
    start_t = time.time()
    msg = await message.reply(f"⚡ **{sm('INITIALIZING ZARA KERNEL...')}**")
    end_t = time.time()
    ping_ms = round((end_t - start_t) * 1000, 2)
    
    animation_steps = [
        f"📡 **{sm('SCANNING USER BIOMETRICS...')}**\n`UID: {message.from_user.id}`",
        f"🔄 **{sm('ESTABLISHING SECURE UPLINK...')}**\n`[████░░░░░░] 45%`",
        f"🔓 **{sm('BYPASSING MAINFRAME FIREWALL...')}**\n`[████████░░] 89%`",
        f"💀 **{sm('ACCESS GRANTED: SYSTEM ACTIVE')}**\n`[██████████] 100%`"
    ]
    
    for step in animation_steps:
        await asyncio.sleep(0.3) 
        try: await msg.edit(step)
        except: pass
    
    await asyncio.sleep(0.4)
    try: await msg.delete()
    except: pass

    txt = get_dashboard_text(message.from_user, ping_ms)
    btns = get_buttons()

    try:
        db_attr = getattr(client, 'db', None)
        data = None
        if db_attr is not None:
            data = await db_attr.zara_settings.find_one({"_id": "START_MSG"})

        if data and data.get("type"):
            m_type = data["type"]
            fid = data["file_id"]
            
            if m_type == "photo": await message.reply_photo(fid, caption=txt, reply_markup=btns)
            elif m_type == "video": await message.reply_video(fid, caption=txt, reply_markup=btns)
            elif m_type == "animation": await message.reply_animation(fid, caption=txt, reply_markup=btns)
            elif m_type == "sticker": await message.reply_sticker(fid, reply_markup=btns)
            else: await message.reply(txt, reply_markup=btns)
        else:
            await message.reply(txt, reply_markup=btns, disable_web_page_preview=True)

    except Exception as e:
        print(f"Start Delivery Error: {e}")
        await message.reply(txt, reply_markup=btns, disable_web_page_preview=True)

# ==========================================
# 🖼️ SET START MEDIA (HARDCODED ID ONLY)
# ==========================================
@Client.on_message(filters.command("setstart", prefixes=["!", "/"]) & filters.user(8036881129))
async def set_start_pic(client, message: Message):
    reply = message.reply_to_message
    if not reply:
        return await message.reply(f"❌ **{sm('Reply to a Photo/Video/GIF')}**")
    
    data = {"_id": "START_MSG", "type": "text"}
    
    if reply.photo: data.update({"type": "photo", "file_id": reply.photo.file_id})
    elif reply.video: data.update({"type": "video", "file_id": reply.video.file_id})
    elif reply.animation: data.update({"type": "animation", "file_id": reply.animation.file_id})
    elif reply.sticker: data.update({"type": "sticker", "file_id": reply.sticker.file_id})
    else: return await message.reply(f"❌ **{sm('Invalid Media Type')}**")
    
    try:
        db_attr = getattr(client, 'db', None)
        if db_attr is None:
            return await message.reply(f"❌ **{sm('Database connection not found in client!')}**")
            
        await db_attr.zara_settings.update_one({"_id": "START_MSG"}, {"$set": data}, upsert=True)
        await message.reply(f"✅ **{sm('Start Media Updated Successfully!')}**")
    except Exception as e:
        await message.reply(f"❌ **DB Error:** `{e}`")

# ==========================================
# 🗑️ RESET START (HARDCODED ID ONLY)
# ==========================================
@Client.on_message(filters.command("resetstart", prefixes=["!", "/"]) & filters.user(8036881129))
async def reset_start_pic(client, message: Message):
    try:
        db_attr = getattr(client, 'db', None)
        if db_attr is None:
            return await message.reply(f"❌ **{sm('Database connection not found in client!')}**")
            
        await db_attr.zara_settings.delete_one({"_id": "START_MSG"})
        await message.reply(f"🔄 **{sm('Reset to Default Text Terminal')}**")
    except Exception as e:
        await message.reply(f"❌ **DB Error:** `{e}`")

# ==========================================
# 🪄 CALLBACKS (MENU NAVIGATION)
# ==========================================
@Client.on_callback_query(filters.regex("magic_alert"))
async def magic_callback(client, callback: CallbackQuery):
    await callback.answer(sm("security alert: unauthorized access detected!"), show_alert=True)

@Client.on_callback_query(filters.regex("help_menu"))
async def help_menu(client, callback: CallbackQuery):
    help_txt = (
        f"💀 **{sm('TERMINAL COMMANDS')}**\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🔹 **!add** : {sm('Deploy New Userbot')}\n"
        f"🔹 **!clone** : {sm('Inject Session String')}\n"
        f"🔹 **!remove** : {sm('Kill Userbot Node')}\n"
        f"🔹 **!users** : {sm('List Active Bots')}\n"
        f"🔹 **!setstart** : {sm('Set Boot Media')} (Root Only)\n"
        f"🔹 **!resetstart** : {sm('Reset Boot Media')} (Root Only)\n"
    )
    back_btn = InlineKeyboardMarkup([[InlineKeyboardButton(f"🔙 {sm('BACK TO CORE')}", callback_data="back_home")]])
    
    try:
        if callback.message.media:
            await callback.message.edit_caption(caption=help_txt, reply_markup=back_btn)
        else:
            await callback.message.edit_text(text=help_txt, reply_markup=back_btn)
    except: pass

@Client.on_callback_query(filters.regex("back_home"))
async def back_home(client, callback: CallbackQuery):
    txt = get_dashboard_text(callback.from_user, ping_ms="--")
    btns = get_buttons()
    try:
        if callback.message.media:
            await callback.message.edit_caption(caption=txt, reply_markup=btns)
        else:
            await callback.message.edit_text(text=txt, reply_markup=btns, disable_web_page_preview=True)
    except: pass

