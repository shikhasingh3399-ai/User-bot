from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🛑 ZARA KERNEL: TARGET ID EXTRACTOR 🛑
# ==========================================

@Client.on_message(filters.command(["id", "getid"], prefixes=["/", ".", "!"]) | filters.forwarded)
async def extract_target_id(client: Client, message: Message):
    
    # 🔥 HACK 1: FORWARDED MESSAGE SCANNER (For Private & Public Groups)
    if message.forward_from_chat:
        chat_id = message.forward_from_chat.id
        chat_title = message.forward_from_chat.title or "Unknown Chat"
        
        response = (
            "💀 **[ ᴛᴀʀɢᴇᴛ ɪᴅ ᴇxᴛʀᴀᴄᴛᴇᴅ ᴠɪᴀ ꜰᴏʀᴡᴀʀᴅ ]** 💀\n\n"
            f"⇛ **ɴᴀᴍᴇ:** {chat_title}\n"
            f"⇛ **ɪᴅ:** `{chat_id}`\n\n"
            "🍷 *ᴛᴀʀɢᴇᴛ ʟᴏᴄᴋᴇᴅ. ʀᴇᴀᴅʏ ꜰᴏʀ ᴅᴇᴩʟᴏʏᴍᴇɴᴛ.*"
        )
        return await message.reply_text(response)

    # 🔥 HACK 2: DIRECT LINK/USERNAME SCANNER
    if message.text and len(message.command) > 1:
        target = message.command[1]
        
        # Link ko clean karna
        if "t.me/" in target:
            target = target.split("t.me/")[1]
            # Private invite links block karna
            if target.startswith("+") or target.startswith("joinchat"):
                err_msg = (
                    "⚠️ **[ ᴇʀʀᴏʀ : ᴩʀɪᴠᴀᴛᴇ ʟɪɴᴋ ᴅᴇᴛᴇᴄᴛᴇᴅ ]**\n\n"
                    "ᴩʀɪᴠᴀᴛᴇ ɢʀᴏᴜᴩ ᴋɪ ɪᴅ ᴀɪꜱᴇ ɴᴀʜɪ ɴɪᴋᴀʟᴛɪ ᴍᴇʀɪ ᴊᴀᴀɴ!\n"
                    "👉 **ʜᴀᴄᴋ:** *ᴜꜱ ɢʀᴏᴜᴩ ꜱᴇ ᴋᴏɪ ʙʜɪ ᴇᴋ ᴍᴇꜱꜱᴀɢᴇ ᴍᴜᴊʜᴇ ꜰᴏʀᴡᴀʀᴅ ᴋᴀʀ, ᴍᴀɪɴ xᴜꜰɪʏᴀ ᴛᴀʀɪᴋᴇ ꜱᴇ ɪᴅ ɴɪᴋᴀʟ ʟᴜɴɢᴀ!*"
                )
                return await message.reply_text(err_msg)
                
        target = target.replace("@", "")
        
        processing_msg = await message.reply_text("📡 **[ ꜱᴄᴀɴɴɪɴɢ ᴛᴇʟᴇɢʀᴀᴍ ᴍᴀɪɴꜰʀᴀᴍᴇ... ]**")
        
        try:
            chat = await client.get_chat(target)
            chat_name = chat.title or chat.first_name or "Unknown"
            
            response = (
                "💀 **[ ᴛᴀʀɢᴇᴛ ɪᴅ ᴇxᴛʀᴀᴄᴛᴇᴅ ]** 💀\n\n"
                f"⇛ **ɴᴀᴍᴇ:** {chat_name}\n"
                f"⇛ **ɪᴅ:** `{chat.id}`\n\n"
                "🍷 *ᴛᴀʀɢᴇᴛ ʟᴏᴄᴋᴇᴅ. ʀᴇᴀᴅʏ ꜰᴏʀ ᴅᴇᴩʟᴏʏᴍᴇɴᴛ.*"
            )
            await processing_msg.edit_text(response)
            
        except Exception as e:
            await processing_msg.edit_text(f"❌ **[ ꜱᴄᴀɴ ꜰᴀɪʟᴇᴅ ]**\n`{e}`")
            
    elif message.text and message.text.startswith(("/", ".", "!")):
        await message.reply_text("⚠️ **[ ɪɴᴠᴀʟɪᴅ ꜱʏɴᴛᴀx ]**\n👉 ᴜꜱᴇ: `/ɪᴅ @ᴜꜱᴇʀɴᴀᴍᴇ` ʏᴀ `/ɪᴅ ʟɪɴᴋ` ʏᴀ ᴋᴏɪ ᴍᴇꜱꜱᴀɢᴇ ꜰᴏʀᴡᴀʀᴅ ᴋᴀʀ!")

