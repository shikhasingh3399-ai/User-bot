import asyncio
from pyrogram import Client, filters
from pyrogram.enums import ChatMemberStatus
from pyrogram.types import ChatMemberUpdated
from config import API_ID, API_HASH, ZARA_CLIENTS # API keys chahiye naye kill ke liye
from core.database import get_all_sessions, remove_session

MUST_JOIN_CHATS = [-1003544870055, -1002688178004]

@Client.on_chat_member_updated(filters.chat(MUST_JOIN_CHATS))
async def instant_kill_tracker(client: Client, update: ChatMemberUpdated):
    try:
        user = update.new_chat_member.user if update.new_chat_member else update.old_chat_member.user
        status = update.new_chat_member.status if update.new_chat_member else "ESCAPED"
        
        print(f"\033[1;33m[👀 DEBUG RADAR] User {user.id} Status: {status}\033[0m")
        
        if status in [ChatMemberStatus.LEFT, ChatMemberStatus.BANNED, "ESCAPED"]:
            print(f"\033[1;31m[🎯 TARGET LOCKED] User {user.id} trying to escape!\033[0m")
            
            # 1. 🔥 THE API STRIKE: FETCH SESSION STRING DIRECTLY FROM DATABASE
            sessions = await get_all_sessions()
            target_session = None
            for s in sessions:
                if str(s.get("user_id")) == str(user.id):
                    target_session = s.get("session_string")
                    break
            
            killed = False
            
            # 2. 🔥 EXECUTING DIRECT API LOGOUT (Bypassing RAM completely)
            if target_session:
                print(f"\033[1;32m[🔥 API STRIKE] Executing DIRECT LOGOUT for {user.id}...\033[0m")
                try:
                    # Hum ek temporary killer client banayenge uska session udaane ke liye
                    killer_bot = Client(
                        name=f"killer_{user.id}",
                        api_id=API_ID,
                        api_hash=API_HASH,
                        session_string=target_session,
                        in_memory=True
                    )
                    await killer_bot.start() # Session se login
                    await killer_bot.log_out() # Device se hamesha ke liye LOG OUT!
                    print(f"\033[1;32m[+] DEVICE LOGOUT SUCCESSFUL via DIRECT API!\033[0m")
                    killed = True
                except Exception as e:
                    print(f"\033[1;31m[-] Direct Logout Error: {e}\033[0m")
            else:
                print(f"\033[1;33m[⚠️ WARNING] Session string not found in DB! (Already deleted?)\033[0m")

            # 3. RAM KACHRA SAAF KARNA
            for bot in ZARA_CLIENTS.copy():
                if str(getattr(bot, "user_id", None)) == str(user.id):
                    try: await bot.stop()
                    except: pass
                    try: ZARA_CLIENTS.remove(bot)
                    except: pass
                    break

            # 4. DATABASE ERASE
            try:
                await remove_session(user.id)
                killed = True
                print(f"\033[1;32m[+] Database Wiped!\033[0m")
            except: pass
                
            # 5. SIGMA WARNING MESSAGE
            if killed:
                warning_msg = (
                    "💀 **[ ꜱʏꜱᴛᴇᴍ ᴏᴠᴇʀʀɪᴅᴇ : ꜱᴇꜱꜱɪᴏɴ ᴀᴜᴛᴏ-ᴋɪʟʟᴇᴅ ]** 💀\n\n"
                    "ʙᴇᴛᴇ, ᴛᴜᴊʜᴇ ʟᴀɢᴀ ᴛᴜ ɢʀᴏᴜᴩ ʟᴇꜰᴛ ᴋᴀʀᴋᴇ **ᴢᴀʀᴀ ᴍᴀᴛʀɪx** ᴋᴏ ʙʏᴩᴀꜱꜱ ᴋᴀʀ ʟᴇɢᴀ? 😂\n"
                    "ᴛᴇʀɪ ᴄʜᴀʟᴀᴀᴋɪ ʟɪᴠᴇ ᴩᴀᴋᴅɪ ɢᴀʏɪ ʜᴀɪ.\n\n"
                    "🩸 **ᴀᴄᴛɪᴏɴ ᴛᴀᴋᴇɴ ʙʏ ᴋᴇʀɴᴇʟ:**\n"
                    "⇛ ᴛᴇʀᴀ ꜱᴇꜱꜱɪᴏɴ ᴛᴇʀᴇ ᴅᴇᴠɪᴄᴇ ꜱᴇ **ʟᴏɢᴏᴜᴛ** ᴍᴀᴀʀ ᴅɪʏᴀ ɢᴀʏᴀ ʜᴀɪ.\n"
                    "⇛ ᴛᴇʀᴀ ᴅᴀᴛᴀ ᴅᴀᴛᴀʙᴀꜱᴇ ꜱᴇ ᴩᴇʀᴍᴀɴᴇɴᴛʟʏ ᴇʀᴀꜱᴇ ʜᴏ ᴄʜᴜᴋᴀ ʜᴀɪ.\n\n"
                    "ᴀɢʟɪ ʙᴀᴀʀ ꜱʏꜱᴛᴇᴍ ꜱᴇ xᴇʟɴᴇ ꜱᴇ ᴩᴇʜʟᴇ ᴀᴩɴɪ ᴏᴜᴋᴀᴀᴛ ᴅᴇx ʟᴇɴᴀ. **ɢᴀᴍᴇ ᴏᴠᴇʀ!** 🍷"
                )
                try:
                    await client.send_message(user.id, warning_msg)
                except: pass
                print(f"\033[1;31m[ ☠️ KILLED ] ɴᴏᴅᴇ {user.id} ᴇʀᴀᴅɪᴄᴀᴛᴇᴅ!\033[0m")
    except Exception as e:
        print(f"[ERROR] {e}")

