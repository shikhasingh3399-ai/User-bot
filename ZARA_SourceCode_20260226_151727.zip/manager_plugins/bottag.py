import asyncio
import random
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait

# ==========================================
# ⚙️ SYSTEM CONFIGURATION
# ==========================================
HARDCODED_OWNER = 8036881129  # 🔥 SUPREME COMMANDER (TERI ID)
TAG_SESSIONS = {}

SIGMA_LINES = [
    "🚫 ACCESS DENIED: Manager Bot hai ye, tere baap ka naukar nahi!",
    "⚠️ SYSTEM ERROR: Teri aukaat nahi hai, sirf Supreme Commander allow hai.",
    "☠️ PERMISSION DENIED: Chup chap baith ja warna system block kar dega.",
    "☣️ OVERRIDE FAILED: Error 404 - Aukaat Not Found."
]

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {
            'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 
            'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 
            'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 
            'y': 'ʏ', 'z': 'ᴢ'
        }
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: 
        return text

# ==========================================
# 🔄 BATCH TAGGING WORKER
# ==========================================
async def tag_worker(client, chat_id, text, batch_size, status_msg):
    try:
        members = []
        # Manager bot needs admin rights to see all members in big groups
        async for member in client.get_chat_members(chat_id):
            if not member.user.is_bot and not member.user.is_deleted:
                members.append(member.user)

        if not members:
            return await status_msg.edit(f"❌ **{sm('KOI ZINDA INSAAN NAHI MILA!')}**")

        await status_msg.edit(f"🔥 **{sm('TAGGING PROTOCOL INITIATED')}**\n🎯 Target: `{len(members)}` members")

        chunk = []
        count = 0
        for user in members:
            # Agar session stop ho gaya ho beech mein
            if not TAG_SESSIONS.get(chat_id, False):
                break

            chunk.append(user.mention)
            count += 1

            # Jab batch size poora ho jaye, tab fire karo
            if len(chunk) == batch_size:
                formatted_text = f"{text}\n\n" + ", ".join(chunk) if text else ", ".join(chunk)
                try:
                    await client.send_message(chat_id, formatted_text)
                    await asyncio.sleep(2.5) # 🔥 Anti-Flood (Bot safe)
                except FloodWait as e:
                    await asyncio.sleep(e.value + 2)
                except Exception:
                    pass
                chunk = [] # Chunk khali karo agle batch ke liye

        # Bachi hui aakhri list ko fire karo
        if chunk and TAG_SESSIONS.get(chat_id, False):
            formatted_text = f"{text}\n\n" + ", ".join(chunk) if text else ", ".join(chunk)
            try:
                await client.send_message(chat_id, formatted_text)
            except: 
                pass

    except Exception as e:
        await client.send_message(chat_id, f"❌ **{sm('SYSTEM CRASHED')}**: `{e}`")

    # 🛑 END SUMMARY
    if TAG_SESSIONS.get(chat_id, False):
        TAG_SESSIONS[chat_id] = False
        try:
            await client.send_message(chat_id, f"✅ **{sm('TAGGING COMPLETE SUCCESSFULLY!')}**")
        except: 
            pass

# ==========================================
# ☢️ COMMANDS: /bottag1, /bottag2, /bottag5
# ==========================================
@Client.on_message(filters.command(["bottag1", "bottag2", "bottag5"], prefixes=["/", ".", "!"]))
async def start_tagging(client, message: Message):
    # 1. 🛡️ AUKAAT CHECK (STRICTLY OWNER)
    if message.from_user.id != HARDCODED_OWNER:
        return await message.reply_text(f"🛑 **{sm(random.choice(SIGMA_LINES))}**")

    if TAG_SESSIONS.get(message.chat.id, False):
        return await message.reply_text(f"⚠️ **{sm('EK PROCESS PEHLE SE CHAL RAHA HAI!')}**")

    # 2. GET BATCH SIZE FROM COMMAND
    cmd = message.command[0].lower()
    batch_size = 5 # Default
    if "1" in cmd: batch_size = 1
    elif "2" in cmd: batch_size = 2
    elif "5" in cmd: batch_size = 5

    # 3. GET TEXT TO TAG WITH
    text = ""
    if message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
    elif len(message.command) > 1:
        text = message.text.split(None, 1)[1]

    # 4. HACKER ANIMATION
    TAG_SESSIONS[message.chat.id] = True
    status_msg = await message.reply_text(f"⚡ **{sm('WAKING UP THE SWARM...')}**")
    await asyncio.sleep(0.4)
    await status_msg.edit(f"📡 **{sm('SCANNING GROUP DATABASE...')}**")

    # 5. START FIRE (Non-blocking)
    asyncio.create_task(tag_worker(client, message.chat.id, text, batch_size, status_msg))

# ==========================================
# 🛑 COMMAND: /stopbottag
# ==========================================
@Client.on_message(filters.command(["stopbottag"], prefixes=["/", ".", "!"]))
async def stop_tagging(client, message: Message):
    # 1. 🛡️ AUKAAT CHECK
    if message.from_user.id != HARDCODED_OWNER:
        return await message.reply_text(f"🛑 **{sm(random.choice(SIGMA_LINES))}**")

    if TAG_SESSIONS.get(message.chat.id, False):
        TAG_SESSIONS[message.chat.id] = False
        await message.reply_text(f"🛑 **{sm('MANAGER NE TAGGING ROK DI HAI!')}**")
    else:
        await message.reply_text(f"⚠️ **{sm('ABE KUCH CHAL HI NAHI RAHA KYA ROKU?')}**")

