import asyncio
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message, ChatPrivileges
from pyrogram.errors import ChatAdminRequired, UserAdminInvalid, RightForbidden

# 🛠️ CONFIG IMPORT
try:
    from config import OWNER_ID, SUDO_USERS
except ImportError:
    try:
        from config import OWNER_ID
        SUDO_USERS = [OWNER_ID]
    except: pass

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# Target Extraction Logic
async def get_target(client, message):
    target = None
    reason = None
    if message.reply_to_message:
        target = message.reply_to_message.from_user
        if len(message.command) > 1:
            reason = message.text.split(None, 1)[1]
    elif len(message.command) > 1:
        input_str = message.command[1]
        try:
            target = await client.get_users(int(input_str) if input_str.lstrip('-').isdigit() else input_str)
        except: pass
        if len(message.command) > 2:
            reason = message.text.split(None, 2)[2]
    return target, reason

# ==========================================
# ⚠️ WARNING SYSTEM (3 STRIKES = BAN)
# ==========================================
@Client.on_message(filters.command("warn", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def warn_user(client, message: Message):
    target, reason = await get_target(client, message)
    if not target: return await eor(message, f"⚠️ **{sm('target not found')}**")
    if target.id == OWNER_ID or target.id in SUDO_USERS:
        return await eor(message, f"🛡️ **{sm('admin immunity active')}**")

    warn_db = client.db["warnings"]
    chat_id = message.chat.id
    
    # Get current warnings
    user_warns = await warn_db.find_one({"chat_id": chat_id, "user_id": target.id})
    current_warns = user_warns["count"] if user_warns else 0
    current_warns += 1

    status_msg = await eor(message, f"⚡ **{sm('processing warning')}...**")

    # 🛑 AUTO BAN LOGIC
    if current_warns >= 3:
        try:
            await client.ban_chat_member(chat_id, target.id)
            await warn_db.delete_one({"chat_id": chat_id, "user_id": target.id}) # Reset
            
            txt = f"🔨 **{sm('max warnings reached')}**\n"
            txt += f"━━━━━━━━━━━━━━━━━━\n"
            txt += f"👤 **{sm('target')}**: {target.mention}\n"
            txt += f"💀 **{sm('action')}**: `BANNED (3/3 Strikes)`\n"
            if reason: txt += f"📝 **{sm('final reason')}**: `{sm(reason)}`"
            return await status_msg.edit(txt)
            
        except ChatAdminRequired:
            return await status_msg.edit(f"❌ **{sm('error')}**: `I have no ban permission here!`")
        except Exception as e:
            return await status_msg.edit(f"❌ **{sm('error')}**: `{e}`")

    # UPDATE DB
    await warn_db.update_one(
        {"chat_id": chat_id, "user_id": target.id},
        {"$set": {"count": current_warns}}, upsert=True
    )

    txt = f"⚠️ **{sm('warning issued')}**\n"
    txt += f"━━━━━━━━━━━━━━━━━━\n"
    txt += f"👤 **{sm('user')}**: {target.mention}\n"
    txt += f"📊 **{sm('strikes')}**: `{current_warns}/3`\n"
    if reason: txt += f"📝 **{sm('reason')}**: `{sm(reason)}`"
    
    await status_msg.edit(txt)

@Client.on_message(filters.command(["unwarn", "rmwarn"], prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def unwarn_user(client, message: Message):
    target, _ = await get_target(client, message)
    if not target: return await eor(message, f"⚠️ **{sm('target not found')}**")

    warn_db = client.db["warnings"]
    await warn_db.delete_one({"chat_id": message.chat.id, "user_id": target.id})
    await eor(message, f"✅ **{sm('warnings cleared')}** {sm('for')} {target.mention}")

# ==========================================
# 📌 PIN & UNPIN MODULES
# ==========================================
@Client.on_message(filters.command("pin", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def pin_message(client, message: Message):
    try:
        if message.reply_to_message:
            # Pin the replied message
            await message.reply_to_message.pin(disable_notification=False)
            await eor(message, f"📌 **{sm('message pinned successfully')}**")
        elif len(message.command) > 1:
            # Send the text and pin it
            text_to_pin = message.text.split(None, 1)[1]
            sent_msg = await client.send_message(message.chat.id, text_to_pin)
            await sent_msg.pin(disable_notification=False)
            await message.delete() # Apna command delete kar dega
        else:
            await eor(message, f"⚠️ **{sm('reply to a message or give text to pin')}**")
    except ChatAdminRequired:
        await eor(message, f"❌ **{sm('error')}**: `I have no pin permission here!`")
    except Exception as e:
        await eor(message, f"❌ **{sm('error')}**: `{e}`")

@Client.on_message(filters.command("unpin", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def unpin_message(client, message: Message):
    try:
        if message.reply_to_message:
            await message.reply_to_message.unpin()
            await eor(message, f"🗑️ **{sm('message unpinned')}**")
        else:
            await eor(message, f"⚠️ **{sm('reply to a pinned message to unpin')}**")
    except ChatAdminRequired:
        await eor(message, f"❌ **{sm('error')}**: `I have no pin permission here!`")
    except Exception as e:
        await eor(message, f"❌ **{sm('error')}**: `{e}`")

@Client.on_message(filters.command("unpinall", prefixes=".") & filters.me) # Owner only for safety
async def unpin_all_messages(client, message: Message):
    try:
        await client.unpin_all_chat_messages(message.chat.id)
        await eor(message, f"🧹 **{sm('all messages unpinned')}**")
    except ChatAdminRequired:
        await eor(message, f"❌ **{sm('error')}**: `I have no pin permission here!`")
    except Exception as e:
        await eor(message, f"❌ **{sm('error')}**: `{e}`")

# ==========================================
# 👑 PROMOTE & DEMOTE MODULES (THE BONUS)
# ==========================================
@Client.on_message(filters.command("promote", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def promote_user(client, message: Message):
    target, title = await get_target(client, message)
    if not target: return await eor(message, f"⚠️ **{sm('target not found')}**")
    
    admin_title = title if title else "ZARA Admin"
    status_msg = await eor(message, f"⚡ **{sm('granting admin privileges')}...**")
    
    try:
        await client.promote_chat_member(
            message.chat.id, 
            target.id,
            privileges=ChatPrivileges(
                can_manage_chat=True,
                can_delete_messages=True,
                can_manage_video_chats=True,
                can_restrict_members=True,
                can_promote_members=False,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=True
            )
        )
        try: await client.set_administrator_title(message.chat.id, target.id, admin_title)
        except: pass
        
        await status_msg.edit(f"👑 **{sm('promoted successfully')}**: {target.mention}\n🏷️ **{sm('title')}**: `{sm(admin_title)}`")
    except ChatAdminRequired:
        await status_msg.edit(f"❌ **{sm('error')}**: `I have no promote permission here!`")
    except Exception as e:
        await status_msg.edit(f"❌ **{sm('error')}**: `{e}`")

@Client.on_message(filters.command("demote", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def demote_user(client, message: Message):
    target, _ = await get_target(client, message)
    if not target: return await eor(message, f"⚠️ **{sm('target not found')}**")
    
    status_msg = await eor(message, f"⚡ **{sm('revoking admin privileges')}...**")
    
    try:
        await client.promote_chat_member(
            message.chat.id, 
            target.id,
            privileges=ChatPrivileges(
                can_manage_chat=False,
                can_delete_messages=False,
                can_manage_video_chats=False,
                can_restrict_members=False,
                can_promote_members=False,
                can_change_info=False,
                can_invite_users=False,
                can_pin_messages=False
            )
        )
        await status_msg.edit(f"📉 **{sm('demoted successfully')}**: {target.mention}")
    except ChatAdminRequired:
        await status_msg.edit(f"❌ **{sm('error')}**: `I have no demote permission here!`")
    except Exception as e:
        await status_msg.edit(f"❌ **{sm('error')}**: `{e}`")


