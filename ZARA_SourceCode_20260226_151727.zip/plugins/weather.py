import asyncio
import aiohttp
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🛰️ ASYNC SATELLITE UPLINK (Open-Meteo)
# ==========================================
async def fetch_weather_data(city):
    try:
        async with aiohttp.ClientSession() as session:
            # STEP 1: Tactical Geocoding
            geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1&language=en&format=json"
            async with session.get(geo_url, timeout=5) as geo_res:
                geo_data = await geo_res.json()
            
            if not geo_data.get("results"):
                return None 
                
            loc = geo_data["results"][0]
            lat, lon = loc["latitude"], loc["longitude"]
            place = loc["name"]
            country = loc.get("country", "Unknown")
            
            # STEP 2: Deep Atmospheric Scan
            weather_url = (
                f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
                f"&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,surface_pressure,cloud_cover,visibility"
                f"&daily=sunrise,sunset,uv_index_max&timezone=auto"
            )
            async with session.get(weather_url, timeout=5) as w_res:
                w_data = await w_res.json()
            
            return {"geo": {"name": place, "country": country, "lat": lat, "lon": lon}, "data": w_data}
    except Exception as e:
        print(f"Satellite Error: {e}")
        return None

# ==========================================
# ☢️ THREAT LEVEL ANALYZER
# ==========================================
def analyze_threat(temp, wind, uv):
    if temp >= 40 or temp <= 0 or wind >= 50 or uv >= 9:
        return "🔴 CRITICAL (EXTREME CONDITIONS)"
    elif temp >= 35 or temp <= 5 or wind >= 35 or uv >= 6:
        return "🟠 MODERATE (CAUTION ADVISED)"
    return "🟢 STABLE (SAFE OPERATIONS)"

def get_condition(code, is_day):
    c = code
    if c == 0: return ("☀️" if is_day else "🌙", "CLEAR SKY")
    if c == 1: return ("🌤️", "MAINLY CLEAR")
    if c == 2: return ("⛅", "PARTLY CLOUDY")
    if c == 3: return ("☁️", "OVERCAST")
    if c in [45, 48]: return ("🌫️", "FOG SIGNAL")
    if c in [51, 53, 55]: return ("🌦️", "LIGHT DRIZZLE")
    if c in [56, 57]: return ("🌨️", "FREEZING DRIZZLE")
    if c in [61, 63, 65]: return ("🌧️", "RAIN PRECIPITATION")
    if c in [66, 67]: return ("🌨️", "FREEZING RAIN")
    if c in [71, 73, 75, 77]: return ("❄️", "SNOWFALL DETECTED")
    if c in [80, 81, 82]: return ("⛈️", "HEAVY RAIN SHOWERS")
    if c in [85, 86]: return ("❄️", "HEAVY SNOW SHOWERS")
    if c in [95, 96, 99]: return ("⚡", "THUNDERSTORM ALERT")
    return ("🌡️", "UNKNOWN ANOMALY")

# ==========================================
# ⛈️ COMMAND: SIGMA WEATHER
# ==========================================
@Client.on_message(filters.command(["weather", ], prefixes=[".", "!", "/"]) & filters.me)
async def weather_system(client, message: Message):
    if len(message.command) < 2:
        return await eor(message, f"⚠️ **{sm('USAGE')}**: `.w <City Name>`")
    
    city = message.text.split(None, 1)[1]
    
    # 1. Terminal Decryption Animation
    status = await eor(message, f"🛰️ **{sm('ESTABLISHING SATELLITE UPLINK...')}**")
    await asyncio.sleep(0.4)
    await status.edit(f"🎯 **{sm('CALIBRATING TARGET COORDS')}**: `{city.upper()}`")
    await asyncio.sleep(0.4)
    await status.edit(f"🔐 **{sm('BYPASSING METEOROLOGICAL FIREWALL...')}**")
    
    # 2. Asynchronous Fetch
    result = await fetch_weather_data(city)
    
    if not result:
        return await status.edit(f"❌ **{sm('SIGNAL LOST')}**: `{sm('TARGET CITY NOT FOUND ON RADAR')}`")

    try:
        # 3. Data Extraction
        geo = result["geo"]
        curr = result["data"]["current"]
        daily = result["data"]["daily"]
        
        temp = curr["temperature_2m"]
        feels = curr["apparent_temperature"]
        humid = curr["relative_humidity_2m"]
        wind = curr["wind_speed_10m"]
        pressure = curr["surface_pressure"]
        clouds = curr["cloud_cover"]
        vis_km = round(curr["visibility"] / 1000, 1)
        uv_max = daily["uv_index_max"][0]
        
        sunrise = daily["sunrise"][0].split("T")[1]
        sunset = daily["sunset"][0].split("T")[1]
        
        icon, cond_text = get_condition(curr["weather_code"], curr["is_day"])
        threat_level = analyze_threat(temp, wind, uv_max)
        
        # 4. The Sigma HUD Layout
        report = f"💀 **{sm('ZARA ORBITAL SCANNER V4.0')}**\n"
        report += f"━━━━━━━━━━━━━━━━━━━━━━\n"
        report += f"📍 **{sm('COORDS')}**: `{geo['lat']}, {geo['lon']}`\n"
        report += f"🏙️ **{sm('TARGET')}**: `{geo['name'].upper()}, {geo['country'].upper()}`\n"
        report += f"━━━━━━━━━━━━━━━━━━━━━━\n"
        report += f"{icon} **{sm(cond_text)}**\n"
        report += f"🌡️ **{sm('TEMP')}**: `{temp}°C` (Feels: `{feels}°C`)\n\n"
        
        report += f"💨 **{sm('WIND')}**: `{wind} km/h`    │ ☁️ **{sm('CLOUD COVER')}**: `{clouds}%`\n"
        report += f"💧 **{sm('HUMIDITY')}**: `{humid}%`   │ 👁️ **{sm('VISIBILITY')}**: `{vis_km} km`\n"
        report += f"⚓ **{sm('PRESSURE')}**: `{pressure} hPa` │ ☢️ **{sm('MAX UV IDX')}**: `{uv_max}`\n"
        report += f"━━━━━━━━━━━━━━━━━━━━━━\n"
        report += f"🌅 **{sm('SUNRISE')}**: `{sunrise}` │ 🌇 **{sm('SUNSET')}**: `{sunset}`\n"
        report += f"━━━━━━━━━━━━━━━━━━━━━━\n"
        report += f"⚠️ **{sm('THREAT LEVEL')}**: `{sm(threat_level)}`"
        
        await status.edit(report)
        
    except Exception as e:
        await status.edit(f"⚠️ **{sm('SYSTEM CORRUPTION')}**: `{str(e)}`")

