import aiohttp
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from config import OWNER_ID, is_sudo

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

# ==========================================
# 🛰️ ZARA GEO-TRACER (PUBLIC + OWNER PROTECTED)
# ==========================================
# Filter me kuch nahi lagaya, yani public use kar sakti hai
@Client.on_message(filters.command(["ip", ], prefixes="."))
async def geo_tracer(client, message: Message):
    
    # Check if user is Owner/Sudo
    user_id = message.from_user.id if message.from_user else 0
    is_owner_or_sudo = (user_id == OWNER_ID or is_sudo(user_id))

    # 1. TARGET SELECTION
    target = None
    mode = "SELF" 
    
    if len(message.command) > 1:
        target = message.command[1]
        target = target.replace("https://", "").replace("http://", "").split("/")[0]
        mode = "TARGET"
        
    elif message.reply_to_message and message.reply_to_message.text:
        content = message.reply_to_message.text
        if "." in content:
            target = content.split()[0].replace("https://", "").replace("http://", "")
            mode = "TARGET"

    # 🛑 SECURITY BLOCK: Normal users apni marzi se Bot ka IP nahi nikal sakte
    if mode == "SELF" and not is_owner_or_sudo:
        return await message.reply("❌ **Error:** Please provide a target IP or Domain.\n👉 `Usage: .ip 8.8.8.8`")

    # 2. UI STATUS (Smart Reply/Edit Logic)
    if user_id == client.me.id:
        # Agar owner ne khud command di hai to edit karo
        status = await message.edit(f"🛰️ **{sm('tracking target')}...**")
    else:
        # Agar public ne command di hai to reply karo
        status = await message.reply(f"🛰️ **{sm('tracking target')}...**")

    # 3. API REQUEST
    try:
        query_url = f"http://ip-api.com/json/{target}" if target else "http://ip-api.com/json/"
        fields = "status,message,country,regionName,city,zip,lat,lon,timezone,isp,org,as,query,mobile,proxy,hosting"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{query_url}?fields={fields}") as response:
                result = await response.json()

        if result['status'] == 'fail':
            err_text = f"❌ **{sm('trace failed')}**\n⚠️ Reason: `{result['message']}`"
            if user_id == client.me.id: return await status.edit(err_text)
            else: return await status.edit_text(err_text)

        # 4. DATA PARSING
        ip = result.get('query', 'N/A')
        city = result.get('city', 'Unknown')
        region = result.get('regionName', 'Unknown')
        country = result.get('country', 'Unknown')
        isp = result.get('isp', 'Unknown')
        org = result.get('org', 'Unknown')
        lat = result.get('lat', 0)
        lon = result.get('lon', 0)
        timezone = result.get('timezone', 'UTC')
        
        id_type = "🏠 RESIDENTIAL"
        if result.get('mobile'): id_type = "📱 MOBILE DATA"
        elif result.get('hosting'): id_type = "☁️ DATA CENTER (BOT)"
        elif result.get('proxy'): id_type = "🎭 PROXY / VPN"

        # Fixed Google Maps Link
        map_url = f"https://www.google.com/maps?q={lat},{lon}"
        
        # 5. GENERATE REPORT
        if mode == "SELF":
            header = f"🤖 **{sm('NODE IDENTITY')}**: `{client.me.first_name}`"
        else:
            header = f"🎯 **{sm('TARGET LOCKED')}**: `{target}`"

        report = (
            f"{header}\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🌍 **{sm('ip address')}**: `{ip}`\n"
            f"💀 **{sm('type')}**: `{id_type}`\n"
            f"🚩 **{sm('location')}**: `{city}, {country}`\n"
            f"🏢 **{sm('isp')}**: `{isp}`\n"
            f"🏢 **{sm('org')}**: `{org}`\n"
            f"🕰️ **{sm('timezone')}**: `{timezone}`\n"
            f"📍 **{sm('coords')}**: `{lat}, {lon}`\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🧭 **[OPEN GOOGLE MAP]({map_url})**\n"
            f"💀 **{sm('zara kernel')}**"
        )

        # 6. FINAL OUTPUT
        if user_id == client.me.id:
            await status.edit(report, disable_web_page_preview=True)
        else:
            await status.edit_text(report, disable_web_page_preview=True)

    except Exception as e:
        if user_id == client.me.id:
            await status.edit(f"❌ **{sm('error')}**: `{e}`")
        else:
            await status.edit_text(f"❌ **{sm('error')}**: `{e}`")


