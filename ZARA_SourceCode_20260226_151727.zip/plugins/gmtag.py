import asyncio
import random
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait

# 🛠️ DATABASE IMPORT
try:
    from core.database import db
    collection = db.gmtag
except ImportError:
    collection = None

# ==========================================
# ⚙️ SYSTEM CONFIGURATION
# ==========================================
HARDCODED_OWNER = 8036881129  # 🔥 TERA BAAP (SUPREME COMMANDER)
GM_SESSIONS = {}
GM_CACHE = []

DEFAULT_GM = [
    "Good Morning! ☀️",
    "Utho sone walo sawera ho gaya 🐓",
    "Rise and Shine Ludo! ✨",
    "Aankh khol le bhai, subah ho gayi 👀",
    "Chalo utho, duniya me aag lagani hai 🔥"
]

SIGMA_LINES = [
    "Abe Lode! Apne hi Baap (Owner) ki command use karega? 🖕",
    "Teri aukaat jhaant barabar nahi, aur System Database chherega? 😂",
    "Madarchod, System hila dunga tera! NIKAL! 🤬",
    "Error 404: Teri aukaat not found! 😎"
]

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🧠 DATABASE LOADER (FAST CACHE)
# ==========================================
async def load_gm_data():
    global GM_CACHE
    if collection is None:
        GM_CACHE = DEFAULT_GM
        return
    try:
        temp_list = []
        async for doc in collection.find():
            if "text" in doc: temp_list.append(doc["text"])
        
        if temp_list: GM_CACHE = temp_list
        else: GM_CACHE = DEFAULT_GM
    except Exception:
        GM_CACHE = DEFAULT_GM

asyncio.get_event_loop().create_task(load_gm_data())

# ==========================================
# 🔄 WORKER ENGINE (MACHINE GUN)
# ==========================================
async def gmtag_engine(client, chat_id, messages):
    count = 0
    try:
        async for member in client.get_chat_members(chat_id):
            if not GM_SESSIONS.get(chat_id, False): break
            
            # 🔥 SIGMA PROTECTION: Bot isko ignore karega (Bots, Deleted, and Owner)
            if member.user.is_bot or member.user.is_deleted: continue
            if member.user.id == HARDCODED_OWNER: continue 
            
            try:
                txt = random.choice(messages)
                mention = member.user.mention
                
                await client.send_message(chat_id, f"{txt} {mention}")
                count += 1
                await asyncio.sleep(2.5) # 🔥 Anti-Flood Safe Delay
                
            except FloodWait as e:
                await asyncio.sleep(e.value + 2)
            except Exception: pass
            
    except Exception: pass
    
    # 🛑 END SUMMARY
    if GM_SESSIONS.get(chat_id, False):
        GM_SESSIONS[chat_id] = False
        try:
            await client.send_message(chat_id, f"✅ **{sm('MISSION ACCOMPLISHED')}**\n💀 **{sm('TOTAL TARGETS WAKED UP')}**: `{count}`")
        except: pass

# ==========================================
# ➕ COMMAND: ADD GM (OWNER ONLY)
# ==========================================
@Client.on_message(filters.command(["addgm", ], prefixes=[".", "!", "/"]) & filters.me)
async def add_gm_line(client, message: Message):
    # 🔥 THE ULTIMATE AUKAAT CHECK
    if message.from_user.id != HARDCODED_OWNER:
        return await eor(message, f"🛑 **{sm('AUKAAT ME REH LUDE')}!**\n`{random.choice(SIGMA_LINES)}`")

    if message.reply_to_message and message.reply_to_message.text:
        content = message.reply_to_message.text
    elif len(message.command) > 1:
        content = message.text.split(None, 1)[1]
    else:
        return await eor(message, f"⚠️ **{sm('USAGE')}**: `.addgm <text/reply>`")
    
    if collection is None:
        return await eor(message, f"❌ **{sm('DATABASE MISSING')}**")

    msg = await eor(message, f"🔄 **{sm('UPLOADING TO MAINFRAME')}...**")
    
    lines = content.split('\n')
    new_entries = [{"text": line.strip()} for line in lines if line.strip()]

    if new_entries:
        try:
            await collection.insert_many(new_entries, ordered=False)
            global GM_CACHE
            for entry in new_entries: GM_CACHE.append(entry["text"])
            await msg.edit(f"✅ **{sm('DATABASE INJECTED')}!**\n📥 **{sm('NEW LINES LOADED')}**: `{len(new_entries)}` 💀")
        except Exception as e:
            await msg.edit(f"❌ **{sm('DB ERROR')}**: `{e}`")
    else:
        await msg.edit(f"⚠️ **{sm('EMPTY TEXT LAUDE')}**")

# ==========================================
# 🗑️ COMMAND: CLEAR GM DB (OWNER ONLY)
# ==========================================
@Client.on_message(filters.command(["cleargm", ], prefixes=[".", "!", "/"]) & filters.me)
async def clear_gm_db(client, message: Message):
    if message.from_user.id != HARDCODED_OWNER:
        return await eor(message, f"🛑 **{sm('AUKAAT ME REH LUDE')}!**\n`{random.choice(SIGMA_LINES)}`")

    if collection is None:
        return await eor(message, f"❌ **{sm('DATABASE MISSING')}**")

    msg = await eor(message, f"🗑️ **{sm('WIPING DATABASE...')}**")
    await collection.delete_many({}) 
    global GM_CACHE
    GM_CACHE = DEFAULT_GM
    await msg.edit(f"✅ **{sm('DATABASE WIPED SUCCESSFUL')}!**\n`{sm('SYSTEM REVERTED TO DEFAULT')} 💀`")

# ==========================================
# 📊 COMMAND: LIST GM (OWNER ONLY)
# ==========================================
@Client.on_message(filters.command(["gmlist", ], prefixes=[".", "!", "/"]) & filters.me)
async def list_gm_lines(client, message: Message):
    if message.from_user.id != HARDCODED_OWNER:
        return await eor(message, f"🛑 **{sm('ACCESS DENIED')}!**\n`{sm('SIRF TERA BAAP YE USE KAR SAKTA HAI')} 💀`")

    count = len(GM_CACHE)
    text = f"💀 **{sm('ZARA GM ARMORY')}**\n"
    text += f"━━━━━━━━━━━━━━━━━━━━\n"
    text += f"📥 **{sm('TOTAL LINES LOADED')}**: `{count}`\n"
    text += f"🟢 **{sm('STATUS')}**: `{sm('READY TO FIRE')}`\n"
    text += f"━━━━━━━━━━━━━━━━━━━━\n"
    await eor(message, text)

# ==========================================
# ⚔️ COMMAND: START GM TAG (ALL USERS)
# ==========================================
@Client.on_message(filters.command(["gmtag", ], prefixes=[".", "!", "/"]) & filters.me)
async def start_gm(client, message: Message):
    if GM_SESSIONS.get(message.chat.id, False):
        return await eor(message, f"⚠️ **{sm('PROCESS ALREADY RUNNING LAUDE')}**")
    
    ammo = GM_CACHE if GM_CACHE else DEFAULT_GM
    GM_SESSIONS[message.chat.id] = True
    
    # 🔥 TOXIC ANIMATION
    anim = await eor(message, f"⚡ **{sm('INITIALIZING ZARA KERNEL...')}**")
    await asyncio.sleep(0.3)
    await anim.edit(f"📡 **{sm('SCANNING SLEEPY TARGETS...')}**")
    await asyncio.sleep(0.3)
    await anim.edit(f"🌤️ **{sm('GOOD MORNING PROTOCOL ACTIVE')}**\n🔄 **{sm('LINES LOADED')}**: `{len(ammo)}`\n⏳ **{sm('STATUS')}**: `{sm('WAKING UP BASTARDS...')} 💥`")
    
    asyncio.create_task(gmtag_engine(client, message.chat.id, ammo))

# ==========================================
# 🛑 COMMAND: STOP GM TAG (ALL USERS)
# ==========================================
@Client.on_message(filters.command(["stopgmtag", ], prefixes=[".", "!", "/"]) & filters.me)
async def stop_gm(client, message: Message):
    if GM_SESSIONS.get(message.chat.id, False):
        GM_SESSIONS[message.chat.id] = False
        await eor(message, f"🛑 **{sm('PROCESS TERMINATED BY USER')} 💀**")
    else:
        await eor(message, f"⚠️ **{sm('ABE KUCH CHAL HI NAHI RAHA LAUDE')}**")

