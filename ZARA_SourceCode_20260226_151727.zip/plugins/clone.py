import os
import asyncio
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait

# ==========================================
# 💀 ZARA IDENTITY BACKUP SYSTEM
# ==========================================
ZARA_BACKUP = {}

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🎭 COMMAND: CLONE (IDENTITY THEFT)
# ==========================================
@Client.on_message(filters.command("clone", prefixes=[".", "!", "/"]) & filters.me)
async def clone_identity(client, message: Message):
    target = None
    anim = await eor(message, f"⚡ **{sm('INITIALIZING IDENTITY THEFT...')}**")

    # 1. TARGET ACQUISITION
    try:
        if message.reply_to_message:
            target = message.reply_to_message.from_user
        elif len(message.command) > 1:
            user_input = message.command[1]
            if user_input.isdigit(): target = await client.get_users(int(user_input))
            else: target = await client.get_users(user_input)
    except Exception as e:
        return await anim.edit(f"❌ **{sm('TARGET NOT FOUND')}**: `{e}`")

    if not target:
        return await anim.edit(f"⚠️ **{sm('REPLY KAR YA USERNAME DE LAUDE')}**")

    # 2. BACKUP ORIGINAL IDENTITY (BEFORE CLONING)
    try:
        me = await client.get_me()
        my_chat = await client.get_chat("me")
        
        # Sirf tab backup lo jab pehle se backup na ho (warna clone pe clone marega to original lost ho jayega)
        if not ZARA_BACKUP:
            ZARA_BACKUP["first_name"] = me.first_name or ""
            ZARA_BACKUP["last_name"] = me.last_name or ""
            ZARA_BACKUP["bio"] = my_chat.bio or ""
            await anim.edit(f"💾 **{sm('ORIGINAL IDENTITY SAVED IN SECURE VAULT...')}**")
            await asyncio.sleep(0.5)
    except Exception as e:
        return await anim.edit(f"❌ **{sm('BACKUP FAILED')}**: `{e}`")

    # 3. EXTRACTION AND INJECTION (CLONING)
    await anim.edit(f"🧬 **{sm('EXTRACTING TARGET DNA...')}**")
    
    try:
        target_chat = await client.get_chat(target.id)
        
        # 🔥 SAFELY SLICING TO PREVENT 'ENTITY_BOUNDS_INVALID' CRASH
        fname = target.first_name[:64] if target.first_name else ""
        lname = target.last_name[:64] if target.last_name else ""
        bio = target_chat.bio[:70] if target_chat.bio else ""

        # Update Name and Bio
        await client.update_profile(first_name=fname, last_name=lname, bio=bio)
        
        # Clone Profile Picture
        photo_id = None
        async for photo in client.get_chat_photos(target.id, limit=1):
            photo_id = photo.file_id
            break

        if photo_id:
            await anim.edit(f"📸 **{sm('STEALING PROFILE PICTURE...')}**")
            photo_path = await client.download_media(photo_id)
            await client.set_profile_photo(photo=photo_path)
            if os.path.exists(photo_path):
                os.remove(photo_path)
        
        await anim.edit(f"💀 **{sm('IDENTITY CLONED SUCCESSFULLY')}!**\n`{sm('NOW YOU ARE')} {fname}`")

    except Exception as e:
        await anim.edit(f"❌ **{sm('SYSTEM CRASH DURING CLONE')}**: `{e}`")


# ==========================================
# 🔄 COMMAND: REVERT (BACK TO ORIGINAL)
# ==========================================
@Client.on_message(filters.command("revert", prefixes=[".", "!", "/"]) & filters.me)
async def revert_identity(client, message: Message):
    if not ZARA_BACKUP:
        return await eor(message, f"⚠️ **{sm('NO BACKUP FOUND! PEHLE KISI KO CLONE TO KAR LAUDE')}**")

    anim = await eor(message, f"⚡ **{sm('RESTORING ORIGINAL IDENTITY...')}**")

    try:
        # 1. Restore Name and Bio
        await client.update_profile(
            first_name=ZARA_BACKUP["first_name"],
            last_name=ZARA_BACKUP["last_name"],
            bio=ZARA_BACKUP["bio"]
        )

        # 2. Restore Profile Picture
        # Logic: Telegram pe current DP delete karne se, uske peeche wali (Original) DP wapas aa jati hai!
        async for photo in client.get_chat_photos("me", limit=1):
            await client.delete_profile_photos(photo.file_id)
            break
            
        # 3. Clear the Backup Vault
        ZARA_BACKUP.clear()
        
        await anim.edit(f"✅ **{sm('IDENTITY RESTORED! WELCOME BACK ZARA KERNEL')} 👑**")

    except Exception as e:
        await anim.edit(f"❌ **{sm('RESTORE FAILED')}**: `{e}`")

