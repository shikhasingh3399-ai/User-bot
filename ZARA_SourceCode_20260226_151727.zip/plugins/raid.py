import asyncio
import random
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait
from motor.motor_asyncio import AsyncIOMotorClient

# ==========================================
# ⚙️ SYSTEM CONFIGURATION
# ==========================================
try:
    from config import MONGO_URI
except ImportError:
    MONGO_URI = None

HARDCODED_OWNER = 8036881129  # 🔥 TERA BAAP (SUPREME COMMANDER)

if MONGO_URI:
    mongo = AsyncIOMotorClient(MONGO_URI)
    db = mongo["ZARA_BOTNET"]
    raid_collection = db["raid_data"]
else:
    raid_collection = None

# ⚡ GLOBAL FLAGS
RAID_STATUS = {} 
RAID_CACHE = []  

# 🤬 DEFAULT AMMO (SIGMA LEVEL)
DEFAULT_ABUSE = [
    "Madarchod bhag yaha se 🖕",
    "Teri maa ka bhosda 🤬",
    "Nikal lawde pehli fursat me 👋",
    "Tera baap aaya hai, jhuk ke reh 😎",
    "Gand me danda de dunga 🎋",
    "Kutte ki maut marega tu 🐕",
    "Bhosdike nikal yaha se 😡",
    "Randi ke bache shant reh 🤫"
]

SIGMA_LINES = [
    "Abe Lode! Apne hi Baap (Owner) pe raid karega? 🖕",
    "Teri aukaat jhaant barabar nahi, aur System God ko pelega? 😂",
    "Madarchod, System hila dunga tera! NIKAL! 🤬",
    "Error 404: Teri aukaat not found! 😎"
]

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🧠 DATABASE LOADER (BUG FIXED)
# ==========================================
async def load_raid_data():
    global RAID_CACHE
    # 🔥 FIX: Explicitly checking 'is None' instead of 'not'
    if raid_collection is None:
        RAID_CACHE = DEFAULT_ABUSE
        return
    try:
        temp_list = []
        async for doc in raid_collection.find():
            if "text" in doc: temp_list.append(doc["text"])
        
        if temp_list: RAID_CACHE = temp_list
        else: RAID_CACHE = DEFAULT_ABUSE
    except Exception:
        RAID_CACHE = DEFAULT_ABUSE

# Boot sequence loader
asyncio.get_event_loop().create_task(load_raid_data())

# ==========================================
# 🔫 MACHINE GUN WORKER
# ==========================================
async def raid_worker(client_instance, chat_id, mention, count, ammo_list):
    i = 0
    while i < count:
        if not RAID_STATUS.get(chat_id, False): break
        try:
            txt = random.choice(ammo_list)
            await client_instance.send_message(chat_id, f"{txt} {mention}")
            i += 1
            await asyncio.sleep(0.1) 
        except FloodWait as e:
            await asyncio.sleep(e.value + 1)
        except Exception:
            await asyncio.sleep(1.0)

# ==========================================
# ➕ COMMAND: ADD RAID (OWNER ONLY)
# ==========================================
@Client.on_message(filters.command("addraid", prefixes=[".", "!", "/"]) & filters.user(HARDCODED_OWNER) & filters.me)
async def add_raid_data(client, message: Message):
    if not message.reply_to_message or not message.reply_to_message.text:
        return await eor(message, f"❌ **{sm('REPLY KISPE KARU LAUDE? TEXT DE')}**")

    # 🔥 FIX: Explicitly checking 'is None'
    if raid_collection is None:
        return await eor(message, f"❌ **{sm('DATABASE MISSING! MONGO_URI CHECK KAR')}**")

    msg = await eor(message, f"⚡ **{sm('UPDATING WEAPON ARSENAL...')}**")
    
    lines = message.reply_to_message.text.split("\n")
    new_entries = [{"text": line.strip()} for line in lines if line.strip()]

    if new_entries:
        await raid_collection.insert_many(new_entries)
        global RAID_CACHE
        for entry in new_entries: RAID_CACHE.append(entry["text"])
        await msg.edit(f"✅ **{sm('DATABASE INJECTED')}!**\n`{len(new_entries)} {sm('NEW ABUSES LOADED')} 💀`")
    else:
        await msg.edit(f"⚠️ **{sm('TEXT EMPTY HAI BE')}**")

# ==========================================
# 🗑️ COMMAND: DEL RAID (OWNER ONLY)
# ==========================================
@Client.on_message(filters.command(["delraid", ], prefixes=[".", "!", "/"]) & filters.user(HARDCODED_OWNER) & filters.me)
async def clear_raid_data(client, message: Message):
    # 🔥 FIX: Explicitly checking 'is None'
    if raid_collection is None:
        return await eor(message, f"❌ **{sm('DATABASE MISSING')}**")

    msg = await eor(message, f"⚡ **{sm('WIPING RAID DATABASE...')}**")
    try:
        await raid_collection.delete_many({})
        global RAID_CACHE
        RAID_CACHE = DEFAULT_ABUSE
        await msg.edit(f"🗑️ **{sm('ALL RAID DATA WIPED!')}**\n`{sm('SYSTEM REVERTED TO DEFAULT AMMO')} 💀`")
    except Exception as e:
        await msg.edit(f"❌ **{sm('DB ERROR')}**: `{e}`")

# ==========================================
# 📊 COMMAND: RAID LIST (OWNER ONLY)
# ==========================================
@Client.on_message(filters.command("raidlist", prefixes=[".", "!", "/"]) & filters.user(HARDCODED_OWNER) & filters.me)
async def count_raid_data(client, message: Message):
    total = len(RAID_CACHE)
    text = f"💀 **{sm('ZARA ARMORY STATUS')}**\n"
    text += f"━━━━━━━━━━━━━━━━━━━━\n"
    text += f"🤬 **{sm('TOTAL ABUSES LOADED')}**: `{total}`\n"
    text += f"🟢 **{sm('STATUS')}**: `{sm('READY TO FIRE')}`\n"
    text += f"━━━━━━━━━━━━━━━━━━━━\n"
    await eor(message, text)

# ==========================================
# ⚔️ COMMAND: RAID (ALL USERS)
# ==========================================
@Client.on_message(filters.command("raid", prefixes=[".", "!", "/"]) & filters.me)
async def start_raid(client, message: Message):
    target = None
    count = 10
    
    if message.reply_to_message:
        target = message.reply_to_message.from_user
        if len(message.command) > 1 and message.command[1].isdigit():
            count = int(message.command[1])
    elif len(message.command) > 1:
        try:
            u_in = message.command[1]
            if u_in.isdigit(): target = await client.get_users(int(u_in))
            else: target = await client.get_users(u_in)
            
            if len(message.command) > 2 and message.command[2].isdigit():
                count = int(message.command[2])
        except:
            return await eor(message, f"❌ **{sm('USER NOT FOUND LAUDE')}**")

    if not target:
        return await eor(message, f"⚠️ **{sm('TARGET KAHAN HAI BE?')}**")

    # 🔥 SIGMA PROTECTION: NO ONE CAN RAID THE OWNER
    if target.id == HARDCODED_OWNER:
        anim = await eor(message, f"⚠️ **{sm('WARNING')}!**")
        await asyncio.sleep(0.5)
        return await anim.edit(f"👑 **{random.choice(SIGMA_LINES)}**")

    # 3. SETUP & ANIMATION
    RAID_STATUS[message.chat.id] = True
    mention = f"[{target.first_name}](tg://user?id={target.id})"
    ammo_list = RAID_CACHE if RAID_CACHE else DEFAULT_ABUSE

    anim = await eor(message, f"⚡ **{sm('INITIALIZING ZARA RAID KERNEL...')}**")
    await asyncio.sleep(0.3)
    await anim.edit(f"🎯 **{sm('TARGET LOCKED')}**: {mention}")
    await asyncio.sleep(0.3)
    await anim.edit(f"🖕 **{sm('MAA CH*D DO SALE KI')}!** 💥")
    await asyncio.sleep(0.4)
    await anim.delete()

    # 4. START FIRING
    asyncio.create_task(raid_worker(client, message.chat.id, mention, count, ammo_list))

# ==========================================
# 🛑 COMMAND: STOP RAID (ALL USERS)
# ==========================================
@Client.on_message(filters.command(["stopraid", ], prefixes=[".", "!", "/"]) & filters.me)
async def stop_raid(client, message: Message):
    if RAID_STATUS.get(message.chat.id, False):
        RAID_STATUS[message.chat.id] = False
        await eor(message, f"🛑 **{sm('RAID STOPPED! TARGET DESTROYED')} 💀**")
    else:
        await eor(message, f"⚠️ **{sm('ABE KUCH CHAL HI NAHI RAHA LAUDE')}**")

