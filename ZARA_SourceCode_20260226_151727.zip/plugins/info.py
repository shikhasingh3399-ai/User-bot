import os
import asyncio
from datetime import datetime
import unicodedata
from pyrogram import Client, filters, enums
from pyrogram.types import Message

# 🛠️ CONFIG IMPORT
try:
    from config import OWNER_ID
except ImportError:
    OWNER_ID = 0

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ', '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🧠 STATUS CALCULATOR
# ==========================================
def get_status(user):
    if not user.status:
        return f"{sm('ghost mode')} 👻"
    
    if user.status == enums.UserStatus.ONLINE: return f"{sm('online')} 🟢"
    elif user.status == enums.UserStatus.OFFLINE:
        if user.last_online_date:
            now = datetime.now()
            last_online = user.last_online_date
            diff = now - last_online
            if diff.days > 0: return f"{diff.days} {sm('days ago')} 🔴"
            hours = diff.seconds // 3600
            if hours > 0: return f"{hours} {sm('hours ago')} 🔴"
            minutes = (diff.seconds % 3600) // 60
            return f"{minutes} {sm('mins ago')} 🔴"
        return f"{sm('offline')} 🔴"
    elif user.status == enums.UserStatus.RECENTLY: return f"{sm('recently')} 🟡"
    elif user.status == enums.UserStatus.LAST_WEEK: return f"{sm('last week')} 🟡"
    elif user.status == enums.UserStatus.LAST_MONTH: return f"{sm('last month')} ⚫"
    else: return f"{sm('ghost mode')} 👻"

# ==========================================
# 🆔 COMMAND: GCID (GROUP CHAT ID)
# ==========================================
@Client.on_message(filters.command(["gcid", ], prefixes=[".", "!", "/"]) & filters.me)
async def get_chat_id(client, message: Message):
    chat_id = message.chat.id
    chat_name = message.chat.title or message.chat.first_name or "Unknown Chat"
    
    text = f"🏢 **{sm('CHAT DATABASE EXPOSED')}**\n"
    text += f"━━━━━━━━━━━━━━━━━━━━━\n"
    text += f"🏷️ **{sm('NAME')}**: `{chat_name}`\n"
    text += f"🆔 **{sm('GCID')}**: `{chat_id}`\n"
    text += f"━━━━━━━━━━━━━━━━━━━━━\n"
    text += f"💀 **{sm('ZARA KERNEL')}**"
    
    await eor(message, text)

# ==========================================
# 🆔 COMMAND: ONLY ID (SIMPLE & FAST)
# ==========================================
@Client.on_message(filters.command(["id"], prefixes=[".", "!", "/"]) & filters.me)
async def get_id_only(client, message: Message):
    if message.reply_to_message:
        target = message.reply_to_message.from_user
        target_name = target.first_name if target else "Unknown"
        target_id = target.id if target else "Unknown"
    else:
        target_name = message.from_user.first_name
        target_id = message.from_user.id

    chat_id = message.chat.id

    text = f"🩸 **{sm('TARGET ID EXTRACTED')}**\n"
    text += f"👤 **{target_name[:15]}**: `{target_id}`\n"
    text += f"💬 **{sm('CHAT ID')}**: `{chat_id}`"
    
    await eor(message, text)

# ==========================================
# 🕵️‍♂️ COMMAND: ZARA X-RAY SCANNER
# ==========================================
@Client.on_message(filters.command(["info", ], prefixes=[".", "!", "/"]) & filters.me)
async def xray_scan(client, message: Message):
    target = None
    status_msg = await eor(message, f"⚡ **{sm('INITIALIZING SATELLITE TRACKING...')}**")
    
    try:
        if message.reply_to_message and message.reply_to_message.from_user:
            target = message.reply_to_message.from_user
        elif len(message.command) > 1:
            user_input = message.command[1]
            if user_input.isdigit(): target = await client.get_users(int(user_input))
            else: target = await client.get_users(user_input)
        else:
            target = message.from_user
    except Exception as e:
        return await status_msg.edit(f"❌ **{sm('TARGET LOST')}**: `{e}`")

    if not target:
        return await status_msg.edit(f"⚠️ **{sm('ERROR')}**: `{sm('ENTITY NOT FOUND LUDE')}`")

    # 2. TOXIC HACKING ANIMATION SEQUENCE
    steps = [
        f"🦅 **{sm('TARGET LOCKED')}**: `{target.id}`",
        f"🧬 **{sm('EXTRACTING AUKAAT AND METADATA...')}**",
        f"📂 **{sm('DOWNLOADING POLICE RECORDS...')}**",
        f"💀 **{sm('SYSTEM KI GAND FAAD DI!')}**"
    ]
    for step in steps:
        await status_msg.edit(step)
        await asyncio.sleep(0.3)

    # 3. DEEP DATA MINING
    try:
        user_id = target.id
        full_chat = await client.get_chat(user_id)
        
        photo_id = None
        pfp_count = 0
        try:
            async for photo in client.get_chat_photos(user_id, limit=1):
                photo_id = photo.file_id
                pfp_count = await client.get_chat_photos_count(user_id)
        except: pass

        bio = full_chat.bio.strip() if full_chat.bio else sm("no bio found in database")
        
        try:
            common = await client.get_common_chats(user_id)
            common_count = len(common)
        except: common_count = 0

        full_name = f"{target.first_name or ''} {target.last_name or ''}".strip() or "Unknown"
        username = f"@{target.username}" if target.username else sm("no username")
        permalink = f"[{full_name}](tg://user?id={user_id})"
        dc_id = getattr(target, 'dc_id', sm("unknown"))
        
        flags = []
        if target.is_scam: flags.append("⚠️ SCAMMER")
        if target.is_fake: flags.append("🚫 FAKE")
        if target.is_premium: flags.append("💎 PREMIUM")
        if target.is_verified: flags.append("✅ VERIFIED")
        if target.id == OWNER_ID: flags.append("👑 SYSTEM GOD (TERA BAAP)")
        elif target.is_support: flags.append("🛡️ TELEGRAM STAFF")
        elif target.is_bot: flags.append("🤖 BOT")
        
        rank = " | ".join(flags) if flags else sm("civilian")
        threat_level = "CRITICAL 🔴" if target.is_scam or target.is_fake else "LOW 🟢"

        # 4. DOSSIER GENERATION
        report = f"🩸 **{sm('ZARA INTELLIGENCE REPORT')}** 🩸\n"
        report += f"━━━━━━━━━━━━━━━━━━━━━\n"
        
        report += f"👤 **{sm('SUBJECT IDENTITY')}**\n"
        report += f" ├── **{sm('NAME')}** : {permalink}\n"
        report += f" ├── **{sm('UID')}** : `{user_id}`\n"
        report += f" └── **{sm('USERNAME')}** : `{username}`\n\n"
        
        report += f"📡 **{sm('NETWORK TELEMETRY')}**\n"
        report += f" ├── **{sm('DATACENTER')}** : `DC-{dc_id}`\n"
        report += f" ├── **{sm('STATUS')}** : `{get_status(target)}`\n"
        report += f" └── **{sm('COMMON GROUPS')}** : `{common_count}`\n\n"
        
        report += f"🛡️ **{sm('SECURITY AUDIT')}**\n"
        report += f" ├── **{sm('RANK')}** : `{rank}`\n"
        report += f" ├── **{sm('THREAT LEVEL')}** : `{threat_level}`\n"
        report += f" └── **{sm('PROFILE PICS')}** : `{pfp_count}`\n\n"
        
        report += f"📝 **{sm('BIO LOG')}**\n`{bio[:100]}`\n" 
        
        report += f"━━━━━━━━━━━━━━━━━━━━━\n"
        report += f"💀 **{sm('GENERATED BY ZARA BOTNET')}**"

        # 5. UPLOAD PROTOCOL
        if photo_id:
            await status_msg.edit(f"📸 **{sm('DOWNLOADING VISUAL EVIDENCE...')}**")
            try:
                await client.send_photo(message.chat.id, photo_id, caption=report)
                await status_msg.delete()
            except:
                try:
                    path = await client.download_media(photo_id)
                    await client.send_photo(message.chat.id, path, caption=report)
                    await status_msg.delete()
                    if os.path.exists(path): os.remove(path)
                except Exception:
                    await status_msg.edit(report, disable_web_page_preview=True)
        else:
            await status_msg.edit(report, disable_web_page_preview=True)

    except Exception as e:
        await status_msg.edit(f"❌ **{sm('SYSTEM CRASH')}**: `{e}`")

