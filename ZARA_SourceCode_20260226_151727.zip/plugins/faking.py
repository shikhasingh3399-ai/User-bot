import os
import asyncio
import unicodedata
from pyrogram import Client, filters, enums
from pyrogram.types import Message

# ==========================================
# 🎨 ZARA HACKER FONT ENGINE (iOS MEDIUM)
# ==========================================
def sm(text):
    if not text: return ""
    text = str(text)
    normalized = unicodedata.normalize('NFKC', text)
    mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
    return "".join(mapping.get(c.lower(), c) for c in normalized)

# Dictionary to keep track of active fake actions
ACTIVE_ACTIONS = {}

# ==========================================
# 👁️‍🗨️ 1. THE GHOST STEALER V2 (.steal)
# ==========================================
@Client.on_message(filters.command("steal", prefixes=".") & filters.me)
async def zara_steal(client: Client, message: Message):
    if not message.reply_to_message:
        return await message.edit(sm("❌ error: reply to a message, media, or sticker to steal it."))
    
    target_msg = message.reply_to_message
    anim = await message.edit("`[ ◐ ]` " + sm("bypassing security protocols..."))
    
    # 🕵️‍♂️ Extracting Target Data (Who sent it and from where)
    sender = target_msg.from_user.first_name if target_msg.from_user else "Unknown Ghost"
    chat_name = message.chat.title if message.chat.title else "Private Vault"
    
    # 🗄️ Creating the Dossier (Spy Report)
    dossier = (
        f"💀 **{sm('target compromised')}** 💀\n"
        f"━━━━━━━━━━━━━━━\n"
        f"👤 **{sm('sender')}**: `{sender}`\n"
        f"🌐 **{sm('source')}**: `{chat_name}`\n"
    )

    try:
        await asyncio.sleep(0.5)
        await anim.edit("`[ ◓ ]` " + sm("extracting payload..."))
        
        # 📝 IF TARGET IS JUST TEXT
        if target_msg.text:
            stolen_text = f"{dossier}\n💬 **{sm('message')}**:\n`{target_msg.text}`"
            await client.send_message("me", stolen_text)
            await anim.edit(sm("✅ text payload successfully hijacked to your vault."))
            
        # 📸 IF TARGET IS MEDIA / STICKER / GIF
        elif target_msg.media:
            file_path = await client.download_media(target_msg)
            
            if not file_path:
                return await anim.edit(sm("❌ error: extraction failed. payload encrypted."))

            await anim.edit("`[ ◑ ]` " + sm("uploading to secure vault (saved messages)..."))
            
            # Forwarding to Saved Messages based on Media Type
            if target_msg.photo:
                await client.send_photo("me", photo=file_path, caption=dossier)
            elif target_msg.video:
                await client.send_video("me", video=file_path, caption=dossier)
            elif target_msg.animation: # GIF Support
                await client.send_animation("me", animation=file_path, caption=dossier)
            elif target_msg.sticker: # Sticker Support (Sends dossier first, then sticker)
                await client.send_message("me", dossier)
                await client.send_sticker("me", sticker=file_path)
            elif target_msg.voice:
                await client.send_voice("me", voice=file_path, caption=dossier)
            elif target_msg.audio:
                await client.send_audio("me", audio=file_path, caption=dossier)
            else:
                await client.send_document("me", document=file_path, caption=dossier)
                
            os.remove(file_path) # Clean up local server storage
            await anim.edit(sm("✅ media payload successfully hijacked and saved to your vault."))
            
        else:
            return await anim.edit(sm("❌ error: unsupported payload type."))

        # 👻 Ghost Stealth - Delete the command without a trace
        await asyncio.sleep(1.5)
        await anim.delete() 

    except Exception as e:
        await anim.edit(sm(f"❌ critical failure: {e}"))

# ==========================================
# 🎭 2. PSYCHOLOGICAL WARFARE (FAKE ACTIONS)
# ==========================================
async def fake_action_task(client, chat_id, action, duration):
    try:
        for _ in range(duration // 5): 
            if not ACTIVE_ACTIONS.get(chat_id):
                break
            await client.send_chat_action(chat_id, action)
            await asyncio.sleep(5)
    except:
        pass
    finally:
        ACTIVE_ACTIONS[chat_id] = False

@Client.on_message(filters.command(["faketype", ], prefixes=".") & filters.me)
async def fake_typing(client: Client, message: Message):
    duration = 60 
    if len(message.command) > 1 and message.command[1].isdigit():
        duration = int(message.command[1])
        
    chat_id = message.chat.id
    ACTIVE_ACTIONS[chat_id] = True
    
    await message.edit(sm(f"👻 ghost typing activated for {duration}s. use .fakestop to halt."))
    await asyncio.sleep(1.5)
    await message.delete() 
    
    asyncio.create_task(fake_action_task(client, chat_id, enums.ChatAction.TYPING, duration))

@Client.on_message(filters.command(["fakevid", ], prefixes=".") & filters.me)
async def fake_video(client: Client, message: Message):
    duration = 60 
    if len(message.command) > 1 and message.command[1].isdigit():
        duration = int(message.command[1])
        
    chat_id = message.chat.id
    ACTIVE_ACTIONS[chat_id] = True
    
    await message.edit(sm(f"🎥 ghost video recording activated for {duration}s. use .fakestop to halt."))
    await asyncio.sleep(1.5)
    await message.delete() 
    
    asyncio.create_task(fake_action_task(client, chat_id, enums.ChatAction.RECORD_VIDEO, duration))

@Client.on_message(filters.command("fakestop", prefixes=".") & filters.me)
async def fake_stop(client: Client, message: Message):
    chat_id = message.chat.id
    ACTIVE_ACTIONS[chat_id] = False
    await client.send_chat_action(chat_id, enums.ChatAction.CANCEL)
    
    anim = await message.edit(sm("🛑 illusions deactivated."))
    await asyncio.sleep(1.5)
    await anim.delete()

