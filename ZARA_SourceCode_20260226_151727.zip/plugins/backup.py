import os
import zipfile
import asyncio
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🔐 ZARA SYSTEM: ABSOLUTE OWNER BACKUP 
# ==========================================

# 🔥 YAHAN APNI MAIN ACCOUNT KI ID DAAL (Jiske bina backup na nikle)
OWNER_ID = 8322992273  # Ise badal kar apni real ID daal dena

def sm(text):
    if not text: return ""
    normal = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    small_caps = "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"
    table = str.maketrans(normal, small_caps)
    return text.translate(table)

@Client.on_message(filters.command("backup", prefixes=[".", "/", "!"]))
async def smart_backup(client: Client, message: Message):
    
    # 🛑 THE RUTHLESS SECURITY CHECK (Abuse system for others)
    if message.from_user.id != OWNER_ID:
        gali_msg = (
            "🤬 **[ ᴀᴄᴄᴇꜱꜱ ᴅᴇɴɪᴇᴅ : ꜰᴜᴄᴋ ᴏꜰꜰ ]** 🤬\n\n"
            "ʙᴇᴛᴇ, ᴛᴇʀɪ ᴀᴜᴋᴀᴀᴛ ɴᴀʜɪ ʜᴀɪ **ᴢᴀʀᴀ ᴍᴀᴛʀɪx** ᴋᴀ ꜱᴏᴜʀᴄᴇ ᴄᴏᴅᴇ ʜᴀᴀᴛʜ ʟᴀɢᴀɴᴇ ᴋɪ!\n"
            "ʙᴀᴀᴩ ᴋᴏ ʜᴀᴄᴋ ᴋᴀʀɴᴇ ᴄʜᴀʟᴀ ᴛʜᴀ ʟᴏᴅᴇ? ᴛᴇʀᴀ ɪᴩ ᴀᴜʀ ɪᴅ ᴅᴏɴᴏ ʀᴀᴅᴀʀ ᴩᴇ ᴀᴀ ᴄʜᴜᴋᴇ ʜᴀɪɴ.\n\n"
            "🩸 **ᴡᴀʀɴɪɴɢ:** ᴀɢʟɪ ʙᴀᴀʀ ʏᴇ ᴄᴏᴍᴍᴀɴᴅ ᴅᴀᴀʟᴀ, ᴛᴏ ꜱᴇꜱꜱɪᴏɴ ᴛᴏ ᴜᴅᴇɢᴀ ʜɪ, ꜱᴀᴀᴛʜ ᴍᴇ ᴅᴇᴠɪᴄᴇ ʙʜɪ ᴄʀᴀꜱʜ ᴋᴀʀᴜɴɢᴀ! ɴɪᴋᴀʟ ʏᴀʜᴀɴ ꜱᴇ! 🖕💀"
        )
        return await message.reply_text(gali_msg)

    # ==========================================
    # ✅ ORIGINAL BACKUP LOGIC STARTS HERE
    # ==========================================
    msg = await message.reply_text(f"🔄 **{sm('ZARA SYSTEM BACKUP INITIATED...')}**\n(Scanning editable files)")

    # Zip file ka naam time ke hisaab se banega
    time_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_filename = f"ZARA_SourceCode_{time_str}.zip"
    
    # 🚫 IN FOLDERS KO IGNORE KAREGA
    exclude_dirs = ["__pycache__", ".git", "downloads", "session", "venv", "env", "node_modules"]
    
    # ✅ SIRF IN EXTENSIONS KO BACKUP KAREGA (Teri editable files)
    allowed_exts = [".py", ".env", ".md"] 

    try:
        # Zip file create karna shuru
        with zipfile.ZipFile(backup_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk("."):
                dirs[:] = [d for d in dirs if d not in exclude_dirs]
                
                for file in files:
                    ext = os.path.splitext(file)[1]
                    if ext in allowed_exts and file != "requirements.txt":
                        filepath = os.path.join(root, file)
                        zipf.write(filepath, os.path.relpath(filepath, "."))
        
        await msg.edit(f"⬆️ **{sm('UPLOADING TO SAVED MESSAGES...')}**\n(Securing the Vault)")
        
        caption = (
            f"📂 **{sm('ZARA BOTNET BACKUP')}**\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"👤 **{sm('Owner')}:** {message.from_user.mention}\n"
            f"📅 **{sm('Date')}:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`\n"
            f"🛡️ **{sm('Status')}:** `Secured & Encrypted`\n"
            f"⚠️ **{sm('Note')}:** _Contains only editable core files._"
        )
        
        # Send direct to "Saved Messages" of the Owner
        await client.send_document(
            chat_id="me", 
            document=backup_filename, 
            caption=caption
        )
        
        await msg.edit(f"✅ **{sm('BACKUP SUCCESSFUL!')}**\n🔐 Check your Saved Messages.")
        
    except Exception as e:
        await msg.edit(f"❌ **{sm('BACKUP FAILED')}:** `{str(e)}`")
    
    finally:
        # 🧹 CLEANUP
        if os.path.exists(backup_filename):
            os.remove(backup_filename)

