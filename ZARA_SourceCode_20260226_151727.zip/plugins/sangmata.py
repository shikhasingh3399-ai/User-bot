import asyncio
import re
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

# ==========================================
# 🕵️‍♂️ SANGMATA ELITE INTERCEPTOR (OWNER ONLY)
# ==========================================
SANG_BOT = "SangMata_BOT" 

@Client.on_message(filters.command(["sg", "history"], prefixes=".") & filters.me)
async def sangmata_ultimate(client, message: Message):
    target_id = None
    
    if message.reply_to_message:
        target_id = message.reply_to_message.from_user.id
    elif len(message.command) > 1:
        user_input = message.command[1]
        try:
            if user_input.lstrip('-').isdigit():
                target_id = int(user_input)
            else:
                user = await client.get_users(user_input)
                target_id = user.id
        except Exception:
            return await message.edit(f"❌ **{sm('target error')}**: `User not found or invalid format.`")
    else:
        target_id = message.from_user.id

    status = await message.edit(f"📡 **{sm('tracking neural signal')}...**")

    try:
        # 2. DEEP INTEL EXTRACTION
        try:
            user_info = await client.get_users(target_id)
            full_chat = await client.get_chat(target_id)
            
            # 🔥 THE FIX IS HERE: Agar bio None hai to auto-handle karega
            bio = full_chat.bio if full_chat.bio else "No Bio Found"
            
        except Exception:
            return await status.edit(f"❌ **{sm('error')}**: `Cannot extract data for this ID.`")

        name = f"{user_info.first_name or ''} {user_info.last_name or ''}".strip()
        dc_id = getattr(user_info, "dc_id", "Unknown")
        
        is_premium = "✅ YES" if getattr(user_info, "is_premium", False) else "❌ NO"
        is_scam = "⚠️ YES (SCAMMER)" if getattr(user_info, "is_scam", False) else "❌ NO"
        is_fake = "⚠️ YES (FAKE)" if getattr(user_info, "is_fake", False) else "❌ NO"

        # 3. SANGMATA DROP PROTOCOL
        await client.unblock_user(SANG_BOT)
        sent = await client.send_message(SANG_BOT, f"{target_id}")
        
        response = None
        for _ in range(12): 
            await asyncio.sleep(0.5)
            async for log in client.get_chat_history(SANG_BOT, limit=1):
                if log.id > sent.id: 
                    response = log
                    break
            if response: break
        
        try: 
            if response: await client.delete_messages(SANG_BOT, [sent.id, response.id])
            else: await client.delete_messages(SANG_BOT, [sent.id])
        except: pass
        
        if not response:
            return await status.edit(f"❌ **{sm('timeout')}**: `SangMata servers are down or slow.`")

        # 4. DATA PARSING 
        raw = response.text or ""
        names, usernames = [], []
        
        if "No records found" in raw or "didn't change" in raw:
            names.append(" └─ `No History Found`")
        else:
            lines = raw.split('\n')
            mode = "NAME"
            for line in lines:
                if "Username" in line: mode = "USER"; continue
                match = re.search(r'\d+\.\s\[(.*?)\]\s(.*)', line)
                if match:
                    date = match.group(1).split()[0]
                    content = match.group(2).strip()
                    entry = f"`{content}` • {date}"
                    if mode == "NAME": names.append(entry)
                    else: usernames.append(entry)

        # 5. GENERATE DOSSIER
        report = f"🩸 **{sm('IDENTITY AUTOPSY REPORT')}** 🩸\n"
        report += f"━━━━━━━━━━━━━━━━━━━━\n"
        report += f"👤 **{sm('subject')}** : [{name}](tg://user?id={target_id})\n"
        report += f"🆔 **{sm('uid')}** : `{target_id}`\n"
        report += f"🌐 **{sm('data center')}** : `DC-{dc_id}`\n"
        report += f"💎 **{sm('premium')}** : `{is_premium}`\n"
        
        if "YES" in is_scam or "YES" in is_fake:
            report += f"🚨 **{sm('threat level')}** : `SCAM/FAKE DETECTED`\n"
            
        report += f"📝 **{sm('bio')}** : `{bio[:60]}...`\n\n" if len(bio) > 60 else f"📝 **{sm('bio')}** : `{bio}`\n\n"
        
        report += f"📜 **{sm('name history')}**\n"
        if names:
            for i, n in enumerate(names[:6]): 
                p = " └─ " if i == len(names[:6])-1 else " ├─ "
                report += f"{p}{n}\n"
        else: report += " └─ `Clean` \n"

        if usernames:
            report += f"\n🏷️ **{sm('username history')}**\n"
            for i, u in enumerate(usernames[:4]): 
                p = " └─ " if i == len(usernames[:4])-1 else " ├─ "
                report += f"{p}{u}\n"

        report += f"━━━━━━━━━━━━━━━━━━━━\n"
        report += f"💀 **{sm('zara kernel active')}**"

        await status.edit(report, disable_web_page_preview=True)

    except Exception as e:
        await status.edit(f"❌ **{sm('critical error')}**: `{str(e)[:50]}`")

