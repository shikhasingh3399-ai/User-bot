import asyncio
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait

# 🛠️ CONFIG IMPORT (Sirf Owner)
try:
    from config import OWNER_ID
except ImportError:
    pass

# ==========================================
# 🛑 GLOBAL CONTROLLER (STOP SWITCH)
# ==========================================
TAG_SESSIONS = {}

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🧠 TAGGING ENGINE (THE BRAIN)
# ==========================================
async def tag_engine(client: Client, message: Message, batch_size: int):
    chat_id = message.chat.id
    
    # 1. STATUS CHECK
    if TAG_SESSIONS.get(chat_id):
        return await eor(message, f"⚠️ **{sm('system busy')}**: `{sm('process already active')}`")
    
    TAG_SESSIONS[chat_id] = True
    
    # 2. INPUT ANALYSIS
    tag_content = f"👋 **{sm('wake up everyone')}**"
    reply_id = None
    
    if message.reply_to_message:
        reply_id = message.reply_to_message.id
        
    if len(message.command) > 1:
        tag_content = message.text.split(None, 1)[1]
    elif message.reply_to_message and message.reply_to_message.text:
        tag_content = message.reply_to_message.text

    # 3. HACKER ANIMATION
    status_msg = await eor(message, f"⚡ **{sm('initializing zara protocol')}...**")
    await asyncio.sleep(1)
    try: await status_msg.delete()
    except: pass

    # 4. MEMBER HARVESTING & TAGGING
    members_list = []
    msg_counter = 0 
    
    try:
        async for member in client.get_chat_members(chat_id):
            if not TAG_SESSIONS.get(chat_id): break
            if member.user.is_bot or member.user.is_deleted: continue
            
            members_list.append(member.user)
            
            if len(members_list) == batch_size:
                mentions = " ".join([f"[{user.first_name}](tg://user?id={user.id})" for user in members_list])
                final_text = f"{tag_content}\n\n{mentions}"
                
                try:
                    if reply_id: await client.send_message(chat_id, final_text, reply_to_message_id=reply_id)
                    else: await client.send_message(chat_id, final_text)
                    
                    msg_counter += 1
                    members_list = [] 
                    
                    # === 🛡️ LIMIT BYPASS SYSTEM ===
                    if msg_counter % 70 == 0:
                        warn = await client.send_message(chat_id, f"🛑 **{sm('limit protect active')}**\n`{sm('cooling down for 60s to prevent ban...')}`")
                        await asyncio.sleep(60) 
                        try: await warn.delete()
                        except: pass
                    else:
                        await asyncio.sleep(1.5) 
                        
                except FloodWait as e:
                    await asyncio.sleep(e.value + 5)
                except Exception: pass

        # Leftover Fix
        if members_list and TAG_SESSIONS.get(chat_id):
            mentions = " ".join([f"[{user.first_name}](tg://user?id={user.id})" for user in members_list])
            final_text = f"{tag_content}\n\n{mentions}"
            try:
                if reply_id: await client.send_message(chat_id, final_text, reply_to_message_id=reply_id)
                else: await client.send_message(chat_id, final_text)
            except: pass

    except Exception as e:
        print(f"Tagging Error: {e}")

    # 5. CLEANUP
    TAG_SESSIONS[chat_id] = False
    try:
        await client.send_message(chat_id, f"✅ **{sm('tagging sequence completed')}**")
    except: pass

# ==========================================
# 🎮 COMMANDS (STRICTLY OWNER ONLY: filters.me)
# ==========================================

@Client.on_message(filters.command(["tag1", ], prefixes=[".", "!", "/"]) & filters.me)
async def tag_one(client, message):
    await tag_engine(client, message, batch_size=1)

@Client.on_message(filters.command(["tag3", ], prefixes=[".", "!", "/"]) & filters.me)
async def tag_three(client, message):
    await tag_engine(client, message, batch_size=3)

@Client.on_message(filters.command(["tag5", ], prefixes=[".", "!", "/"]) & filters.me)
async def tag_five(client, message):
    await tag_engine(client, message, batch_size=5)

@Client.on_message(filters.command(["stoptagall", ], prefixes=[".", "!", "/"]) & filters.me)
async def stop_tagging(client, message):
    if not TAG_SESSIONS.get(message.chat.id):
        return await message.edit(f"⚠️ **{sm('system idle')}**: `{sm('no active sequence')}`")
    
    TAG_SESSIONS[message.chat.id] = False
    await message.edit(f"🛑 **{sm('sequence terminated')}**\n`{sm('tagging stopped successfully')}`")

