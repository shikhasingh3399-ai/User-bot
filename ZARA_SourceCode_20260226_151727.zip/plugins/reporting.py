import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message

# 👑 ZARA SYSTEM OWNER
OWNER_ID = 8036881129

# ==========================================
# 💀 THE NIGHTMARE ILLUSION (ADVANCED FAKE REPORT)
# ==========================================
@Client.on_message(filters.command("report", prefixes=".") & filters.me)
async def fake_report(client: Client, message: Message):
    
    # 🎯 Agar Owner bina reply kiye use kare
    if not message.reply_to_message:
        return await message.edit_text("❌ **[ᴇʀʀᴏʀ]** Tᴀʀɢᴇᴛ Lᴏᴄᴋ ғᴀɪʟᴇᴅ. Rᴇᴘʟʏ ᴛᴏ ᴀ ᴍᴇssᴀɢᴇ.")

    # 🕵️‍♂️ Fetching REAL Data for max psychological impact
    target = message.reply_to_message.from_user
    msg_id = message.reply_to_message.id
    
    t_name = target.first_name or "Unknown"
    t_id = target.id
    dc_id = target.dc_id or "Unknown" # Fetches the target's Telegram Datacenter

    msg = await message.edit_text(f"⚙️ `[ ᴢᴀʀᴀ ᴋᴇʀɴᴇʟ ] ɪɴɪᴛɪᴀᴛɪɴɢ ᴛᴀʀɢᴇᴛᴇᴅ ʀᴇᴘᴏʀᴛ sᴇǫᴜᴇɴᴄᴇ...`")

    # 🚀 The Terminal Hacking Animation (Upgraded with Real Data variables)
    steps = [
        f"📡 `Pɪɴɢɪɴɢ Tᴇʟᴇɢʀᴀᴍ Aʙᴜsᴇ API... [████░░░░░░] 40%`\n🎯 `Tᴀʀɢᴇᴛ Lᴏᴄᴋᴇᴅ:` **{t_name}** (`{t_id}`)\n🗄️ `Dᴀᴛᴀ Cᴇɴᴛᴇʀ Lᴏᴄᴀᴛᴇᴅ:` **DC{dc_id}**",
        
        f"🌐 `Rᴏᴜᴛɪɴɢ 24x Nᴏᴅᴇs ᴛᴏ Mᴇssᴀɢᴇ ɪᴅ: #{msg_id}... [████████░░] 80%`",
        
        f"🚨 `Iɴᴊᴇᴄᴛɪɴɢ ᴀʙᴜsᴇ ᴘᴀʏʟᴏᴀᴅs ᴀɢᴀɪɴsᴛ {target.mention}...`\n\n"
        f" ├─ ⚠️ `Vɪᴏʟᴀᴛɪᴏɴ:` Sᴘᴀᴍ & Aʙᴜsᴇ [Iɴᴊᴇᴄᴛᴇᴅ ✅]\n"
        f" ├─ ⚠️ `Vɪᴏʟᴀᴛɪᴏɴ:` Iʟʟᴇɢᴀʟ Cᴏɴᴛᴇɴᴛ [Iɴᴊᴇᴄᴛᴇᴅ ✅]\n"
        f" └─ ⚠️ `Vɪᴏʟᴀᴛɪᴏɴ:` TᴏS Bʀᴇᴀᴄʜ [Iɴᴊᴇᴄᴛᴇᴅ ✅]",
        
        f"☠️ **[ ᴍ ᴀ s s  ʀ ᴇ ᴘ ᴏ ʀ ᴛ  s ᴜ ᴄ ᴄ ᴇ s s ]** ☠️\n\n"
        f"🎯 **Tᴀʀɢᴇᴛ:** {target.mention} (`{t_id}`)\n"
        f"🛡️ **Sᴛᴀᴛᴜs:** Fʟᴀɢɢᴇᴅ ʙʏ ZARA Cᴏʀᴇ.\n"
        f"⏳ **Aᴄᴛɪᴏɴ:** Rᴇᴘᴏʀᴛ ɪᴅ #77382 Rᴇɢɪsᴛᴇʀᴇᴅ.\n"
        f"⚰️ `Aᴄᴄᴏᴜɴᴛ sᴜsᴘᴇɴsɪᴏɴ ɪᴍᴍɪɴᴇɴᴛ.`"
    ]

    for step in steps:
        await asyncio.sleep(2.0) # Thoda suspense build karne ke liye time
        await msg.edit_text(step)

