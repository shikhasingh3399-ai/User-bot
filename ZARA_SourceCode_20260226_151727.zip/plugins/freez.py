import asyncio
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 💀 ZARA HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# ❄️ COMMAND: WALL OF TEXT (CHAT CHOKER)
# ==========================================
@Client.on_message(filters.command(["freezegc", ], prefixes=[".", "!", "/"]) & filters.me)
async def freeze_group(client, message: Message):
    anim = await eor(message, f"⚡ **{sm('initializing system overload...')}**")
    await asyncio.sleep(0.4)
    await anim.edit(f"🧬 **{sm('compiling dharma payload...')}**")
    await asyncio.sleep(0.4)
    
    # 🚨 THE NEW TEXT PAYLOAD 🚨
    base_text = "जय श्री राम 🚩 जय श्री महाकाल 💀 | "
    # Telegram max length is 4096. Adjusting payload to fit safely.
    payload = (base_text * 150)[:4000] 
    
    text = f"💀 **{sm('zara grid protocol active')}** 💀\n\n{payload}"
    
    try:
        await anim.edit(f"☠️ **{sm('payload injected! gc is choked.')}**")
        await client.send_message(message.chat.id, text)
    except Exception as e:
        await anim.edit(f"❌ **{sm('system error')}**: `{e}`")

# ==========================================
# 💥 COMMAND: BOMB GC (LAG SPAMMER)
# ==========================================
@Client.on_message(filters.command(["bombgc", ], prefixes=[".", "!", "/"]) & filters.me)
async def lag_spammer(client, message: Message):
    if len(message.command) < 2:
        return await eor(message, f"⚠️ **{sm('usage')}**: `.bombgc <number>`")
        
    try:
        count = int(message.command[1])
    except:
        return await eor(message, f"❌ **{sm('ginti daal laude!')}**")

    await eor(message, f"🔥 **{sm('zara lag spammer activated')}!**\n`{sm('sending')} {count} {sm('payloads...')}`")
    
    base_text = "जय श्री राम 🚩 जय श्री महाकाल 💀 | "
    payload = (base_text * 150)[:4000]
    
    sent_count = 0
    for _ in range(count):
        try:
            await client.send_message(message.chat.id, payload)
            sent_count += 1
            await asyncio.sleep(0.1) 
        except:
            await asyncio.sleep(1)

# ==========================================
# 🧹 COMMAND: UNFREEZE (TACTICAL CLEANUP)
# ==========================================
@Client.on_message(filters.command(["unfreeze", ], prefixes=[".", "!", "/"]) & filters.me)
async def clean_lag(client, message: Message):
    anim = await eor(message, f"🧹 **{sm('initiating tactical cleanup...')}**")
    deleted_count = 0
    
    try:
        # Pura chat history scan karega (last 50 messages)
        async for msg in client.get_chat_history(message.chat.id, limit=50):
            # Sirf apne messages dhundega jisme naya payload hai
            if msg.from_user and msg.from_user.is_self:
                if "जय श्री राम" in str(msg.text) or "जय श्री महाकाल" in str(msg.text):
                    await msg.delete()
                    deleted_count += 1
                    await asyncio.sleep(0.1) # Delete karne me floodwait na aaye
                    
        if deleted_count > 0:
            await anim.edit(f"✅ **{sm('grid cleared!')}** `{deleted_count} {sm('payloads destroyed. back to normal.')}`")
        else:
            await anim.edit(f"⚠️ **{sm('no active payloads found here.')}**")
            
    except Exception as e:
        await anim.edit(f"❌ **{sm('cleanup error')}**: `{e}`")


