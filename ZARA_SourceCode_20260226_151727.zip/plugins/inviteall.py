import asyncio
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import (
    UserPrivacyRestricted, UserNotMutualContact, 
    ChatAdminRequired, FloodWait, PeerIdInvalid, UserAlreadyParticipant
)

# ==========================================
# 🎨 ZARA HACKER FONT ENGINE 
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

# ==========================================
# ➕ 1. SINGLE INVITE ENGINE (.invite)
# ==========================================
@Client.on_message(filters.command("invite", prefixes=".") & filters.me)
async def single_invite(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.edit(f"⚠️ **{sm('usage')}**: `.invite @username` {sm('or')} `ID`")

    target = message.command[1]
    msg = await message.edit(f"⏳ `{sm('extracting user data and forcing invite...')} `")

    try:
        # Convert to int if it's a numeric ID
        if target.lstrip('-').isdigit():
            target = int(target)

        await client.add_chat_members(message.chat.id, target)
        await msg.edit(f"✅ **{sm('target successfully added to the grid!')}**\n👤 **User:** `{target}`")

    except UserPrivacyRestricted:
        await msg.edit(f"❌ **{sm('failed')}**: {sm('user privacy settings prevent inviting.')}")
    except UserNotMutualContact:
        await msg.edit(f"❌ **{sm('failed')}**: {sm('mutual contact required to add this user.')}")
    except ChatAdminRequired:
        await msg.edit(f"❌ **{sm('failed')}**: {sm('i need admin rights to add members here!')}")
    except UserAlreadyParticipant:
        await msg.edit(f"⚠️ **{sm('notice')}**: {sm('user is already in this chat.')}")
    except Exception as e:
        await msg.edit(f"❌ **{sm('system error')}**: `{e}`")

# ==========================================
# ☢️ 2. MASS INVITE ENGINE (.inviteall)
# ==========================================
@Client.on_message(filters.command("inviteall", prefixes=".") & filters.me)
async def mass_invite(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.edit(f"⚠️ **{sm('usage')}**: `.inviteall @user1 @user2 123456...`")

    # Extract all users from the command
    targets = message.command[1:]
    msg = await message.edit(f"⚙️ `{sm('initiating mass invite protocol...')} `\n👥 **Targets:** `{len(targets)}`")

    added_count = 0
    failed_count = 0

    for target in targets:
        try:
            if target.lstrip('-').isdigit():
                target = int(target)
                
            await client.add_chat_members(message.chat.id, target)
            added_count += 1
            
            # 🛡️ SIGMA ANTI-BAN DELAY (Very Important to prevent account ban)
            await asyncio.sleep(2) 

        except FloodWait as e:
            await msg.edit(f"⚠️ `{sm('telegram anti-spam triggered! sleeping for')} {e.value}s...`")
            await asyncio.sleep(e.value + 1)
            # Try once more after sleeping
            try:
                await client.add_chat_members(message.chat.id, target)
                added_count += 1
            except: failed_count += 1
            
        except Exception:
            failed_count += 1
            pass # Ignore other errors and continue looping

    await msg.edit(
        f"☢️ **{sm('mass invite complete')}** ☢️\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"✅ **{sm('successfully added')}**: `{added_count}`\n"
        f"❌ **{sm('failed / blocked')}**: `{failed_count}`"
    )

# ==========================================
# 💬 3. QUOTLY MAKER (.q or .quotly)
# ==========================================
@Client.on_message(filters.command(["q", "quotly"], prefixes=".") & filters.me)
async def make_quote(client: Client, message: Message):
    if not message.reply_to_message:
        return await message.edit(f"❌ **{sm('error')}**: {sm('reply to a message to make a quote!')}")

    anim = await message.edit(f"💬 `{sm('connecting to quotly api...')} `")
    
    try:
        await client.unblock_user("QuotLyBot")
    except:
        pass

    try:
        # Step 1: Forward the target message to QuotLyBot
        await message.reply_to_message.forward("QuotLyBot")
        await anim.edit(f"⏳ `{sm('generating sticker...')} [▓▓▓▓░░]`")
        
        # Step 2: Wait for QuotLyBot to process
        await asyncio.sleep(3)
        
        # Step 3: Fetch the generated sticker
        sticker_found = False
        async for msg in client.get_chat_history("QuotLyBot", limit=3):
            if msg.sticker:
                # Send the sticker to the current group
                await message.reply_sticker(msg.sticker.file_id)
                sticker_found = True
                break
                
        if sticker_found:
            await anim.delete() # Delete the loading message
        else:
            await anim.edit(f"❌ **{sm('failed')}**: {sm('quotly bot did not respond in time.')}")

    except Exception as e:
        await anim.edit(f"❌ **{sm('quotly engine crashed')}**: `{e}`")

