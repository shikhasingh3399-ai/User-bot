import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🚁 1. HELICOPTER COMMAND (Dynamic Name)
# ==========================================
@Client.on_message(filters.command("helicopter", prefixes=".") & filters.me)
async def helicopter_art(client: Client, message: Message):
    # Jo command bhej raha hai, uska first name nikal lo
    my_name = message.from_user.first_name if message.from_user.first_name else "ZARA"
    
    # \\ lagaya hai taaki backslash error na de
    heli_art = f"""▬▬▬.◙.▬▬▬ 
═▂▄▄▓▄▄▂ 
◢◤ █▀▀████▄▄▄▄◢◤ 
█▄ █ █▄ ███{my_name}▀▀▀▀╬ 
◥█████◤ 
══╩══╩══ 
╬═╬ 
╬═╬ 
╬═╬ 
╬═╬ 
╬═╬ 
╬═╬ 
╬═╬ ʜᴇʟʟᴏ ʙᴀʙʏ ɪ ᴀᴍ {my_name}:) 
╬═╬☻/ 
╬═╬/▌ 
╬═╬/ \\"""
    
    await message.edit_text(f"`{heli_art}`")


# ==========================================
# 🚶‍♂️ 2. GBUT COMMAND (@Reflex_x_zara branding)
# ==========================================
@Client.on_message(filters.command("gbut", prefixes=".") & filters.me)
async def gbut_art(client: Client, message: Message):
    gbut_text = """┈┈┏━╮╭━┓┈╭━━━━╮
┈┈┃┏┗┛┓┃╭┫@Reflex_x_zara ┃
┈┈╰┓▋▋┏╯╯╰━━━━╯
┈╭━┻╮╲┗━━━━╮╭╮┈
┈┃▎▎┃╲╲╲╲╲╲┣━╯┈
┈╰━┳┻▅╯╲╲╲╲┃┈┈┈
┈┈┈╰━┳┓┏┳┓┏╯┈┈┈
┈┈┈┈┈┗┻┛┗┻┛┈┈┈┈"""
    
    await message.edit_text(f"`{gbut_text}`")


# ==========================================
# 👻 3. Z COMMAND (ZARA Warning)
# ==========================================
@Client.on_message(filters.command("z", prefixes=".") & filters.me)
async def z_art(client: Client, message: Message):
    z_text = """────██──────▀▀▀██
──▄▀█▄▄▄─────▄▀█▄▄▄
▄▀──█▄▄──────█─█▄▄
─▄▄▄▀──▀▄───▄▄▄▀──▀▄
─▀───────▀▀─▀───────▀▀
ɴɪᴋᴀʟ ᴍᴄ😥😥.. ɢᴀᴀʟɪ ɴᴀ ᴅᴇ ᴠᴀʀɴᴀ 𝗭𝗔𝗥𝗔 ᴛᴇʀɪ ɢ**ᴅ ᴍᴀᴀʀ ʟᴇɢᴀ.👻"""
    
    await message.edit_text(f"`{z_text}`")


# ==========================================
# 💍 4. PROPOSE COMMAND (Girl Hard Animation)
# ==========================================
@Client.on_message(filters.command("propose", prefixes=".") & filters.me)
async def propose_animation(client: Client, message: Message):
    # Ladki ke propose karne ke frames
    propose_frames = [
        "👸\n\n`Suno... Mujhe tumse kuch kehna tha...`",
        "👸 🌹\n\n`Bahut time se dil me chhupa ke rakha tha...`",
        "🧎‍♀️ 🌹\n\n`Tum meri life ka sabse special hissa ban gaye ho...`",
        "🧎‍♀️ 💍\n\n`Kya tum mere rahoge? Hamesha ke liye?`",
        "🧎‍♀️ 💍\n\n**I LOVE YOU SO MUCH! 🥺❤️\nWill you be mine forever? 💕**"
    ]
    
    for frame in propose_frames:
        try:
            await message.edit_text(frame)
            await asyncio.sleep(1.2) # Thoda delay taaki ladki ki feeling feel ho sake! 😂
        except:
            pass

