import asyncio
from pyrogram import Client, filters
from pyrogram.enums import ChatMembersFilter, ChatMemberStatus
from pyrogram.types import Message

# ==========================================
# 🕵️‍♂️ ZARA SYSTEM: SCANNER MODULE (CLICKABLE)
# ==========================================

# 1. ADMIN LIST (Clickable Names Ke Sath)
@Client.on_message(filters.command("adminlist", prefixes=".") & filters.group & filters.me)
async def admin_list(client: Client, message: Message):
    msg = await message.edit_text("⚙️ `Sᴄᴀɴɴɪɴɢ Aᴅᴍɪɴ ᴅᴀᴛᴀʙᴀsᴇ...`")
    admins = ""
    count = 0
    try:
        async for member in client.get_chat_members(message.chat.id, filter=ChatMembersFilter.ADMINISTRATORS):
            if not member.user.is_deleted:
                name = member.user.first_name if member.user.first_name else "ZARA Admin"
                # Ye line name ko clickable link bana degi
                mention = f"[{name}](tg://user?id={member.user.id})"
                admins += f" ├─ 👑 {mention}\n"
                count += 1
        
        text = f"🛡️ **ZARA SYSTEM : ADMIN LIST** 🛡️\n\n**Tᴏᴛᴀʟ Aᴅᴍɪɴs:** {count}\n{admins}"
        await msg.edit_text(text)
    except Exception as e:
        await msg.edit_text(f"⚠️ 𝗘𝗿𝗿𝗼𝗿: `{e}`")


# 2. BOT LIST (Clickable Names Ke Sath)
@Client.on_message(filters.command("botlist", prefixes=".") & filters.group & filters.me)
async def bot_list(client: Client, message: Message):
    msg = await message.edit_text("⚙️ `Sᴄᴀɴɴɪɴɢ ꜰᴏʀ ʙᴏᴛs...`")
    bots = ""
    count = 0
    try:
        async for member in client.get_chat_members(message.chat.id, filter=ChatMembersFilter.BOTS):
            name = member.user.first_name if member.user.first_name else "Bot"
            # Bot ka name bhi clickable
            mention = f"[{name}](tg://user?id={member.user.id})"
            bots += f" ├─ 🤖 {mention}\n"
            count += 1
        
        if count == 0:
            return await msg.edit_text("🤖 **ZARA SYSTEM:** Is group me koi bot nahi hai bhai!")
            
        text = f"🤖 **ZARA SYSTEM : BOT LIST** 🤖\n\n**Tᴏᴛᴀʟ Bᴏᴛs:** {count}\n{bots}"
        await msg.edit_text(text)
    except Exception as e:
        await msg.edit_text(f"⚠️ 𝗘𝗿𝗿𝗼𝗿: `{e}`")


# 3. OWNS (Clickable Real Owner)
@Client.on_message(filters.command("owns", prefixes=".") & filters.group & filters.me)
async def find_owner(client: Client, message: Message):
    msg = await message.edit_text("⚙️ `Bʏᴘᴀssɪɴɢ Sᴇᴄᴜʀɪᴛʏ... Lᴏᴄᴀᴛɪɴɢ Rᴇᴀʟ Oᴡɴᴇʀ 💀`")
    owner_info = ""
    
    try:
        async for member in client.get_chat_members(message.chat.id, filter=ChatMembersFilter.ADMINISTRATORS):
            if member.status == ChatMemberStatus.OWNER:
                name = member.user.first_name if member.user.first_name else "Hidden Entity"
                # Owner ka name bhi clickable
                mention = f"[{name}](tg://user?id={member.user.id})"
                uname = f"@{member.user.username}" if member.user.username else "No Username"
                
                owner_info = (
                    f"👑 **ZARA SYSTEM: Rᴇᴀʟ Oᴡɴᴇʀ Fᴏᴜɴᴅ!** 👑\n\n"
                    f" ├─ **Nᴀᴍᴇ:** {mention}\n"
                    f" ├─ **Uɴᴀᴍᴇ:** {uname}\n"
                    f" └─ **ID:** `{member.user.id}`\n\n"
                    f"📍 **Bʏᴘᴀss Cᴏᴍᴘʟᴇᴛᴇ.**"
                )
                break 
        
        if owner_info:
            await asyncio.sleep(1) 
            await msg.edit_text(owner_info)
        else:
            await msg.edit_text("⚠️ **Oᴡɴᴇʀ Nᴏᴛ Fᴏᴜɴᴅ!**\n(Telegram API Backend Privacy is fully active 💀)")
            
    except Exception as e:
        await msg.edit_text(f"⚠️ 𝗘𝗿𝗿𝗼𝗿: `{e}`")

