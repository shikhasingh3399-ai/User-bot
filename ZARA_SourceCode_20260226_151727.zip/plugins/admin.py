import asyncio
import unicodedata
import time
from datetime import datetime, timedelta
from pyrogram import Client, filters, enums
from pyrogram.types import ChatPermissions, Message, ChatPrivileges
from pyrogram.errors import (
    ChatAdminRequired,
    UserAdminInvalid,
    FloodWait,
    PeerIdInvalid
)

# 🛠️ FIXED CONFIG IMPORT
try:
    from config import OWNER_ID, SUDO_USERS
except ImportError:
    try:
        from config import OWNER_ID
        SUDO_USERS = [OWNER_ID]
    except ImportError:
        print("❌ CRITICAL: 'config.py' not found!")
        exit(1)

# ==========================================
# 🎨 SYSTEM FONT & STYLE ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ', '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except:
        return text

# ==========================================
# 🧠 UTILITY FUNCTIONS
# ==========================================
async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self:
            return await message.edit(text)
        else:
            return await message.reply(text)
    except:
        return await message.reply(text)

def extract_time(time_val):
    if any(time_val.endswith(unit) for unit in ('m', 'h', 'd')):
        unit = time_val[-1]
        try:
            time_num = int(time_val[:-1])  
            if unit == 'm': return time_num * 60
            elif unit == 'h': return time_num * 3600
            elif unit == 'd': return time_num * 86400
        except: return None
    return None

async def sys_exec(message, command_name):
    msg = await eor(message, f"⚡ `[SYSTEM]` **{sm('initializing')}...**")
    if message.from_user.is_self:
        logs = [
            f"🔄 **{sm('verifying privileges')}...**",
            f"🔓 **{sm('bypassing security')}...**",
            f"💀 **{sm(f'executing {command_name}')}...**"
        ]
        for log in logs:
            await msg.edit(log)
            await asyncio.sleep(0.2)
    return msg

# ==========================================
# ⚔️ ADMIN MODULES (SUDO & OWNER)
# ==========================================

# 1. 🚫 BAN & TBAN
@Client.on_message(filters.command(["ban", "tban"], prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def ban_handler(client, message: Message):
    cmd = message.command[0]
    target = None
    time_val = None
    reason = "ɴᴏ ʀᴇᴀsᴏɴ"
    until_date = None
    display_time = "ᴘᴇʀᴍᴀɴᴇɴᴛ"

    try:
        if message.reply_to_message:
            target = message.reply_to_message.from_user
            if cmd == "tban":
                if len(message.command) > 1:
                    time_val = message.command[1]
                    if len(message.command) > 2: reason = message.text.split(None, 2)[2]
            else:
                if len(message.command) > 1: reason = message.text.split(None, 1)[1]
        
        elif len(message.command) > 1:
            input_str = message.command[1]
            try:
                if input_str.lstrip('-').isdigit():
                    target = await client.get_users(int(input_str))
                else:
                    target = await client.get_users(input_str)
            except: pass
            
            if target and cmd == "tban":
                if len(message.command) > 2:
                    time_val = message.command[2]
                    if len(message.command) > 3: reason = message.text.split(None, 3)[3]
            elif target:
                if len(message.command) > 2: reason = message.text.split(None, 2)[2]
    except Exception as e:
        return await eor(message, f"⚠️ **{sm('error parsing command')}**: `{e}`")

    if not target:
        return await eor(message, f"⚠️ **{sm('target not found')}**")

    if target.id == OWNER_ID or target.id in SUDO_USERS:
        return await eor(message, f"🛡️ **{sm('access denied')}**: {sm('cannot ban admin node')}")

    if cmd == "tban":
        if not time_val: return await eor(message, f"⚠️ **{sm('specify time')}**: `.tban 1m`")
        seconds = extract_time(time_val)
        if not seconds: return await eor(message, f"❌ **{sm('invalid format')}**: `1m, 1h, 1d`")
        until_date = datetime.now() + timedelta(seconds=seconds)
        display_time = sm(time_val)

    status_msg = await sys_exec(message, "ban_protocol")
    
    try:
        # 🔥 THE FIX: Agar permanent ban hai to until_date mat bhejo
        if until_date:
            await client.ban_chat_member(message.chat.id, target.id, until_date=until_date)
        else:
            await client.ban_chat_member(message.chat.id, target.id)
            
        txt = f"🚫 **{sm('target terminated')}**\n"
        txt += f"━━━━━━━━━━━━━━━━━━\n"
        txt += f"👤 **{sm('user')}**: {target.mention}\n"
        txt += f"🆔 **{sm('uid')}**: `{target.id}`\n"
        txt += f"⏳ **{sm('duration')}**: `{display_time}`\n"
        txt += f"📝 **{sm('reason')}**: `{sm(reason)}`"
        
        await status_msg.edit(txt)
    except Exception as e:
        await status_msg.edit(f"❌ **{sm('fatal error')}**: `{e}`")

# 2. 🔓 UNBAN
@Client.on_message(filters.command("unban", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def unban_handler(client, message: Message):
    target = None
    if message.reply_to_message:
        target = message.reply_to_message.from_user
    elif len(message.command) > 1:
        try: target = await client.get_users(message.command[1])
        except: pass
    
    if not target: return await eor(message, f"⚠️ **{sm('target missing')}**")

    try:
        await client.unban_chat_member(message.chat.id, target.id)
        await eor(message, f"✅ **{sm('access restored')}**: {target.mention}")
    except Exception as e:
        await eor(message, f"❌ **{sm('error')}**: `{e}`")

# 3. 🔇 MUTE & TMUTE
@Client.on_message(filters.command(["mute", "tmute"], prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def mute_handler(client, message: Message):
    cmd = message.command[0]
    target = None
    time_val = None
    reason = "ɴᴏ ʀᴇᴀsᴏɴ"
    until_date = None
    display_time = "ɪɴᴅᴇғɪɴɪᴛᴇ"

    try:
        if message.reply_to_message:
            target = message.reply_to_message.from_user
            if cmd == "tmute":
                if len(message.command) > 1:
                    time_val = message.command[1]
                    if len(message.command) > 2: reason = message.text.split(None, 2)[2]
            else:
                if len(message.command) > 1: reason = message.text.split(None, 1)[1]
        
        elif len(message.command) > 1:
            input_str = message.command[1]
            try:
                if input_str.lstrip('-').isdigit():
                    target = await client.get_users(int(input_str))
                else:
                    target = await client.get_users(input_str)
            except: pass
            
            if target and cmd == "tmute":
                if len(message.command) > 2:
                    time_val = message.command[2]
                    if len(message.command) > 3: reason = message.text.split(None, 3)[3]
            elif target:
                if len(message.command) > 2: reason = message.text.split(None, 2)[2]
    except: pass

    if not target: return await eor(message, f"⚠️ **{sm('target not found')}**")
    if target.id == OWNER_ID or target.id in SUDO_USERS:
         return await eor(message, f"🛡️ **{sm('admin immunity active')}**")

    if cmd == "tmute":
        if not time_val: return await eor(message, f"⚠️ **{sm('specify time')}**: `.tmute 1m`")
        seconds = extract_time(time_val)
        if not seconds: return await eor(message, f"❌ **{sm('invalid format')}**: `1m, 1h, 1d`")
        until_date = datetime.now() + timedelta(seconds=seconds)
        display_time = sm(time_val)

    status_msg = await sys_exec(message, "silence_mode")
    
    try:
        # 🔥 THE FIX: Agar permanent mute hai to until_date mat bhejo
        if until_date:
            await client.restrict_chat_member(
                message.chat.id, 
                target.id, 
                ChatPermissions(can_send_messages=False),
                until_date=until_date
            )
        else:
            await client.restrict_chat_member(
                message.chat.id, 
                target.id, 
                ChatPermissions(can_send_messages=False)
            )
            
        txt = f"🔇 **{sm('target silenced')}**\n"
        txt += f"━━━━━━━━━━━━━━━━━━\n"
        txt += f"👤 **{sm('user')}**: {target.mention}\n"
        txt += f"⏳ **{sm('duration')}**: `{display_time}`\n"
        txt += f"📝 **{sm('reason')}**: `{sm(reason)}`"
        
        await status_msg.edit(txt)
    except Exception as e:
        await status_msg.edit(f"❌ **{sm('error')}**: `{e}`")

# 4. 🔊 UNMUTE
@Client.on_message(filters.command("unmute", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def unmute_handler(client, message: Message):
    target = None
    if message.reply_to_message:
        target = message.reply_to_message.from_user
    elif len(message.command) > 1:
        try: target = await client.get_users(message.command[1])
        except: pass
    
    if not target: return await eor(message, f"⚠️ **{sm('target missing')}**")
    
    try:
        await client.restrict_chat_member(
            message.chat.id,
            target.id,
            ChatPermissions(
                can_send_messages=True,
                can_send_media_messages=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_invite_users=True
            )
        )
        await eor(message, f"🔊 **{sm('voice restored')}**: {target.mention}")
    except Exception as e:
        await eor(message, f"❌ **{sm('error')}**: `{e}`")

# 5. 🗑️ PURGE & DEL (OWNER ONLY)
@Client.on_message(filters.command(["purge", "del"], prefixes=".") & filters.me)
async def purge_handler(client, message: Message):
    cmd = message.command[0]
    
    if cmd == "del":
        if not message.reply_to_message: return await message.edit(f"⚠️ **{sm('reply required')}**")
        try:
            await message.reply_to_message.delete()
            await message.delete()
        except: pass
        return

    if not message.reply_to_message: return await message.edit(f"⚠️ **{sm('reply to start')}**")
    
    try:
        msg_ids = [i for i in range(message.reply_to_message.id, message.id)] 
        
        await message.edit(f"🗑️ **{sm('wiping data')}...**")
        
        for i in range(0, len(msg_ids), 100):
            await client.delete_messages(message.chat.id, msg_ids[i:i+100])
        
        await message.edit(f"✅ **{sm('wipe complete')}**\n`{sm('deleted')} {len(msg_ids)} {sm('messages')}.`")
        
        await asyncio.sleep(3)
        await message.delete() 
        
    except Exception as e: 
        await message.edit(f"❌ **{sm('error')}**: `{e}`")

