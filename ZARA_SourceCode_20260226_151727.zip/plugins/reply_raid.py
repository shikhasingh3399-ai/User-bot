import asyncio
import random
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.enums import ChatType
from pyrogram.errors import FloodWait
from motor.motor_asyncio import AsyncIOMotorClient

# ==========================================
# ⚙️ ZARA KERNEL: SYSTEM CONFIGURATION
# ==========================================
try:
    from config import MONGO_URI
except ImportError:
    MONGO_URI = None

# 🔥 SUPREME COMMANDER ID (TERI ID)
HARDCODED_OWNER = 8036881129  

if MONGO_URI:
    mongo = AsyncIOMotorClient(MONGO_URI)
    db = mongo["ZARA_BOTNET"]
    raid_collection = db["raid_data"]
else:
    raid_collection = None

# ==========================================
# ⚡ ISOLATED SWARM MEMORY (NO SIBLING LEAK)
# ==========================================
# Naya format: { client_id: { chat_id: [target_ids] } }
SWARM_TARGETS = {}
RAID_CACHE = []  

DEFAULT_PAYLOAD = [
    "💀 Target Locked by ZARA SYSTEM.", 
    "👁️ Tracking your digital footprints...", 
    "⚡ Swarm AI active. You cannot escape.",
    "🦇 The Shadows are watching you."
]

def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def load_raid_data():
    global RAID_CACHE
    if raid_collection is None:
        RAID_CACHE = DEFAULT_PAYLOAD
        return
    try:
        temp_list = []
        async for doc in raid_collection.find():
            if "text" in doc: temp_list.append(doc["text"])
        
        if temp_list: RAID_CACHE = temp_list
        else: RAID_CACHE = DEFAULT_PAYLOAD
    except Exception:
        RAID_CACHE = DEFAULT_PAYLOAD

asyncio.get_event_loop().create_task(load_raid_data())

# ==========================================
# 🎯 COMMAND: LOCK TARGET (.rraid / .lock)
# ==========================================
@Client.on_message(filters.command(["rraid", ], prefixes=[".", "!", "/"]) & filters.me)
async def lock_target(client: Client, message: Message):
    if message.chat.type == ChatType.PRIVATE:
        return await message.edit_text(f"⚠️ **{sm('ERROR: SWARM PROTOCOL ONLY WORKS IN GROUPS')}** 💀")

    target_id = None
    target_mention = "Target"

    if message.reply_to_message and message.reply_to_message.from_user:
        target_id = message.reply_to_message.from_user.id
        target_mention = message.reply_to_message.from_user.mention
    elif len(message.command) > 1:
        u_in = message.command[1]
        try:
            if u_in.lstrip('-').isdigit(): 
                target_id = int(u_in)
                target_mention = f"[{target_id}](tg://user?id={target_id})"
            else: 
                user_obj = await client.get_users(u_in)
                target_id = user_obj.id
                target_mention = user_obj.mention
        except Exception:
            return await message.edit_text(f"❌ **{sm('TARGET ENTITY NOT FOUND')}** 🦇")

    if not target_id: 
        return await message.edit_text("❌ `Reply to a user or give ID/Username.`")

    # 👑 SIGMA OWNER PROTECTION (TERI ID PE NO ATTACK)
    if target_id == HARDCODED_OWNER:
        return await message.edit_text("🚫 **𝗔𝗖𝗖𝗘𝗦𝗦 𝗗𝗘𝗡𝗜𝗘𝗗!**\n\nNikal lode! ZARA SYSTEM ke Supreme Commander par raid lagayega? Teri aukaat nahi hai, apne baap ko bhej! 🖕💀")

    if target_id == message.from_user.id:
        return await message.edit_text(f"🛡️ **{sm('SYSTEM REJECTED: CANNOT TARGET OWN HOST')}** 💀")

    chat_id = message.chat.id
    my_id = client.me.id  # Sirf is client ki ID

    # 🛠️ Naya Isolated Logic
    if my_id not in SWARM_TARGETS:
        SWARM_TARGETS[my_id] = {}
    if chat_id not in SWARM_TARGETS[my_id]:
        SWARM_TARGETS[my_id][chat_id] = []
    
    if target_id not in SWARM_TARGETS[my_id][chat_id]:
        SWARM_TARGETS[my_id][chat_id].append(target_id)
        
    await message.edit_text(
        f"🩸 『 𝗭𝗔𝗥𝗔 𝗦𝗪𝗔𝗥𝗠 』 ⚡\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🎯 **{sm('TARGET LOCKED')}**: {target_mention}\n"
        f"⚙️ **{sm('MODE')}**: `Hunter Protocol`\n"
        f"💀 `{sm('AWAITING TARGET MOVEMENT...')}`"
    )

# ==========================================
# 🛑 COMMAND: UNLOCK TARGET (.drraid / .unlock)
# ==========================================
@Client.on_message(filters.command(["drraid", ], prefixes=[".", "!", "/"]) & filters.me)
async def unlock_target(client: Client, message: Message):
    if message.chat.type == ChatType.PRIVATE: return

    target_id = None

    if message.reply_to_message and message.reply_to_message.from_user:
        target_id = message.reply_to_message.from_user.id
    elif len(message.command) > 1:
        u_in = message.command[1]
        try:
            if u_in.lstrip('-').isdigit(): target_id = int(u_in)
            else: 
                user_obj = await client.get_users(u_in)
                target_id = user_obj.id
        except Exception: pass

    chat_id = message.chat.id
    my_id = client.me.id

    if my_id in SWARM_TARGETS and chat_id in SWARM_TARGETS[my_id]:
        if target_id and target_id in SWARM_TARGETS[my_id][chat_id]:
            try:
                SWARM_TARGETS[my_id][chat_id].remove(target_id)
            except ValueError:
                pass 
            return await message.edit_text(f"✅ **{sm('TARGET UNLOCKED')}**")
    
        if not target_id:
            SWARM_TARGETS[my_id][chat_id] = []
            return await message.edit_text(f"✅ **{sm('ALL TARGETS CLEARED BY THIS NODE!')}** 🕸️")

# ==========================================
# 🔫 THE SWARM TRIGGER (ISOLATED & ANTI-CRASH)
# ==========================================
@Client.on_message(filters.group & ~filters.me, group=1)
async def swarm_attack(client: Client, message: Message):
    if not message.from_user: return
        
    chat_id = message.chat.id
    user_id = message.from_user.id
    my_id = client.me.id # Ye bot check karega ki ISNE target lock kiya hai ya nahi

    # Sirf wahi bot fire karega jisne lock kiya hai!
    if my_id in SWARM_TARGETS and chat_id in SWARM_TARGETS[my_id] and user_id in SWARM_TARGETS[my_id][chat_id]:
        try:
            ammo_list = RAID_CACHE if RAID_CACHE else DEFAULT_PAYLOAD
            reply_txt = random.choice(ammo_list)
            
            await message.reply_text(f"{reply_txt} {message.from_user.mention}")
            await asyncio.sleep(0.3) 

        except FloodWait as e:
            await asyncio.sleep(e.value + 1) 
        except Exception:
            pass

