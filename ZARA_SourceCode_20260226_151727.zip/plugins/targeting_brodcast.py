import asyncio
import unicodedata
from pyrogram import Client, filters, enums
from pyrogram.types import Message
from pyrogram.errors import FloodWait

# Config se Owner ID import kar rahe hain
from config import OWNER_ID

# ==========================================
# 🎨 ZARA HACKER FONT ENGINE (iOS MEDIUM)
# ==========================================
def sm(text):
    if not text: return ""
    text = str(text)
    normalized = unicodedata.normalize('NFKC', text)
    mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
    return "".join(mapping.get(c.lower(), c) for c in normalized)

# ==========================================
# 🚀 SIGMA PARALLEL BROADCAST WORKER (STANDALONE)
# ==========================================
async def node_caster(node: Client, cast_type: str, msg_to_send):
    success = 0
    fail = 0
    
    async for dialog in node.get_dialogs():
        chat_type = dialog.chat.type
        
        # Filter Groups vs DMs
        if cast_type == "GROUP" and chat_type not in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
            continue
        if cast_type == "DM" and chat_type != enums.ChatType.PRIVATE:
            continue
            
        # Security: Don't let bots spam the Owner, Themselves, or Telegram official
        if cast_type == "DM" and dialog.chat.id in [OWNER_ID, node.me.id, 777000]:
            continue

        try:
            if isinstance(msg_to_send, str):
                await node.send_message(dialog.chat.id, msg_to_send)
            else:
                await msg_to_send.copy(dialog.chat.id) 
                
            success += 1
            await asyncio.sleep(2.5) # 🛡️ SIGMA ANTI-BAN DELAY
            
        except FloodWait as e:
            await asyncio.sleep(e.value + 1)
            try:
                if isinstance(msg_to_send, str):
                    await node.send_message(dialog.chat.id, msg_to_send)
                else:
                    await msg_to_send.copy(dialog.chat.id)
                success += 1
                await asyncio.sleep(2.5)
            except:
                fail += 1
        except Exception:
            fail += 1
            
    return node, success, fail

# ==========================================
# 🎯 ZARA TARGETED CAST ENGINE (.tgcast / .tdmcast)
# ==========================================
@Client.on_message(filters.command(["tgcast", "tdmcast"], prefixes=".") & filters.me)
async def target_cast(client: Client, message: Message):
    # 🛑 1st SECURITY SHIELD: Only Supreme Commander can use this
    if message.from_user.id != OWNER_ID:
        return await message.edit(sm("❌ error: access denied. only supreme commander can target specific nodes."))

    if len(message.command) < 3 and not message.reply_to_message:
        return await message.edit(sm("⚠️ usage: .tdmcast @username <message> OR reply to media with .tdmcast 123456789"))

    command = message.command[0].lower()
    cast_type = "GROUP" if command == "tgcast" else "DM"
    target_input = message.command[1]
    
    # 🎯 Parse Target ID or Username
    target_id = int(target_input) if target_input.lstrip('-').isdigit() else target_input.replace("@", "")

    # 📝 Extract Payload (Text or Media)
    msg_to_send = None
    if message.reply_to_message:
        msg_to_send = message.reply_to_message
    elif len(message.command) > 2:
        msg_to_send = message.text.split(None, 2)[2]
        
    if not msg_to_send:
        return await message.edit(sm("❌ error: reply to a message or type some text to cast."))

    # 🌀 Clean Radar Animation
    anim = await message.edit(sm(f"`[ ◐ ]` scanning grid for target node '{target_input}'..."))
    frames = ["`[ ◓ ]`", "`[ ◑ ]`", "`[ ◒ ]`", "`[ ◐ ]`"]
    for frame in frames:
        try:
            await anim.edit(sm(f"{frame} scanning grid for target node '{target_input}'..."))
            await asyncio.sleep(0.2)
        except: pass

    # 🤖 Find the Exact Target Node in the Grid
    all_bots = []
    target_node = None
    
    if hasattr(client, "userbots"):
        all_bots = client.userbots
    elif hasattr(client, "manager") and hasattr(client.manager, "userbots"):
        all_bots = client.manager.userbots
        
    for b in all_bots:
        if b.me:
            # Check by Numeric ID
            if isinstance(target_id, int) and b.me.id == target_id:
                target_node = b
                break
            # Check by Username
            elif isinstance(target_id, str) and b.me.username and b.me.username.lower() == target_id.lower():
                target_node = b
                break

    if not target_node:
        return await anim.edit(sm(f"❌ error: node '{target_input}' not found or offline."))

    # 🛑 2nd SECURITY SHIELD: Protect the Supreme Commander's Account
    if target_node.me.id == OWNER_ID:
        return await anim.edit(sm("❌ error: security protocol triggered! you cannot hijack the supreme commander's node."))

    node_name = target_node.me.first_name

    await anim.edit(sm(f"`[ ◑ ]` target verified: {node_name}. hijacking node for {cast_type} cast..."))
    await asyncio.sleep(1)
    
    await anim.edit(sm(f"`[ ◒ ]` payload dispatched. target is transmitting... [anti-ban active]"))

    # 🚀 Execute Broadcast ONLY on Target Node
    _, success, fail = await node_caster(target_node, cast_type, msg_to_send)

    # 📊 Generate Dossier (Report)
    report = (
        f"🎯 **{sm('targeted broadcast complete')}** 🎯\n"
        f"━━━━━━━━━━━━━━━\n"
        f"🛠️ **{sm('mode')}**: `{cast_type} CAST`\n"
        f"👤 **{sm('hijacked node')}**: `{node_name}` (`{target_node.me.id}`)\n"
        f"━━━━━━━━━━━━━━━\n"
        f"📊 **{sm('status')}**: ✅ `{success}` | ❌ `{fail}`"
    )
    
    await anim.edit(report)

