import os
import re
import math
import asyncio
import unicodedata
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import Message

# 🛠️ CONFIG IMPORT
try:
    from config import OWNER_ID, SUDO_USERS
except ImportError:
    try:
        from config import OWNER_ID
        SUDO_USERS = [OWNER_ID]
    except: 
        SUDO_USERS = []

# ==========================================
# ⚙️ KERNEL CONFIGURATION & CACHE
# ==========================================
COMMANDS_PER_PAGE = 20  # 10 rows of 2 columns
PLUGIN_DIR = "plugins"

CMD_CACHE = []
MOD_CACHE = 0

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ', 'v': 'ᴠ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🕵️‍♂️ DEEP SCANNER
# ==========================================
def _sync_scan():
    cmds = set()
    module_count = 0
    if not os.path.exists(PLUGIN_DIR): return [], 0

    for root, dirs, files in os.walk(PLUGIN_DIR):
        for file in files:
            if file.endswith(".py") and not file.startswith("__"):
                module_count += 1
                try:
                    with open(os.path.join(root, file), "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                        matches = re.findall(r'filters\.command\(\s*\[?(.*?)\]?\s*(?:,|\))', content)
                        for match in matches:
                            clean = re.sub(r'["\'\s]', '', match)
                            for cmd in clean.split(","):
                                if cmd and len(cmd) > 1 and cmd not in ["help", "start", "restart", "logs"]:
                                    cmds.add(cmd)
                except: pass
    return sorted(list(cmds)), module_count

async def get_commands(force_update=False):
    global CMD_CACHE, MOD_CACHE
    if not CMD_CACHE or force_update:
        CMD_CACHE, MOD_CACHE = await asyncio.to_thread(_sync_scan)
    return CMD_CACHE, MOD_CACHE

# ==========================================
# 🖥️ FLAWLESS TERMINAL GRID (100% STRAIGHT)
# ==========================================
def make_grid(cmd_list, page, total_pages):
    rows = []
    start_idx = page * COMMANDS_PER_PAGE
    end_idx = start_idx + COMMANDS_PER_PAGE
    current_slice = cmd_list[start_idx:end_idx]
    
    # 🔥 TRIPLE BACKTICK LOGIC FOR PERFECT ALIGNMENT
    for i in range(0, len(current_slice), 2):
        c1 = current_slice[i]
        c2 = current_slice[i+1] if i+1 < len(current_slice) else ""
        
        # 16 spaces padding ensures perfect pipeline alignment
        col1 = f".{c1}".ljust(16)
        col2 = f".{c2}" if c2 else ""
        
        if col2:
            rows.append(f"{col1} │ {col2}")
        else:
            rows.append(f"{col1} │")
            
    # Wrap entire grid in a single code block
    return "```text\n" + "\n".join(rows) + "\n```"

# ==========================================
# 🚀 MAIN HELP CONTROLLER
# ==========================================
@Client.on_message(filters.command(["help", ], prefixes=[".", "!", "/"]) & (filters.me | filters.user(SUDO_USERS)))
async def zara_terminal(client, message: Message):
    args = message.command
    
    force_update = False
    if len(args) > 1 and args[1].lower() in ["update", "sync"]:
        force_update = True
        status = await eor(message, f"🔄 **{sm('FLUSHING CACHE & RESCANNING KERNEL...')}**")
    else:
        status = await eor(message, f"⚡ **{sm('ACCESSING KERNEL MEMORY...')}**")

    cmd_list, mod_count = await get_commands(force_update)
    total_cmds = len(cmd_list)
    
    if total_cmds == 0:
        return await status.edit(f"❌ **{sm('SYSTEM CRITICAL')}**: `{sm('NO MODULES FOUND')}`")

    current_page = 0
    if len(args) > 1 and args[1].isdigit():
        current_page = int(args[1]) - 1
        
    total_pages = math.ceil(total_cmds / COMMANDS_PER_PAGE)
    
    if current_page < 0: current_page = 0
    if current_page >= total_pages: current_page = total_pages - 1

    grid = make_grid(cmd_list, current_page, total_pages)
    time_now = datetime.now().strftime("%H:%M:%S")
    
    # 🔥 FULL SMALL CAPS UI HEADER
    header = f"💀 **{sm('ZARA BOTNET TERMINAL V4.0')}**\n"
    header += f"━━━━━━━━━━━━━━━━━━━━━\n"
    header += f"🧬 **{sm('MODULES')}**: `{mod_count}` │ 📡 **{sm('CMDS')}**: `{total_cmds}`\n"
    header += f"⏳ **{sm('TIME')}**: `{time_now}`\n"
    header += f"━━━━━━━━━━━━━━━━━━━━━\n"
    
    # 🔥 FULL SMALL CAPS UI FOOTER
    footer = f"━━━━━━━━━━━━━━━━━━━━━\n"
    footer += f"📑 **{sm('PAGE')}**: `{current_page + 1}/{total_pages}`\n"
    
    # Navigation Hint
    if total_pages > 1:
        if current_page < total_pages - 1:
            footer += f"▶️ `{sm('NEXT PAGE')}: .help {current_page + 2}`\n"
        if current_page > 0:
            footer += f"◀️ `{sm('PREV PAGE')}: .help {current_page}`\n"
            
    footer += f"💎 **{sm('SYSTEM STATUS')}:** `{sm('ONLINE')} 🟢`\n"

    try:
        await status.edit(header + grid + footer)
    except Exception as e:
        await status.edit(f"❌ **{sm('RENDER ERROR')}**: `{e}`")

