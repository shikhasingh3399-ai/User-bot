import asyncio
import random
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 💖 SECTION 1: THE 60 HEARTS BLAST (.love)
# ==========================================
@Client.on_message(filters.command("love", prefixes=".") & filters.me)
async def love_animation(client: Client, message: Message):
    # Sabhi colors ke hearts ki list
    colors = ["❤️", "🧡", "💛", "💚", "💙", "💜", "🤎", "🖤", "🤍", "💖", "💗", "💓", "💞", "💕", "💘", "💝", "🩷", "🩵", "🩶"]
    
    heart_blast = ""
    # 10 frames chalayenge, har frame me 6 hearts add honge (Total 60 Hearts)
    for i in range(10):
        for _ in range(6):
            heart_blast += random.choice(colors)
        
        try:
            await message.edit_text(f"**{heart_blast}**")
            await asyncio.sleep(0.3) # 0.3 second ka delay taaki animation smooth dikhe
        except:
            pass
            
    # Final message with nice emoji
    final_text = f"**{heart_blast}**\n\n✨ **Lᴏᴠᴇ ʏᴏᴜ <3** 🥺💝"
    await message.edit_text(final_text)


# ==========================================
# 🧸 SECTION 2: TEDDY BEAR ANIMATION (.loveyou)
# ==========================================
@Client.on_message(filters.command("loveyou", prefixes=".") & filters.me)
async def teddy_animation(client: Client, message: Message):
    # 5/6 modules ka frame-by-frame Text Animation
    teddy_frames = [
        "**[■□□□□]**\n\n`Cʀᴇᴀᴛɪɴɢ sᴏᴍᴇᴛʜɪɴɢ sᴘᴇᴄɪᴀʟ...`",
        "**[■■□□□]**\n\n(\\__/) \n( •_•)",
        "**[■■■□□]**\n\n(\\__/) \n( •_•)\n/ >💝",
        "**[■■■■□]**\n\n(\\__/) \n( >.<)\n/ >💝 `Fᴏʀ ʏᴏᴜ...`",
        "**[■■■■■]**\n\n(\\__/) \n( ♥️_♥️)\n/ >💝 `Pʟᴇᴀsᴇ ᴀᴄᴄᴇᴘᴛ ɪᴛ!`",
        "🧸 **L O V E   Y O U !** 🧸\n\n   💖 💝 💖 💝 💖"
    ]
    
    for frame in teddy_frames:
        try:
            await message.edit_text(frame)
            await asyncio.sleep(0.6) # Thoda slow taaki animation padha ja sake
        except:
            pass


# ==========================================
# ❣️ SECTION 3: RANDOM HEART FLASH (.heart)
# ==========================================
@Client.on_message(filters.command("heart", prefixes=".") & filters.me)
async def random_heart(client: Client, message: Message):
    # Khali random love emojis
    love_emojis = ["🥰", "😍", "😘", "🫶", "💋", "💌", "💘", "💝", "💖", "💗", "💓", "💞", "💕", "❣️", "❤️‍🔥", "❤️‍🩹"]
    
    # 8 baar screen par alag-alag emojis flash honge
    for _ in range(8):
        flash_text = "".join(random.choices(love_emojis, k=5)) # Ek baar me 5 emoji
        try:
            await message.edit_text(f"**{flash_text}**")
            await asyncio.sleep(0.4)
        except:
            pass
            
    # Final cute message
    await message.edit_text("**ʟᴏᴠᴇ ʏᴏᴜ ᴛᴏᴏ ᴍᴇʀɪ ᴄᴜᴛᴇ ꜱɪ ᴊᴀᴀɴ ❤️🥺🫶**")

