import asyncio
from pyrogram import Client, filters
from pyrogram.errors import FloodWait, UserAdminInvalid, ChatAdminRequired
from pyrogram.types import Message

# (Agar tera ZARA font import karna ho to yahan kar lena, abhi normal stylish rakha hai)
def sm(text):
    return text # Placeholder for your hacker font if needed

# ==========================================
# ☢️ THE CHANNEL NUKE PROTOCOL (/chbanall)
# ==========================================
@Client.on_message(filters.command("chbanall", prefixes=["/", ".", "!"]) & filters.me)
async def nuke_channel(client: Client, message: Message):
    chat_id = message.chat.id
    
    # 1. Pehle check karega ki group/channel hai ya nahi
    if message.chat.type in ["private", "bot"]:
        return await message.reply("⚠️ **ᴇʀʀᴏʀ:** ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ ᴡᴏʀᴋꜱ ɪɴ ᴄʜᴀɴɴᴇʟꜱ/ɢʀᴏᴜᴩꜱ.")

    status_msg = await message.reply("☢️ `[ ɪɴɪᴛɪᴀᴛɪɴɢ ᴍᴀꜱꜱ ᴇxᴛᴇʀᴍɪɴᴀᴛɪᴏɴ ᴩʀᴏᴛᴏᴄᴏʟ... ]`")

    banned_count = 0
    failed_count = 0

    try:
        await status_msg.edit("☢️ `[ ɢᴀᴛʜᴇʀɪɴɢ ᴛᴀʀɢᴇᴛꜱ... ᴛʜɪꜱ ᴍᴀʏ ᴛᴀᴋᴇ ᴀ ᴡʜɪʟᴇ ꜰᴏʀ 40ᴋ+ ]`")
        
        # 2. Extract and Ban Loop
        async for member in client.get_chat_members(chat_id):
            user = member.user
            
            # Khud ko aur baaki admins ko ban nahi karega
            if user.id == client.me.id or member.status in ["creator", "administrator"]:
                continue
                
            try:
                await client.ban_chat_member(chat_id, user.id)
                banned_count += 1
                
                # Har 50 ban ke baad terminal pe update dega (UI update limit bachane ke liye)
                if banned_count % 50 == 0:
                    try:
                        await status_msg.edit(f"💀 **ɴᴜᴋᴇ ɪɴ ᴩʀᴏɢʀᴇꜱꜱ...**\n━━━━━━━━━━━━━━━\n🩸 ʙᴀɴɴᴇᴅ: `{banned_count}`\n❌ ꜰᴀɪʟᴇᴅ: `{failed_count}`")
                    except: pass
                    
                await asyncio.sleep(0.2) # API Limit se bachne ke liye chhota delay
                
            except FloodWait as e:
                # Agar Telegram gussa hua, toh bot utne second ruk jayega
                await asyncio.sleep(e.value + 2) 
            except UserAdminInvalid:
                failed_count += 1 # Cannot ban admins
            except ChatAdminRequired:
                return await status_msg.edit("🤬 **ᴏᴜᴋᴀᴀᴛ ᴍᴇ ʀᴇʜ!** ʏᴏᴜ ɴᴇᴇᴅ ᴀᴅᴍɪɴ ʀɪɢʜᴛꜱ ᴛᴏ ʙᴀɴ ᴍᴇᴍʙᴇʀꜱ ʜᴇʀᴇ.")
            except Exception:
                failed_count += 1

        # 3. Final Report
        final_report = (
            f"☢️ **ᴄʜᴀɴɴᴇʟ ᴇʀᴀᴅɪᴄᴀᴛᴇᴅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ** ☢️\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 ᴛᴀʀɢᴇᴛ ᴄʜᴀᴛ: `{message.chat.title}`\n"
            f"🩸 ᴛᴏᴛᴀʟ ʙᴀɴɴᴇᴅ: `{banned_count}` ᴍᴇᴍʙᴇʀꜱ\n"
            f"❌ ꜱᴋɪᴩᴩᴇᴅ/ꜰᴀɪʟᴇᴅ: `{failed_count}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"💀 `[ ᴏᴩᴇʀᴀᴛɪᴏɴ ᴄᴏᴍᴩʟᴇᴛᴇ ]`"
        )
        await status_msg.edit(final_report)

    except Exception as e:
        await status_msg.edit(f"❌ **ꜱʏꜱᴛᴇᴍ ᴄʀᴀꜱʜ:** {str(e)}")

