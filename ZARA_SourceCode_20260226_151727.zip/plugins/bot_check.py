from pyrogram import Client, filters
from pyrogram.types import Message

# 👑 OWNER ID (Hardcore Lock)
OWNER_ID = 8036881129

# ==========================================
# ⚡ ALIVE CHECK (Sirf Owner ke liye)
# ==========================================
@Client.on_message(filters.command("bot", prefixes=".") & filters.user(OWNER_ID))
async def alive_check(client: Client, message: Message):
    # Sirf ek current / voltage wali emoji reply karega
    await message.reply_text("⚡")


