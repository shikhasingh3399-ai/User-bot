import asyncio
import unicodedata
import re
from pyrogram import Client, filters, enums
from pyrogram.types import Message
from pyrogram.errors import FloodWait, UserNotParticipant

# 🛠️ CONFIG IMPORT
try:
    from config import OWNER_ID, SUDO_USERS
except ImportError:
    try:
        from config import OWNER_ID
        SUDO_USERS = [OWNER_ID]
    except: pass

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

async def get_target(client, message):
    target = None
    if message.reply_to_message:
        target = message.reply_to_message.from_user
    elif len(message.command) > 1:
        input_str = message.command[1]
        try:
            target = await client.get_users(int(input_str) if input_str.lstrip('-').isdigit() else input_str)
        except: pass
    return target

# ==========================================
# 🌐 NETWORK INFILTRATION (JOIN & LEAVE)
# ==========================================

@Client.on_message(filters.command("join", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def join_chat_cmd(client, message: Message):
    link = None
    
    # Smart Link Extraction (Ab kabhi USERNAME_INVALID nahi aayega)
    if len(message.command) > 1:
        link = message.command[1]
    elif message.reply_to_message:
        text = message.reply_to_message.text or message.reply_to_message.caption or ""
        urls = re.findall(r'(https?://(?:t\.me|telegram\.me|telegram\.dog)/[^\s]+)', text)
        if urls: link = urls[0]

    if not link:
        return await eor(message, f"⚠️ **{sm('provide a link or username to join')}**")

    # Clean the link (remove trailing brackets, dots, etc.)
    link = link.rstrip(").,'\"")
    
    # Agar normal username link hai, to direct username nikal lo
    if "t.me/" in link and "+" not in link and "joinchat" not in link:
        link = link.split("t.me/")[1].split("/")[0].split("?")[0]

    status = await eor(message, f"⚡ **{sm('infiltrating network')}...**")
    try:
        await client.join_chat(link)
        await status.edit(f"✅ **{sm('successfully infiltrated')}**: `{link}`")
    except Exception as e:
        await status.edit(f"❌ **{sm('access denied')}**: `{e}`")

@Client.on_message(filters.command("leave", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def leave_chat_cmd(client, message: Message):
    chat_id = message.chat.id
    
    # Agar kisi aur group ki ID daali hai leave karne ko
    if len(message.command) > 1:
        input_chat = message.command[1]
        try:
            chat_id = int(input_chat) if input_chat.lstrip('-').isdigit() else input_chat
        except: pass

    # Agar bot is current group se leave kar raha hai
    if str(chat_id) == str(message.chat.id):
        # 🔥 TASHAN WALA GOODBYE MESSAGE 🔥
        status = await eor(message, f"👋 **{sm('disconnecting from this network')}...**\n`{sm('goodbye everyone!')}` 🚀")
        await asyncio.sleep(2.5) # 2.5 second wait taaki log padh sakein
    else:
        status = await eor(message, f"⚡ **{sm('erasing presence from remote chat')}...**")

    try:
        await client.leave_chat(chat_id)
        # Agar dusre group se leave kiya hai to msg edit karke bata dega
        if str(chat_id) != str(message.chat.id):
            await status.edit(f"✅ **{sm('left chat successfully')}**")
    except Exception as e:
        # Fata to error de dega
        if str(chat_id) == str(message.chat.id):
            await eor(message, f"❌ **{sm('error')}**: `{e}`")
        else:
            await status.edit(f"❌ **{sm('error')}**: `{e}`")


# ==========================================
# 💥 MASS DESTRUCTION (OWNER ONLY)
# ==========================================

@Client.on_message(filters.command("leaveall", prefixes=".") & filters.me)
async def leave_all_cmd(client, message: Message):
    if len(message.command) < 2 or message.command[1].lower() not in ["gc", "ch"]:
        return await eor(message, f"⚠️ **{sm('syntax')}**: `.leaveall gc` {sm('or')} `.leaveall ch`")

    target_type = message.command[1].lower()
    
    if target_type == "gc":
        chat_types = [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]
        label = sm('groups')
    else:
        chat_types = [enums.ChatType.CHANNEL]
        label = sm('channels')

    status = await eor(message, f"🔥 **{sm('initiating mass escape protocol')}...**\n`{sm('this might take a while')}...`")
    
    left_count = 0
    failed_count = 0

    async for dialog in client.get_dialogs():
        if dialog.chat.type in chat_types:
            try:
                await client.leave_chat(dialog.chat.id)
                left_count += 1
                await asyncio.sleep(1) # 🛡️ Shield against FloodWait (thoda badha diya taaki crash na ho)
            except FloodWait as e:
                await asyncio.sleep(e.value + 1)
            except UserNotParticipant:
                pass
            except Exception:
                failed_count += 1

    report = f"💥 **{sm('escape protocol completed')}** 💥\n"
    report += f"━━━━━━━━━━━━━━━━━━\n"
    report += f"🗑️ **{sm('left')}**: `{left_count} {label}`\n"
    report += f"❌ **{sm('failed')}**: `{failed_count}`"
    
    await status.edit(report)


# ==========================================
# 🛡️ THE BLACKLIST (BLOCK / UNBLOCK)
# ==========================================

@Client.on_message(filters.command("block", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def block_user_cmd(client, message: Message):
    target = await get_target(client, message)
    
    if not target:
        return await eor(message, f"⚠️ **{sm('target not found')}**")
    if target.id == OWNER_ID or target.id in SUDO_USERS:
        return await eor(message, f"🛡️ **{sm('cannot block admin nodes')}**")

    status = await eor(message, f"⚡ **{sm('adding to blacklist')}...**")
    try:
        await client.block_user(target.id)
        await status.edit(f"🚫 **{sm('target blocked and isolated')}**\n👤: {target.mention} (`{target.id}`)")
    except Exception as e:
        await status.edit(f"❌ **{sm('error')}**: `{e}`")

@Client.on_message(filters.command("unblock", prefixes=".") & (filters.me | filters.user(SUDO_USERS)))
async def unblock_user_cmd(client, message: Message):
    target = await get_target(client, message)
    
    if not target:
        return await eor(message, f"⚠️ **{sm('target not found')}**")

    status = await eor(message, f"⚡ **{sm('removing from blacklist')}...**")
    try:
        await client.unblock_user(target.id)
        await status.edit(f"✅ **{sm('target unblocked')}**\n👤: {target.mention} (`{target.id}`)")
    except Exception as e:
        await status.edit(f"❌ **{sm('error')}**: `{e}`")

