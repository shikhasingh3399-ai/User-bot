import asyncio
import time
import unicodedata
import random
from pyrogram import Client, filters, enums
from pyrogram.types import ChatPermissions, Message
from pyrogram.errors import FloodWait

# ==========================================
# 🛡️ PROTECTED ZONES (IMMORTAL SHIELD)
# ==========================================
# Yahan un groups ke username hain jahan tabahi allow nahi hai
PROTECTED_ZONES = ["bmw_userbot_ii", "reflxhacking"]

def is_protected(chat):
    """Check karta hai ki group protected list mein hai ya nahi"""
    if chat.username and chat.username.lower() in PROTECTED_ZONES:
        return True
    return False

def get_sigma_reject_msg():
    """Sigma Warnings jab koi apne hi base pe nuke girane ki koshish kare"""
    msgs = [
        f"🚫 **{sm('system override denied')}**\n`{sm('abe apne hi base pe nuke girayega kya? nikal yahan se.')}`",
        f"⚠️ **{sm('fatal error')}**\n`{sm('ye zone protected hai. yahan tera baap (zara) bhi mass tabahi allow nahi karega.')}`",
        f"☠️ **{sm('friendly fire blocked')}**\n`{sm('dimag kharab hai? apne hi ghar mein aag laga raha hai.')}`",
        f"☣️ **{sm('access denied')}**\n`{sm('immortal shield active. weapons offline.')}`"
    ]
    return random.choice(msgs)

# ==========================================
# 🎨 HACKER FONT & TERMINAL UI ENGINE
# ==========================================
def sm(text):
    """Converts text to Small Caps for Hacker Look."""
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    """Smart Edit/Reply"""
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

async def sys_boot(message: Message, action: str):
    """Terminal Boot Animation"""
    msg = await eor(message, f"☣️ **[ ᴢᴀʀᴀ ᴋᴇʀɴᴇʟ ]**\n`{sm('authenticating')}...`")
    await asyncio.sleep(0.3)
    await msg.edit(f"☣️ **[ ᴢᴀʀᴀ ᴋᴇʀɴᴇʟ ]**\n`{sm('bypassing security')}...`")
    await asyncio.sleep(0.3)
    await msg.edit(f"☢️ **[ sʏsᴛᴇᴍ ᴏᴠᴇʀʀɪᴅᴇ ]**\n⚙️ **{sm('executing')}**: `{action}`\n[▓▓▓▓▓▓░░░░] `60%`")
    return msg

async def get_admins(client, chat_id):
    """Extracts admins to avoid banning/muting them"""
    admins = []
    try:
        async for admin in client.get_chat_members(chat_id, filter=enums.ChatMembersFilter.ADMINISTRATORS):
            admins.append(admin.user.id)
    except Exception: pass
    return admins

# ==========================================
# ⚰️ 1. BAN ALL (MASS TERMINATION)
# ==========================================
@Client.on_message(filters.command("banall", prefixes=".") & filters.me)
async def mass_ban(client, message: Message):
    if message.chat.type == enums.ChatType.PRIVATE:
        return await eor(message, f"🚷 **{sm('command restricted to groups')}**")
    
    # 🛡️ IMMORTAL SHIELD CHECK
    if is_protected(message.chat):
        return await eor(message, get_sigma_reject_msg())

    status = await sys_boot(message, "mass_termination")
    admins = await get_admins(client, message.chat.id)
    count = 0
    start_time = time.time()

    async for member in client.get_chat_members(message.chat.id):
        if member.user.id in admins or member.user.is_self: continue
        try:
            await client.ban_chat_member(message.chat.id, member.user.id)
            count += 1
            await asyncio.sleep(0.1) # Stealth Delay
        except FloodWait as e: await asyncio.sleep(e.value)
        except Exception: pass
            
    taken = round(time.time() - start_time, 2)
    
    report = (f"☢️ **{sm('MASS EXECUTION COMPLETE')}** ☢️\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"🩸 **{sm('Action')}** : `TERMINATION [BAN]`\n"
              f"💀 **{sm('Targets')}** : `{count}` {sm('users wiped')}\n"
              f"⏱️ **{sm('Speed')}** : `{taken}s`\n"
              f"🛡️ **{sm('Admins')}** : `Bypassed`\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"💻 **[ ᴢᴀʀᴀ sʏsᴛᴇᴍs : ᴏғғʟɪɴᴇ ]**")
    await status.edit(report)

# ==========================================
# 🕊️ 2. UNBAN ALL (MASS RESTORATION)
# ==========================================
@Client.on_message(filters.command("unbanall", prefixes=".") & filters.me)
async def mass_unban(client, message: Message):
    if message.chat.type == enums.ChatType.PRIVATE:
        return await eor(message, f"🚷 **{sm('command restricted to groups')}**")

    # 🛡️ IMMORTAL SHIELD CHECK
    if is_protected(message.chat):
        return await eor(message, get_sigma_reject_msg())

    status = await sys_boot(message, "mass_restoration")
    count = 0
    start_time = time.time()

    try:
        async for member in client.get_chat_members(message.chat.id, filter=enums.ChatMembersFilter.BANNED):
            try:
                await client.unban_chat_member(message.chat.id, member.user.id)
                count += 1
                await asyncio.sleep(0.1)
            except FloodWait as e: await asyncio.sleep(e.value)
            except Exception: pass
    except Exception as e:
        return await status.edit(f"❌ **{sm('error fetching ban list')}**: `{e}`")

    taken = round(time.time() - start_time, 2)
    
    report = (f"🧬 **{sm('MASS RESTORATION COMPLETE')}** 🧬\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"🔓 **{sm('Action')}** : `RESTORE [UNBAN]`\n"
              f"👤 **{sm('Targets')}** : `{count}` {sm('users restored')}\n"
              f"⏱️ **{sm('Speed')}** : `{taken}s`\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"💻 **[ ᴢᴀʀᴀ sʏsᴛᴇᴍs : ᴏғғʟɪɴᴇ ]**")
    await status.edit(report)

# ==========================================
# ⛓️ 3. MUTE ALL (SILENCE PROTOCOL)
# ==========================================
@Client.on_message(filters.command("muteall", prefixes=".") & filters.me)
async def mass_mute(client, message: Message):
    if message.chat.type == enums.ChatType.PRIVATE:
        return await eor(message, f"🚷 **{sm('command restricted to groups')}**")

    # 🛡️ IMMORTAL SHIELD CHECK
    if is_protected(message.chat):
        return await eor(message, get_sigma_reject_msg())

    status = await sys_boot(message, "global_silence")
    admins = await get_admins(client, message.chat.id)
    count = 0
    start_time = time.time()

    async for member in client.get_chat_members(message.chat.id):
        if member.user.id in admins or member.user.is_self: continue
        try:
            await client.restrict_chat_member(
                message.chat.id, 
                member.user.id, 
                ChatPermissions(can_send_messages=False)
            )
            count += 1
            await asyncio.sleep(0.15)
        except FloodWait as e: await asyncio.sleep(e.value)
        except Exception: pass

    taken = round(time.time() - start_time, 2)

    report = (f"⛓️ **{sm('GLOBAL SILENCE ENFORCED')}** ⛓️\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"🔇 **{sm('Action')}** : `SILENCE [MUTE]`\n"
              f"🤐 **{sm('Targets')}** : `{count}` {sm('voices crushed')}\n"
              f"⏱️ **{sm('Speed')}** : `{taken}s`\n"
              f"🛡️ **{sm('Admins')}** : `Bypassed`\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"💻 **[ ᴢᴀʀᴀ sʏsᴛᴇᴍs : ᴏғғʟɪɴᴇ ]**")
    await status.edit(report)

# ==========================================
# 🔊 4. UNMUTE ALL (VOICE RESTORATION)
# ==========================================
@Client.on_message(filters.command("unmuteall", prefixes=".") & filters.me)
async def mass_unmute(client, message: Message):
    if message.chat.type == enums.ChatType.PRIVATE:
        return await eor(message, f"🚷 **{sm('command restricted to groups')}**")

    # 🛡️ IMMORTAL SHIELD CHECK
    if is_protected(message.chat):
        return await eor(message, get_sigma_reject_msg())

    status = await sys_boot(message, "voice_restoration")
    count = 0
    start_time = time.time()
    
    full_perms = ChatPermissions(
        can_send_messages=True, can_send_media_messages=True,
        can_send_other_messages=True, can_add_web_page_previews=True, can_invite_users=True
    )

    try:
        async for member in client.get_chat_members(message.chat.id, filter=enums.ChatMembersFilter.RESTRICTED):
            try:
                await client.restrict_chat_member(message.chat.id, member.user.id, full_perms)
                count += 1
                await asyncio.sleep(0.15)
            except FloodWait as e: await asyncio.sleep(e.value)
            except Exception: pass
    except Exception as e:
        return await status.edit(f"❌ **{sm('error fetching restricted list')}**: `{e}`")

    taken = round(time.time() - start_time, 2)

    report = (f"🔊 **{sm('FREEDOM GRANTED')}** 🔊\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"🔓 **{sm('Action')}** : `RESTORE [UNMUTE]`\n"
              f"🗣️ **{sm('Targets')}** : `{count}` {sm('voices restored')}\n"
              f"⏱️ **{sm('Speed')}** : `{taken}s`\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"💻 **[ ᴢᴀʀᴀ sʏsᴛᴇᴍs : ᴏғғʟɪɴᴇ ]**")
    await status.edit(report)

# ==========================================
# ⏏️ 5. KICK ALL (MASS EJECTION)
# ==========================================
@Client.on_message(filters.command("kickall", prefixes=".") & filters.me)
async def mass_kick(client, message: Message):
    if message.chat.type == enums.ChatType.PRIVATE:
        return await eor(message, f"🚷 **{sm('command restricted to groups')}**")

    # 🛡️ IMMORTAL SHIELD CHECK
    if is_protected(message.chat):
        return await eor(message, get_sigma_reject_msg())

    status = await sys_boot(message, "mass_ejection")
    admins = await get_admins(client, message.chat.id)
    count = 0
    start_time = time.time()

    async for member in client.get_chat_members(message.chat.id):
        if member.user.id in admins or member.user.is_self: continue
        try:
            await client.ban_chat_member(message.chat.id, member.user.id)
            await client.unban_chat_member(message.chat.id, member.user.id)
            count += 1
            await asyncio.sleep(0.1)
        except FloodWait as e: await asyncio.sleep(e.value)
        except Exception: pass

    taken = round(time.time() - start_time, 2)

    report = (f"⏏️ **{sm('MASS EJECTION COMPLETE')}** ⏏️\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"💨 **{sm('Action')}** : `EJECTION [KICK]`\n"
              f"🗑️ **{sm('Targets')}** : `{count}` {sm('users purged')}\n"
              f"⏱️ **{sm('Speed')}** : `{taken}s`\n"
              f"🛡️ **{sm('Admins')}** : `Bypassed`\n"
              f"━━━━━━━━━━━━━━━━━━━━\n"
              f"💻 **[ ᴢᴀʀᴀ sʏsᴛᴇᴍs : ᴏғғʟɪɴᴇ ]**")
    await status.edit(report)

