import asyncio
import random
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait, UserIsBlocked, PeerIdInvalid
from motor.motor_asyncio import AsyncIOMotorClient

# ==========================================
# ⚙️ SYSTEM & DB CONFIGURATION
# ==========================================
try:
    from config import MONGO_URI
except ImportError:
    MONGO_URI = None

if MONGO_URI:
    mongo = AsyncIOMotorClient(MONGO_URI)
    db = mongo["ZARA_BOTNET"]
    raid_collection = db["raid_data"]
else:
    raid_collection = None

# ==========================================
# ⚡ GLOBAL MEMORY CACHE
# ==========================================
RAID_CACHE = []  
RSPAM_TARGETS = {} # Format: {chat_id: {user_id: {"count": 2, "text": "tu sahi ha"}}}
DEFAULT_ABUSE = ["Abe nikal yaha se 🖕", "Teri aukaat nahi hai yaha bolne ki 🤫", "System se panga mat le 💀"]

# ==========================================
# 🎨 HACKER FONT & HELPERS
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🧠 DATABASE LOADER (AUTO-SYNC)
# ==========================================
async def load_dmraid_data():
    global RAID_CACHE
    if raid_collection is None:
        RAID_CACHE = DEFAULT_ABUSE
        return
    try:
        temp_list = []
        async for doc in raid_collection.find():
            if "text" in doc: temp_list.append(doc["text"])
        if temp_list: RAID_CACHE = temp_list
        else: RAID_CACHE = DEFAULT_ABUSE
    except Exception:
        RAID_CACHE = DEFAULT_ABUSE

asyncio.get_event_loop().create_task(load_dmraid_data())

# ==========================================
# 📩 COMMAND: DM SPAM (Direct Inbox Spam)
# ==========================================
@Client.on_message(filters.command("dmspam", prefixes=[".", "!", "/"]) & filters.me)
async def dm_spammer(client, message: Message):
    if not message.reply_to_message:
        return await eor(message, f"⚠️ **{sm('Kisi ke message pe reply kar GC me!')}**")
        
    if len(message.command) < 3:
        return await eor(message, f"⚠️ **{sm('Usage')}**: `.dmspam <count> <text>`")
    
    try:
        count = int(message.command[1])
    except ValueError:
        return await eor(message, f"❌ **{sm('Count me number daal!')}**")
        
    text = " ".join(message.command[2:])
    target_id = message.reply_to_message.from_user.id # 🎯 Seedha Target ka DM ID

    anim = await eor(message, f"🚀 **{sm('INJECTING SPAM TO TARGET DM')}...**")
    
    sent_count = 0
    for _ in range(count):
        try:
            await client.send_message(target_id, text)
            sent_count += 1
            await asyncio.sleep(0.3)
        except FloodWait as e:
            await asyncio.sleep(e.value)
        except UserIsBlocked:
            return await anim.edit(f"❌ **{sm('Target ne tujhe block kiya hai ya DM band hai!')}**")
        except Exception as e:
            break
            
    await anim.edit(f"✅ **{sm('DM SPAM COMPLETE')}!** `{sent_count}` **messages delivered to DM.**")

# ==========================================
# 🤬 COMMAND: DM RAID (Direct Inbox Abuses)
# ==========================================
@Client.on_message(filters.command("dmraid", prefixes=[".", "!", "/"]) & filters.me)
async def dm_raider(client, message: Message):
    if not message.reply_to_message:
        return await eor(message, f"⚠️ **{sm('Kisi ke message pe reply kar GC me!')}**")

    if len(message.command) < 2:
        return await eor(message, f"⚠️ **{sm('Usage')}**: `.dmraid <count>`")
    
    try:
        count = int(message.command[1])
    except ValueError:
        return await eor(message, f"❌ **{sm('Count me number daal!')}**")
        
    target_id = message.reply_to_message.from_user.id # 🎯 Seedha Target ka DM ID
    ammo_list = RAID_CACHE if RAID_CACHE else DEFAULT_ABUSE

    anim = await eor(message, f"🔥 **{sm('DELIVERING DATABASE ABUSES TO DM')}...**")
    
    sent_count = 0
    for _ in range(count):
        try:
            await client.send_message(target_id, random.choice(ammo_list))
            sent_count += 1
            await asyncio.sleep(0.4) 
        except FloodWait as e:
            await asyncio.sleep(e.value)
        except UserIsBlocked:
            return await anim.edit(f"❌ **{sm('Target ne DM block kar rakha hai!')}**")
        except Exception:
            break
            
    await anim.edit(f"☠️ **{sm('DM RAID COMPLETE')}!** `{sent_count}` **abuses delivered from DB.**")

# ==========================================
# 🔄 COMMAND: R-SPAM (Context-Aware Reply Spam)
# ==========================================
@Client.on_message(filters.command("rspam", prefixes=[".", "!", "/"]) & filters.me)
async def set_rspam(client, message: Message):
    if not message.reply_to_message:
        return await eor(message, f"⚠️ **{sm('Kisi ke message pe reply karke command de!')}**")
        
    if len(message.command) < 3:
        return await eor(message, f"⚠️ **{sm('Usage')}**: `.rspam <count> <text>`")

    try:
        count = int(message.command[1])
    except ValueError:
        return await eor(message, f"❌ **{sm('Count me number daal!')}**")

    text = " ".join(message.command[2:])
    user_id = message.reply_to_message.from_user.id
    chat_id = message.chat.id # 🎯 Yahi decide karega ki GC me bajana hai ya DM me

    if chat_id not in RSPAM_TARGETS:
        RSPAM_TARGETS[chat_id] = {}
        
    RSPAM_TARGETS[chat_id][user_id] = {"count": count, "text": text}

    await eor(message, f"🎯 **{sm('R-SPAM LOCKED IN THIS CHAT')}!**\n👤 **Target:** `{user_id}`\n🔢 **Count:** `{count}`")

# ==========================================
# 🛑 COMMAND: D-SPAM (Deactivate R-Spam)
# ==========================================
@Client.on_message(filters.command("dspam", prefixes=[".", "!", "/"]) & filters.me)
async def stop_rspam(client, message: Message):
    chat_id = message.chat.id
    if chat_id in RSPAM_TARGETS:
        RSPAM_TARGETS[chat_id] = {}
        await eor(message, f"🧹 **{sm('R-SPAM TARGETS CLEARED FROM THIS CHAT')}!**")
    else:
        await eor(message, f"⚠️ **{sm('NO ACTIVE TARGETS HERE')}**")

# ==========================================
# 🔫 THE REPLY TRIGGER (Fires on Target's msg)
# ==========================================
@Client.on_message(filters.all & ~filters.me, group=7)
async def trigger_rspam(client, message: Message):
    if not message.from_user:
        return
        
    chat_id = message.chat.id
    user_id = message.from_user.id

    # Check agar IS CHAT me ye banda target hai
    if chat_id in RSPAM_TARGETS and user_id in RSPAM_TARGETS[chat_id]:
        data = RSPAM_TARGETS[chat_id][user_id]
        
        for _ in range(data["count"]):
            try:
                await message.reply(data["text"])
                await asyncio.sleep(0.3)
            except FloodWait as e:
                await asyncio.sleep(e.value)
            except Exception:
                break

