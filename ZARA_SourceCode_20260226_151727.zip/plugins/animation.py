import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait

# ==========================================
# 💀 ZARA DARK ASCII KERNEL (PRO LEVEL)
# ==========================================

DARK_ANIMS = {
    "fuck": [
        r"""```text
        _ 
       | |
       | |
        ```""",
        r"""```text
        _ 
       | |
       | |
     _ | | _  
    | || || |
        ```""",
        r"""```text
        _ 
       | |
       | |
     _ | | _  _ 
    | || || || |
    |          |
        ```""",
        r"""```text
        _ 
       | |
       | |
     _ | | _  _ 
    | || || || |
    |   FUCK   |
     \  YOU   /
      \      /
       |    |
        ```"""
    ],
    
    "broken": [
        r"""```text
⠀⠀⠀⠀⠀⠀⣴⠶⢦⣤⠶⠶⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣇⠀⠀⠁⠀⢀⣿⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠙⢧⣄⠀⣠⠞⠁⠀⠀⠀⠀
        ```""",
        r"""```text
⠀⠀⠀⠀⠀⠀⣴⠶⢦⣤⠶⠶⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣇⠀⠀⠁⠀⢀⣿⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠙⢧⣄⠀⣠⠞⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣀⡀⠀⠉⠛⠃⣠⣄⡀⠀⠀⠀
⠀⠀⠀⠀⡞⠉⠙⢳⣄⢀⡾⠁⠈⣿⠀⠀⠀
        ```""",
        r"""```text
⠀⠀⠀⠀⠀⠀⣴⠶⢦⣤⠶⠶⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣇⠀⠀⠁⠀⢀⣿⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠙⢧⣄⠀⣠⠞⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣀⡀⠀⠉⠛⠃⣠⣄⡀⠀⠀⠀
⠀⠀⠀⠀⡞⠉⠙⢳⣄⢀⡾⠁⠈⣿⠀⠀⠀
⠀⠀⠀⠀⢻⡄⠀⠀⠙⢿⡇⠀⢰⠇⠀⠀⠀
⠀⠀⠀⠀⠀⠙⣦⡀⠀⠀⠹⣦⡟⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠈⢳⣄⠀⠀⠈⠻⣄⠀⠀⠀
        ```""",
        r"""```text
⠀⠀⠀⠀⠀⠀⣴⠶⢦⣤⠶⠶⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣇⠀⠀⠁⠀⢀⣿⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠙⢧⣄⠀⣠⠞⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣀⡀⠀⠉⠛⠃⣠⣄⡀⠀⠀⠀
⠀⠀⠀⠀⡞⠉⠙⢳⣄⢀⡾⠁⠈⣿⠀⠀⠀
⠀⠀⠀⠀⢻⡄⠀⠀⠙⢿⡇⠀⢰⠇⠀⠀⠀
⠀⠀⠀⠀⠀⠙⣦⡀⠀⠀⠹⣦⡟⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠈⢳⣄⠀⠀⠈⠻⣄⠀⠀⠀
⠀⠀⠀⠀⠀⠀⡞⠋⠛⢧⡀⠀⠀⠘⢷⡀⠀
⠀⠀⠀⢠⡴⠾⣧⡀⠀⠀⠹⣦⠀⠀⠈⢿⡄
        ```"""
    ],

    "zara": [
        r"""```text
╔═════════════════╗
║                 ║
╚═════════════════╝
        ```""",
        r"""```text
╔═════════════════╗
║   Z A R A       ║
╚═════════════════╝
        ```""",
        r"""```text
╔═════════════════╗
║   Z A R A 💀    ║
╚═════════════════╝
        ```""",
        r"""```text
╔═════════════════╗
║   Z A R A 💀    ║
╠═════════════════╣
║  SYSTEM ACTIVE  ║
╚═════════════════╝
        ```"""
    ],

    "skull": [
        r"""```text
      .---.
     /     \
        ```""",
        r"""```text
      .---.
     /     \
    | O   O |
        ```""",
        r"""```text
      .---.
     /     \
    | O   O |
     \  ^  /
        ```""",
        r"""```text
      .---.
     /     \
    | O   O |
     \  ^  /
      |||||
      `---'
     [DEATH]
        ```"""
    ],

    "hacked": [
        r"""```text
[root@zara:~]# _
        ```""",
        r"""```text
[root@zara:~]# bypass_sec -f
        ```""",
        r"""```text
[root@zara:~]# bypass_sec -f
[>] Injecting payload...
        ```""",
        r"""```text
[root@zara:~]# bypass_sec -f
[>] Injecting payload...
[>] Firewall breached.
        ```""",
        r"""```text
╔═════════════════╗
║  SYSTEM HACKED  ║
╚═════════════════╝
        ```"""
    ],

    "scythe": [
        r"""```text
   ____
  /   /
        ```""",
        r"""```text
   ____
  /   /
 /   /
|   /
        ```""",
        r"""```text
   ____
  /   /
 /   /
|   /
|  /
| /
        ```""",
        r"""```text
   ____
  /   /
 /   /
|   /
|  /
| /
|/
|
|
        ```"""
    ],

    "spider": [
        r"""```text
   /\  /\
        ```""",
        r"""```text
   /\  /\
  /  \/  \
        ```""",
        r"""```text
   /\  /\
  /  \/  \
  | |  | |
        ```""",
        r"""```text
   /\  /\
  /  \/  \
  | |  | |
  (O)__(O)
  [VENOM!]
        ```"""
    ],

    "bomb": [
        r"""```text
[██░░░░░░░░] 20%
        ```""",
        r"""```text
[█████░░░░░] 50%
        ```""",
        r"""```text
[██████████] 99%
        ```""",
        r"""```text
 \ \ | / /
-  BAM!  -
 / / | \ \
        ```"""
    ]
}

# ==========================================
# 🎮 UNIVERSAL ANIMATION RUNNER
# ==========================================
@Client.on_message(filters.command(list(DARK_ANIMS.keys()), prefixes=[".", "!", "/"]) & filters.me)
async def dark_anim_runner(client, message: Message):
    cmd = message.command[0].lower()
    frames = DARK_ANIMS.get(cmd)
    
    if not frames:
        return
        
    for frame in frames:
        try:
            await message.edit(frame)
            await asyncio.sleep(0.6) # 🔥 Dark mode needs slight delay to build suspense
        except FloodWait as e:
            await asyncio.sleep(e.value + 1)
        except Exception:
            pass

