import asyncio
import os
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    """Converts text to Small Caps for Hacker Look."""
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🎭 METHOD 1: THE DOPPELGÄNGER (FULL DEEP-CLONE)
# ==========================================
@Client.on_message(filters.command(["fake", ], prefixes=[".", "!", "/"]) & filters.me)
async def doppelganger_mode(client: Client, message: Message):
    if len(message.command) < 3:
        return await eor(message, f"⚠️ **{sm('usage')}**: `.fake @username <msg>`\n💡 `{sm('example')}: .fake @durov system compromised`")

    target_uname = message.command[1]
    fake_text = message.text.split(None, 2)[2] 
    
    anim = await eor(message, f"🧬 `{sm('extracting target dna & visuals')}...`")
    
    # Backup variables initialize
    my_fname, my_lname, my_bio = "", "", ""
    photo_path = None
    
    try:
        # 1. Fetch Target Details & Download DP
        target_user = await client.get_users(target_uname)
        fake_fname = target_user.first_name or "Unknown"
        fake_lname = target_user.last_name or ""
        
        if target_user.photo:
            photo_path = await client.download_media(target_user.photo.big_file_id)
        
        # 2. Save Your Original Details safely
        my_info = await client.get_me()
        my_chat = await client.get_chat(my_info.id) 
        
        my_fname = my_info.first_name or ""
        my_lname = my_info.last_name or ""
        my_bio = my_chat.bio or ""

        await anim.edit(f"🎭 `{sm('morphing identity and face')}...`")
        
        # 3. Apply Fake Identity (Name, Bio AND DP)
        await client.update_profile(first_name=fake_fname, last_name=fake_lname, bio="ZARA SYSTEM: DEEP-CLONE ACTIVE")
        if photo_path:
            await client.set_profile_photo(photo=photo_path)
            
        await asyncio.sleep(0.5) # Server sync
        
        # 4. Send the Fake Message
        await client.send_message(message.chat.id, fake_text)
        
        # 5. Clean up evidence
        await message.delete()
        
        # 6. Revert Identity instantly
        await client.update_profile(first_name=my_fname, last_name=my_lname, bio=my_bio)
        
        # 7. Delete the Fake DP from your profile
        if photo_path:
            async for photo in client.get_chat_photos("me", limit=1):
                await client.delete_profile_photos(photo.file_id)
            os.remove(photo_path) # Delete local downloaded file

    except Exception as e:
        await anim.edit(f"❌ **{sm('identity morph failed')}**: `{e}`")
        # 🛡️ Fail-Safe Protocol: Ensure everything reverts
        try:
            if my_fname: 
                await client.update_profile(first_name=my_fname, last_name=my_lname, bio=my_bio)
            if photo_path and os.path.exists(photo_path):
                os.remove(photo_path)
        except: pass


# ==========================================
# 🖼️ METHOD 2: THE QUOTE FORGER (NATIVE BLOCKQUOTES)
# ==========================================
@Client.on_message(filters.command(["fq", ], prefixes=[".", "!", "/"]) & filters.me)
async def quote_forger(client: Client, message: Message):
    if len(message.command) < 3:
        return await eor(message, f"⚠️ **{sm('usage')}**: `.fq @username <msg>`")

    target_uname = message.command[1]
    fake_text = message.text.split(None, 2)[2]
    
    try:
        # Fetch Target Details for realism
        target_user = await client.get_users(target_uname)
        name = target_user.first_name or "Unknown"
        if target_user.last_name:
            name += f" {target_user.last_name}"
            
        username_display = target_user.username or "Hidden_ID"
            
        # Create a Fake Forward Visual Block using Native Blockquotes (>)
        # Ye Telegram app mein ek proper line quote ki tarah dikhega
        fake_forward_ui = (
            f"👤 **{name}** (`@{username_display}`)\n"
            f"> {fake_text}\n\n"
            f"🕒 `{sm('today at')} {message.date.strftime('%H:%M')}` | 👁️ `{sm('forwarded')}`"
        )
        
        await eor(message, fake_forward_ui)

    except Exception as e:
        await eor(message, f"❌ **{sm('quote engine failed')}**: `{e}`")

