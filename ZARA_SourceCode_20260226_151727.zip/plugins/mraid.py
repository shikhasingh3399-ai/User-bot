import asyncio
import random
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait
from motor.motor_asyncio import AsyncIOMotorClient

# ==========================================
# ⚙️ CONFIGURATION
# ==========================================
try:
    from config import MONGO_URI 
except ImportError:
    print("❌ ERROR: Config file me MONGO_URI nahi mila!")
    MONGO_URI = None

HARDCODED_OWNER = 8036881129 # 🔥 Teri ID yahan fix kar di

# ==========================================
# ⚡ GLOBAL VARIABLES
# ==========================================
mongo = None
love_collection = None
MRAID_STATUS = {} 
LOVE_CACHE = [] 

DEFAULT_LOVE = [
    "I Love You Meri Jaan! ❤️",
    "Tu meri duniya hai baby! 🌹",
    "Suno na, tum bahut cute ho! 💖",
    "Sirf tum aur main, hamesha! 💑"
]

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ', 'v': 'ᴠ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🔌 SMART CONNECT (Crash Proof)
# ==========================================
async def check_db_connection(message=None):
    global mongo, love_collection, LOVE_CACHE
    
    if not MONGO_URI:
        if message: await eor(message, f"❌ **{sm('ERROR')}**: `{sm('MONGO_URI not found in config!')}`")
        return False

    if mongo: return True

    try:
        mongo = AsyncIOMotorClient(MONGO_URI)
        db = mongo["ZARA_BOTNET"] 
        love_collection = db["love_data"]
        
        temp = []
        async for doc in love_collection.find():
            if "text" in doc: temp.append(doc["text"])
            
        if temp: LOVE_CACHE = temp
        else: LOVE_CACHE = DEFAULT_LOVE
            
        return True
    except Exception as e:
        if message: await eor(message, f"❌ **{sm('DB ERROR')}**: `{e}`")
        return False

# ==========================================
# ➕ COMMAND: ADD MRAID (STRICTLY OWNER ONLY)
# ==========================================
# 🔥 Yahan filters.user(HARDCODED_OWNER) laga diya hai!
@Client.on_message(filters.command("addmraid", prefixes=[".", "!", "/"]) & filters.user(HARDCODED_OWNER) & filters.me)
async def add_love(client, message: Message):
    if not message.reply_to_message or not message.reply_to_message.text:
        return await eor(message, f"❌ **{sm('REPLY TO TEXT TO ADD TO DB')}**")

    if not await check_db_connection(message): return

    msg = await eor(message, f"⚡ **{sm('UPLOADING TO MAINFRAME')}...**")
    lines = message.reply_to_message.text.split("\n")
    new_entries = [{"text": x.strip()} for x in lines if x.strip()]

    if new_entries:
        await love_collection.insert_many(new_entries)
        for x in new_entries: LOVE_CACHE.append(x["text"])
        await msg.edit(f"✅ **{sm('ADDED')} {len(new_entries)} {sm('LINES TO RAID DATABASE!')}**")
    else:
        await msg.edit(f"⚠️ **{sm('EMPTY TEXT')}**")

# ==========================================
# 🗑️ COMMAND: CLEAR MRAID (BONUS: OWNER ONLY)
# ==========================================
@Client.on_message(filters.command("clearmraid", prefixes=[".", "!", "/"]) & filters.user(HARDCODED_OWNER) & filters.me)
async def clear_love(client, message: Message):
    if not await check_db_connection(message): return
    global LOVE_CACHE
    
    msg = await eor(message, f"⚡ **{sm('WIPING RAID DATABASE')}...**")
    try:
        await love_collection.delete_many({})
        LOVE_CACHE = DEFAULT_LOVE
        await msg.edit(f"🗑️ **{sm('DATABASE CLEARED! REVERTED TO DEFAULT.')}**")
    except Exception as e:
        await msg.edit(f"❌ **{sm('ERROR')}**: `{e}`")

# ==========================================
# 💘 COMMAND: MRAID (MAIN FOR ALL USERS)
# ==========================================
# Ye sab log use kar sakte hain
@Client.on_message(filters.command("mraid", prefixes=[".", "!", "/"]) & filters.me)
async def start_raid(client, message: Message):
    if not await check_db_connection(message): return

    target = None
    count = 10
    
    if message.reply_to_message:
        target = message.reply_to_message.from_user
        if len(message.command) > 1 and message.command[1].isdigit():
            count = int(message.command[1])
    elif len(message.command) > 1:
        try:
            u = message.command[1]
            target = await client.get_users(int(u) if u.lstrip('-').isdigit() else u)
            if len(message.command) > 2 and message.command[2].isdigit(): 
                count = int(message.command[2])
        except:
            return await eor(message, f"❌ **{sm('USER INVALID')}**")

    if not target:
        return await eor(message, f"⚠️ **{sm('TARGET MISSING')}**")

    mention = f"@{target.username}" if target.username else f"[{target.first_name}](tg://user?id={target.id})"
    
    # Session-specific tracking (Zaruri hai multi-client ke liye)
    session_id = f"{client.me.id}_{message.chat.id}"
    MRAID_STATUS[session_id] = True
    
    await eor(message, f"💘 **{sm('RAID INITIATED')}**\n🎯 **{sm('TARGET')}**: {mention}\n🔢 **{sm('COUNT')}**: `{count}`")
    
    ammo = LOVE_CACHE if LOVE_CACHE else DEFAULT_LOVE
    i = 0
    
    while i < count:
        if not MRAID_STATUS.get(session_id, False): break
        try:
            await client.send_message(message.chat.id, f"{random.choice(ammo)} {mention}")
            i += 1
            await asyncio.sleep(1.5) # 🔥 Changed from 0.05 to 1.5 to prevent INSTANT BAN
        except FloodWait as e:
            await asyncio.sleep(e.value + 2)
        except Exception:
            await asyncio.sleep(2)

    MRAID_STATUS[session_id] = False
    try:
        await client.send_message(message.chat.id, f"✅ **{sm('RAID COMPLETED ON')}** {mention}")
    except: pass

# ==========================================
# 🛑 COMMAND: STOP MRAID (FOR ALL USERS)
# ==========================================
@Client.on_message(filters.command(["stopmraid", ], prefixes=[".", "!", "/"]) & filters.me)
async def stop_raid(client, message: Message):
    session_id = f"{client.me.id}_{message.chat.id}"
    
    if MRAID_STATUS.get(session_id, False):
        MRAID_STATUS[session_id] = False
        await eor(message, f"🛑 **{sm('RAID STOPPED SUCCESSFULLY')}**")
    else:
        await eor(message, f"⚠️ **{sm('NO ACTIVE RAID FOUND IN THIS CHAT')}**")

