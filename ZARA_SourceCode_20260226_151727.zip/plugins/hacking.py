import asyncio
import requests
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from pyrogram import Client, filters
from pyrogram.types import Message

# Thread pool for ultra-fast asynchronous HTTP requests
executor = ThreadPoolExecutor(max_workers=20)

# ==========================================
# 🎨 ZARA HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# Helper function to make async requests non-blocking
def fetch_url(platform, url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        res = requests.get(url, headers=headers, timeout=5)
        if res.status_code == 200:
            return f"✅ **{platform}**: [Link]({url})"
    except: pass
    return None

# ==========================================
# 🕵️‍♂️ COMMAND: SHERLOCK (Ultra-Fast Async Tracker)
# ==========================================
@Client.on_message(filters.command(["track", ], prefixes=[".", "!", "/"]) & filters.me)
async def track_username(client, message: Message):
    if len(message.command) < 2:
        return await eor(message, f"⚠️ **{sm('Usage')}**: `.track <username>`")

    uname = message.command[1]
    anim = await eor(message, f"🔍 **{sm('ZARA SWARM HUNTING')} `@{uname}`...**")
    
    # Expanded OSINT Targets
    sites = {
        "Instagram": f"https://www.instagram.com/{uname}/",
        "GitHub": f"https://github.com/{uname}",
        "Twitter": f"https://twitter.com/{uname}",
        "YouTube": f"https://www.youtube.com/@{uname}",
        "Reddit": f"https://www.reddit.com/user/{uname}",
        "Pinterest": f"https://in.pinterest.com/{uname}/",
        "Snapchat": f"https://www.snapchat.com/add/{uname}",
        "Twitch": f"https://www.twitch.tv/{uname}",
        "Spotify": f"https://open.spotify.com/user/{uname}",
        "Steam": f"https://steamcommunity.com/id/{uname}"
    }

    loop = asyncio.get_event_loop()
    # Running all requests simultaneously for Sigma speed
    tasks = [loop.run_in_executor(executor, fetch_url, platform, url) for platform, url in sites.items()]
    results = await asyncio.gather(*tasks)
    
    found_accounts = [res for res in results if res is not None]

    if not found_accounts:
        await anim.edit(f"💀 **{sm('ZARA OSINT')}** 💀\n\n❌ `{sm('GHOST DETECTED! No accounts found for')} @{uname}`")
    else:
        text = f"💀 **{sm('ZARA DIGITAL FOOTPRINT')}** 💀\n━━━━━━━━━━━━━━━━━━━━\n"
        text += f"🎯 **{sm('TARGET')}**: `@{uname}`\n━━━━━━━━━━━━━━━━━━━━\n"
        text += "\n".join(found_accounts)
        await anim.edit(text, disable_web_page_preview=True)

# ==========================================
# 🌐 COMMAND: WHOIS (Domain Dossier)
# ==========================================
@Client.on_message(filters.command(["whois", ], prefixes=[".", "!", "/"]) & filters.me)
async def whois_lookup(client, message: Message):
    if len(message.command) < 2:
        return await eor(message, f"⚠️ **{sm('Usage')}**: `.whois <website.com>`")

    domain = message.command[1].replace("http://", "").replace("https://", "").split("/")[0]
    anim = await eor(message, f"🌍 **{sm('EXTRACTING DOMAIN DOSSIER...')}**")

    try:
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, requests.get, f"https://networkcalc.com/api/dns/whois/{domain}")
        res = res.json()
        
        if res.get("status") != "OK" or not res.get("whois"):
            return await anim.edit(f"❌ **{sm('DATA CLOAKED OR NOT FOUND')}!**")

        data = res["whois"]
        text = (
            f"🌍 **{sm('ZARA DOMAIN INTELLIGENCE')}** 🌍\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 **{sm('DOMAIN')}**: `{domain}`\n"
            f"🏢 **{sm('REGISTRAR')}**: `{data.get('registrar', 'Unknown')}`\n"
            f"📅 **{sm('REGISTERED')}**: `{data.get('creation_date', 'Unknown')[:10]}`\n"
            f"⏳ **{sm('EXPIRES')}**: `{data.get('expiration_date', 'Unknown')[:10]}`\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
        )
        await anim.edit(text)
    except Exception as e:
        await anim.edit(f"❌ **{sm('API CRASH')}**: `{e}`")

# ==========================================
# 📡 COMMAND: DNS & SUBDOMAIN ENUMERATION
# ==========================================
@Client.on_message(filters.command(["dns", ], prefixes=[".", "!", "/"]) & filters.me)
async def dns_enum(client, message: Message):
    if len(message.command) < 2:
        return await eor(message, f"⚠️ **{sm('Usage')}**: `.dns <website.com>`")

    domain = message.command[1].replace("http://", "").replace("https://", "").split("/")[0]
    anim = await eor(message, f"📡 **{sm('BRUTEFORCING DNS RECORDS...')}**")

    try:
        loop = asyncio.get_event_loop()
        # Using HackerTarget API for OSINT
        res = await loop.run_in_executor(None, requests.get, f"https://api.hackertarget.com/hostsearch/?q={domain}")
        data = res.text

        if "error" in data.lower() or not data:
            return await anim.edit(f"❌ **{sm('NO SUBDOMAINS FOUND FOR')} `{domain}`**")

        lines = data.split("\n")[:15] # Limit to top 15 results
        result_text = f"📡 **{sm('ZARA DNS ENUMERATION')}** 📡\n━━━━━━━━━━━━━━━━━━━━\n"
        for line in lines:
            if "," in line:
                sub, ip = line.split(",", 1)
                result_text += f"🔹 `{sub}` ➔ `{ip}`\n"

        await anim.edit(result_text)
    except Exception as e:
        await anim.edit(f"❌ **{sm('SYSTEM ERROR')}**: `{e}`")

# ==========================================
# 🩸 COMMAND: DATA BREACH SCANNER
# ==========================================
@Client.on_message(filters.command(["breach", ], prefixes=[".", "!", "/"]) & filters.me)
async def breach_scanner(client, message: Message):
    if len(message.command) < 2:
        return await eor(message, f"⚠️ **{sm('Usage')}**: `.breach <email@example.com>`")

    email = message.command[1]
    anim = await eor(message, f"🩸 **{sm('SCANNING DARK WEB DATABASES...')}**")

    try:
        loop = asyncio.get_event_loop()
        # Using XposedOrNot free API
        res = await loop.run_in_executor(None, requests.get, f"https://api.xposedornot.com/v1/check-email/{email}")
        
        if res.status_code == 404:
            return await anim.edit(f"✅ **{sm('SAFE')}!**\n`{sm('This email was NOT found in any public data breaches.')}`")
            
        data = res.json()
        if "breaches" in data:
            breaches = data["breaches"][0][:5] # Show top 5 breaches
            text = (
                f"🩸 **{sm('ZARA BREACH ALERT')}** 🩸\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"🎯 **{sm('TARGET')}**: `{email}`\n"
                f"⚠️ **{sm('STATUS')}**: `{sm('COMPROMISED')}`\n\n"
                f"🔓 **{sm('FOUND IN LEAKS')}**:\n"
            )
            for b in breaches:
                text += f"👉 `{b}`\n"
            text += f"\n💀 *{sm('Password change highly recommended!')}*"
            await anim.edit(text)
        else:
            await anim.edit(f"⚠️ **{sm('Unknown response from breach server.')}**")

    except Exception as e:
        await anim.edit(f"❌ **{sm('API CRASH')}**: `{e}`")


