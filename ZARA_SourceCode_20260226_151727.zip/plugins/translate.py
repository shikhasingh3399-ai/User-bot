import asyncio
import time
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from googletrans import Translator, LANGUAGES

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

# ==========================================
# ⚙️ INITIALIZATION
# ==========================================
tr_engine = Translator()

# ==========================================
# 🌐 NEURAL TRANSLATOR COMMAND (USERBOT PRO)
# ==========================================
# 🔥 Wapas filters.me laga diya! Ab sirf owner ka account hi trigger hoga.
@Client.on_message(filters.command(["tr", ], prefixes=".") & filters.me)
async def zara_translator(client, message: Message):
    # 1. INPUT ACQUISITION
    target_lang = None
    text_to_scan = None
    
    if len(message.command) > 1:
        possible_lang = message.command[1].lower()
        if len(possible_lang) == 2 and possible_lang in LANGUAGES:
            target_lang = possible_lang
            if len(message.command) > 2:
                text_to_scan = message.text.split(None, 2)[2]
        else:
            text_to_scan = message.text.split(None, 1)[1]
            
    # Check Reply
    if not text_to_scan and message.reply_to_message:
        text_to_scan = message.reply_to_message.text or message.reply_to_message.caption

    if not text_to_scan:
        return await message.edit(f"⚠️ **{sm('syntax error')}**: `.tr <lang> <text>` or `reply`")

    # 2. HACKING ANIMATION
    start_time = time.time()
    await message.edit(f"⚡ **{sm('intercepting language packets')}...**")
    await asyncio.sleep(0.3)
    
    try:
        # 3. SMART DETECTION
        detection = await asyncio.to_thread(tr_engine.detect, text_to_scan)
        src_lang = detection.lang
        
        # 4. AUTO-TARGET LOGIC
        if not target_lang:
            if src_lang == 'en': target_lang = 'hi'
            else: target_lang = 'en'
        
        # 5. TRANSLATION EXECUTION
        result = await asyncio.to_thread(tr_engine.translate, text_to_scan, dest=target_lang)
        
        end_time = time.time()
        duration = round((end_time - start_time) * 1000, 2)

        # 6. DATA VISUALIZATION
        src_name = LANGUAGES.get(src_lang, src_lang).title()
        dest_name = LANGUAGES.get(target_lang, target_lang).title()
        
        report = f"🧬 **{sm('NEURAL DECODER v4.0')}**\n"
        report += f"━━━━━━━━━━━━━━━━━━━━\n"
        report += f"🔰 **{sm('origin')}**: `{src_name}` ➔ `{dest_name}`\n"
        report += f"⏱️ **{sm('latency')}**: `{duration}ms`\n\n"
        
        report += f"📝 **{sm('INPUT DATA')}**:\n"
        report += f"`{text_to_scan[:60]}...`\n\n" if len(text_to_scan) > 60 else f"`{text_to_scan}`\n\n"
        
        report += f"🔓 **{sm('DECRYPTED OUTPUT')}**:\n"
        report += f"**{result.text}**\n"
        report += f"━━━━━━━━━━━━━━━━━━━━\n"
        report += f"💀 **{sm('ZARA BOTNET')}**"

        await message.edit(report)

    except Exception as e:
        await message.edit(f"❌ **{sm('decryption failed')}**: `{str(e)[:50]}`")

