import asyncio
import os
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🎨 FONT DICTIONARY FOR TYPEWRITER
# ==========================================
FONTS = {
    "1": str.maketrans("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴩqʀꜱᴛᴜᴠᴡxʏᴢᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴩQʀꜱᴛᴜᴠᴡxʏᴢ"), # ZARA Small Caps
    "2": str.maketrans("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭"), # Bold Sans
    "3": str.maketrans("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ"), # Double Struck (Hacker)
    "4": str.maketrans("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ")  # Circles
}

# 👑 OWNER ID (Hardcore Lock)
OWNER_ID = 8036881129


# ==========================================
# 🧟‍♂️ 1. ZOMBIES COMMAND (Dot ke sath, Sirf Bot wale ke liye)
# ==========================================
@Client.on_message(filters.command("zombies", prefixes=".") & filters.group & filters.me)
async def count_zombies(client: Client, message: Message):
    msg = await message.edit_text("⚙️ ꜱᴄᴀɴɴɪɴɢ ꜰᴏʀ ᴢᴏᴍʙɪᴇꜱ (ᴅᴇʟᴇᴛᴇᴅ ᴀᴄᴄᴏᴜɴᴛꜱ)...")
    
    deleted_count = 0
    async for member in client.get_chat_members(message.chat.id):
        if member.user.is_deleted:
            deleted_count += 1
            
    if deleted_count > 0:
        await msg.edit_text(
            f"🧟‍♂️ **ᴢᴏᴍʙɪᴇ ᴀʟᴇʀᴛ!** 🧟‍♂️\n\n"
            f"‣ ɪꜱ ɢʀᴏᴜᴩ ᴍᴇɪɴ ᴛᴏᴛᴀʟ **{deleted_count}** ᴅᴇʟᴇᴛᴇᴅ ᴀᴄᴄᴏᴜɴᴛꜱ (ʙʜᴏᴏᴛ) ʜᴀɪɴ! 💀\n"
            f"‣ ᴛᴇɴꜱɪᴏɴ ᴍᴀᴛ ʟᴇ, ᴋɪꜱɪ ᴋᴏ ᴋɪᴄᴋ ɴᴀʜɪ ᴋɪʏᴀ ʜᴀɪ."
        )
    else:
        await msg.edit_text("✅ ɢʀᴏᴜᴩ ᴇᴋᴅᴀᴍ ᴄʟᴇᴀɴ ʜᴀɪ, ᴋᴏɪ ᴢᴏᴍʙɪᴇ ɴᴀʜɪ ᴍɪʟᴀ! ✨")


# ==========================================
# 💀 2. THE TARGETED HACK PRANK (Dot ke sath, Sirf Bot wale ke liye)
# ==========================================
@Client.on_message(filters.command("hack", prefixes=".") & filters.me)
async def hack_prank(client: Client, message: Message):
    target_user = None
    
    if message.reply_to_message:
        target_user = message.reply_to_message.from_user
    elif len(message.command) > 1:
        try:
            target_user = await client.get_users(message.command[1])
        except:
            return await message.edit_text("❌ ᴛᴀʀɢᴇᴛ ɴᴀʜɪ ᴍɪʟᴀ ʙʜᴀɪ! ꜱᴀʜɪ ᴜꜱᴇʀɴᴀᴍᴇ/ɪᴅ ᴅᴇ ʏᴀ ʀᴇᴩʟʏ ᴋᴀʀ.")
    else:
        return await message.edit_text("❌ ᴋɪꜱᴋᴏ ʜᴀᴄᴋ ᴋᴀʀɴᴀ ʜᴀɪ? ʀᴇᴩʟʏ ᴋᴀʀ ʏᴀ ᴜꜱᴇʀɴᴀᴍᴇ/ɪᴅ ᴅᴇ!")

    target_name = target_user.first_name if target_user.first_name else "Target"
    
    hacking_steps = [
        f"⚙️ `[10%] Lᴏᴄᴀᴛɪɴɢ {target_name}'s IP Aᴅᴅʀᴇss...`",
        f"🌐 `[25%] Bʏᴘᴀssɪɴɢ {target_name}'s Sᴇᴄᴜʀɪᴛʏ Fɪʀᴇᴡᴀʟʟ...`",
        "📂 `[50%] Exᴛʀᴀᴄᴛɪɴɢ Hɪᴅᴅᴇɴ Fɪʟᴇs (Gᴀʟʟᴇʀʏ & Cʜᴀᴛs)...`",
        "📡 `[75%] Uᴘʟᴏᴀᴅɪɴɢ ᴛᴏ ZARA Mᴀɪɴ Sᴇʀᴠᴇʀ...`",
        "✅ `[100%] Uᴘʟᴏᴀᴅ Cᴏᴍᴘʟᴇᴛᴇ! Dᴀᴛᴀ Sᴇᴄᴜʀᴇᴅ.`"
    ]
    
    for step in hacking_steps:
        await message.edit_text(step)
        await asyncio.sleep(1.5) 
        
    try:
        await message.edit_text("⚙️ `Fᴇᴛᴄʜɪɴɢ Bᴏss Dᴇᴛᴀɪʟs...`")
        boss = await client.get_users("@Reflex_x_zara")
        
        boss_name = boss.first_name if boss.first_name else "ZARA ADMIN"
        boss_username = f"@{boss.username}" if boss.username else "@Reflex_x_zara"
        
        try:
            full_boss = await client.get_chat("@Reflex_x_zara")
            boss_bio = full_boss.bio if full_boss.bio else "⚡ 𝗭𝗔𝗥𝗔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗢𝗪𝗡𝗘𝗥 ⚡"
        except:
            boss_bio = "⚡ 𝗭𝗔𝗥𝗔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗢𝗪𝗡𝗘𝗥 ⚡"

        caption_text = (
            f"🚨 **𝗔𝗟𝗘𝗥𝗧: 𝗦𝗬𝗦𝗧𝗘𝗠 𝗖𝗢𝗠𝗣𝗥𝗢𝗠𝗜𝗦𝗘𝗗** 🚨\n\n"
            f"🎯 **ᴛᴀʀɢᴇᴛ:** {target_user.mention}\n\n"
            f"ᴛᴇʀᴀ ꜱᴀᴀʀᴀ ᴅᴀᴛᴀ, ᴩʜᴏᴛᴏꜱ ᴀᴜʀ ᴄʜᴀᴛꜱ ᴍᴇʀᴇ ʙᴏꜱꜱ ᴋᴇ ꜱᴇʀᴠᴇʀ ᴩᴇ ᴜᴩʟᴏᴀᴅ ʜᴏ ᴄʜᴜᴋᴀ ʜᴀɪ! 💀\n\n"
            f"🛑 **ᴜᴩʟᴏᴀᴅ ᴄᴀɴᴄᴇʟ ᴋᴀʀɴᴇ ᴋᴇ ʟɪʏᴇ ᴍᴇʀᴇ ʙᴏꜱꜱ ᴋᴏ ᴅᴍ ᴋᴀʀ ᴀʙʜɪ:**\n\n"
            f"👤 **ɴᴀᴍᴇ:** {boss_name}\n"
            f"🌐 **ᴜꜱᴇʀɴᴀᴍᴇ:** {boss_username}\n"
            f"📝 **ʙɪᴏ:** `{boss_bio}`\n\n"
            f"⏳ *ᴊᴀʟᴅɪ ᴍᴀᴀꜰɪ ᴍᴀᴀɴɢ ʟᴇ ᴡᴀʀɴᴀ ᴅᴀᴛᴀ ʟᴇᴀᴋ ʜᴏ ᴊᴀʏᴇɢᴀ!*"
        )

        if boss.photo:
            photo_path = await client.download_media(boss.photo.big_file_id)
            await message.delete() 
            await client.send_photo(
                chat_id=message.chat.id,
                photo=photo_path,
                caption=caption_text
            )
            os.remove(photo_path) 
        else:
            await message.edit_text(caption_text)

    except Exception as e:
        await message.edit_text(f"⚠️ Boss ka data nikalne me error: `{e}`")


# ==========================================
# ⌨️ 3. TYPEWRITER (Bina Dot ke, ONLY FOR OWNER ID)
# ==========================================
@Client.on_message(filters.command("type", prefixes="") & filters.user(OWNER_ID))
async def type_text(client: Client, message: Message):
    # Check syntax: type [font_number] [message]
    if len(message.command) < 3:
        return await message.edit_text(
            "❌ **ɢᴀʟᴀᴛ ᴛᴀʀᴇᴇᴋᴀ ʙʜᴀɪ!**\n\n"
            "**Sʏɴᴛᴀx:** `type [1-4] [Message]`\n"
            "**Exᴀᴍᴘʟᴇ:** `type 1 ZARA SYSTEM`\n\n"
            "**Fᴏɴᴛs:**\n"
            "1 = ꜱᴍᴀʟʟ ᴄᴀᴩꜱ (ZARA Style)\n"
            "2 = 𝗯𝗼𝗹𝗱 𝘀𝗮𝗻𝘀\n"
            "3 = 𝔻𝕠𝕦𝕓𝕝𝕖 𝕊𝕥𝕣𝕦𝕔𝕜\n"
            "4 = Ⓒⓘⓡⓒⓛⓔⓢ"
        )
    
    font_choice = message.command[1]
    text = message.text.split(None, 2)[2] 
    
    if font_choice in FONTS:
        text = text.translate(FONTS[font_choice])
    else:
        return await message.edit_text("❌ Fᴏɴᴛ Nᴜᴍʙᴇʀ sɪʀғ 1 sᴇ 4 ᴛᴀᴋ ʜᴀɪ!")

    typed_text = ""
    for char in text:
        typed_text += char
        try:
            await message.edit_text(f"`{typed_text} █`")
            await asyncio.sleep(0.1) 
        except:
            pass
    await message.edit_text(f"**{typed_text}**") 

