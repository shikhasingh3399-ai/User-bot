import os
import asyncio
import random
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import UsernameOccupied, UsernameInvalid, FloodWait, PhotoCropSizeSmall

# ==========================================
# 💀 ZARA HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 📸 COMMAND: SET PFP (Profile Picture)
# ==========================================
@Client.on_message(filters.command(["setpfp", ], prefixes=[".", "!", "/"]) & filters.me)
async def set_profile_pic(client, message: Message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await eor(message, f"❌ **{sm('ABE LAUDE KISI PHOTO PE REPLY TO KAR')}**")

    anim = await eor(message, f"⚡ **{sm('DOWNLOADING VISUAL DATA...')}**")
    try:
        photo_path = await message.reply_to_message.download()
        await anim.edit(f"🧬 **{sm('INJECTING TO MAINFRAME...')}**")
        await client.set_profile_photo(photo=photo_path)
        await anim.edit(f"✅ **{sm('PROFILE PICTURE UPDATED SUCCESSFULLY')} 💀**")
        os.remove(photo_path)
    except Exception as e:
        await anim.edit(f"❌ **{sm('ERROR')}**: `{e}`")

# ==========================================
# 🗑️ COMMAND: DEL ALL PFP (Wipe All DPs)
# ==========================================
@Client.on_message(filters.command(["wipepfp", ], prefixes=[".", "!", "/"]) & filters.me)
async def wipe_all_pfps(client, message: Message):
    anim = await eor(message, f"⚡ **{sm('SCANNING PROFILE DATABASE...')}**")
    try:
        photos = [p.file_id async for p in client.get_chat_photos("me")]
        if not photos:
            return await anim.edit(f"⚠️ **{sm('TERI PROFILE PE KUCH HAI HI NAHI LAUDE')}**")
        
        await anim.edit(f"🔥 **{sm('DELETING')} {len(photos)} {sm('PHOTOS FROM SERVER...')}**")
        await client.delete_profile_photos(photos)
        await anim.edit(f"🗑️ **{sm('ALL PHOTOS WIPED! GHOST MODE ACTIVE')} 👻**")
    except Exception as e:
        await anim.edit(f"❌ **{sm('SYSTEM CRASH')}**: `{e}`")

# ==========================================
# 🗑️ COMMAND: DEL PFP (Delete Only Current DP)
# ==========================================
@Client.on_message(filters.command(["delpfp", ], prefixes=[".", "!", "/"]) & filters.me)
async def del_current_pfp(client, message: Message):
    try:
        photos = [p.file_id async for p in client.get_chat_photos("me", limit=1)]
        if not photos:
            return await eor(message, f"⚠️ **{sm('NO DP FOUND TO DELETE')}**")
        
        await client.delete_profile_photos(photos[0])
        await eor(message, f"🗑️ **{sm('CURRENT DP DELETED')} 💀**")
    except Exception as e:
        await eor(message, f"❌ **{sm('ERROR')}**: `{e}`")

# ==========================================
# 📝 COMMAND: SET BIO
# ==========================================
@Client.on_message(filters.command("setbio", prefixes=[".", "!", "/"]) & filters.me)
async def set_bio_cmd(client, message: Message):
    if len(message.command) == 1:
        return await eor(message, f"⚠️ **{sm('USAGE')}:** `.setbio <text>`")
    
    bio_text = message.text.split(None, 1)[1]
    if len(bio_text) > 70:
        return await eor(message, f"❌ **{sm('BIO BAHUT BADA HAI LAUDE! 70 CHARACTERS LIMIT HAI')}**")

    try:
        await client.update_profile(bio=bio_text)
        await eor(message, f"✅ **{sm('BIO UPDATED TO')}**: `{bio_text}`")
    except Exception as e:
        await eor(message, f"❌ **{sm('ERROR')}**: `{e}`")

# ==========================================
# 📝 COMMAND: SET NAME
# ==========================================
@Client.on_message(filters.command("setname", prefixes=[".", "!", "/"]) & filters.me)
async def set_name_cmd(client, message: Message):
    if len(message.command) == 1:
        return await eor(message, f"⚠️ **{sm('USAGE')}:** `.setname <First> <Last>`")
    
    name_parts = message.text.split(None, 1)[1].split(None, 1)
    first_name = name_parts[0]
    last_name = name_parts[1] if len(name_parts) > 1 else ""

    try:
        await client.update_profile(first_name=first_name, last_name=last_name)
        await eor(message, f"✅ **{sm('IDENTITY CHANGED TO')}**: `{first_name} {last_name}` 💀")
    except Exception as e:
        await eor(message, f"❌ **{sm('ERROR')}**: `{e}`")

# ==========================================
# 🆔 COMMAND: SET USERNAME (With Auto-Suggest)
# ==========================================
@Client.on_message(filters.command(["setusername", ], prefixes=[".", "!", "/"]) & filters.me)
async def set_username_cmd(client, message: Message):
    if len(message.command) == 1:
        return await eor(message, f"⚠️ **{sm('USAGE')}:** `.setusername <new_username>`")
    
    new_username = message.command[1].replace("@", "")
    anim = await eor(message, f"⚡ **{sm('CHECKING USERNAME AVAILABILITY...')}**")
    
    try:
        await client.set_username(new_username)
        await anim.edit(f"✅ **{sm('USERNAME SUCCESSFULLY SET TO')}**: `@{new_username}` 👑")
        
    except UsernameOccupied:
        # 🔥 The Auto-Suggest System
        suggestions = [
            f"{new_username}_zara",
            f"{new_username}xd",
            f"{new_username}botnet",
            f"real_{new_username}",
            f"{new_username}{random.randint(10, 99)}"
        ]
        sug_text = "\n".join([f"👉 `@{s}`" for s in suggestions])
        await anim.edit(
            f"❌ **{sm('ABE LAUDE YE USERNAME KISI AUR NE LE RAKHA HAI')}!**\n\n"
            f"💡 **{sm('YE TRY KAR')}**:\n{sug_text}"
        )
        
    except UsernameInvalid:
        await anim.edit(f"❌ **{sm('INVALID FORMAT!')}** `{sm('SIRF LETTERS AUR NUMBERS DAL BE')}`")
    except Exception as e:
        await anim.edit(f"❌ **{sm('SYSTEM CRASH')}**: `{e}`")


