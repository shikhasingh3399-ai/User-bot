import os
import time
import asyncio
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message
import yt_dlp

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 📊 SIGMA PROGRESS BAR (FOR UPLOAD)
# ==========================================
async def upload_progress(current, total, message, start_time):
    now = time.time()
    diff = now - start_time
    
    # Har 3 second me update karega taaki FloodWait na aaye
    if round(diff % 3.00) == 0 or current == total:
        try:
            percentage = current * 100 / total
            speed = current / diff if diff > 0 else 0
            
            # Hacker Style Bar
            bar_length = 12
            filled = int(bar_length * percentage // 100)
            bar = "█" * filled + "░" * (bar_length - filled)
            
            text = f"📤 **{sm('UPLOADING TO MAINFRAME...')}**\n"
            text += f"━━━━━━━━━━━━━━━━━━━━\n"
            text += f"📊 **{sm('STATUS')}**: `[{bar}] {round(percentage, 1)}%`\n"
            text += f"🚀 **{sm('SPEED')}**: `{humanbytes(speed)}/s`\n"
            text += f"💾 **{sm('DATA')}**: `{humanbytes(current)} / {humanbytes(total)}`\n"
            text += f"━━━━━━━━━━━━━━━━━━━━\n"
            text += f"💀 **{sm('DON T INTERRUPT THE KERNEL')}**"
            
            await message.edit(text)
        except: pass

def humanbytes(size):
    if not size: return "0 B"
    power = 2**10
    n = 0
    Dic_powerN = {0: 'B', 1: 'KB', 2: 'MB', 3: 'GB', 4: 'TB'}
    while size > power:
        size /= power
        n += 1
    return str(round(size, 2)) + " " + Dic_powerN[n]

def time_formatter(milliseconds: int) -> str:
    seconds, milliseconds = divmod(int(milliseconds), 1000)
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return f"{minutes}m {seconds}s"

# ==========================================
# 🧠 THREADED YT-DLP ENGINE (ANTI-FREEZE)
# ==========================================
def extract_and_download(url, ydl_opts):
    """Is function ko alag thread me chalayenge taaki bot hang na ho"""
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        return info

# ==========================================
# 📹 COMMAND: YTDL SIGMA
# ==========================================
@Client.on_message(filters.command(["dl", "song", ], prefixes=[".", "!", "/"]) & filters.me)
async def execute_hack(client, message: Message):
    if len(message.command) < 2:
        return await eor(message, f"⚠️ **{sm('ABE LAUDE LINK KAHAN HAI?')}**\n`Usage: .ytdl <link>`")
    
    url = message.command[1]
    status = await eor(message, f"🔄 **{sm('YOUTUBE KI FIREWALL TOD RAHA HU...')}**")
    
    if not os.path.exists("Downloads"): os.makedirs("Downloads")
    file_path = f"Downloads/sigma_{int(time.time())}.mp4"
    
    # WEAPON CONFIGURATION
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 
        'outtmpl': file_path,
        'quiet': True,
        'no_warnings': True,
        'geo_bypass': True,
        'nocheckcertificate': True,
    }

    try:
        # 1. DOWNLOADING PHASE (Background Thread)
        await status.edit(f"🧬 **{sm('DOWNLOADING ENCRYPTED PACKETS...')}**\n`{sm('wait kar laude, background me chal raha hai...')}`")
        
        info = await asyncio.to_thread(extract_and_download, url, ydl_opts)
        
        title = info.get('title', 'Unknown Target')
        uploader = info.get('uploader', 'Unknown Channel')
        duration = info.get('duration', 0)
        
        # 2. UPLOAD PHASE
        start_time = time.time()
        
        caption_text = f"📂 **{sm('FILE EXFILTRATED SUCCESSFULLY!')}**\n"
        caption_text += f"━━━━━━━━━━━━━━━━━━━━\n"
        caption_text += f"🎬 **{sm('TITLE')}**: `{title}`\n"
        caption_text += f"👤 **{sm('VICTIM')}**: `{uploader}`\n"
        caption_text += f"⏳ **{sm('DURATION')}**: `{time_formatter(duration * 1000)}`\n"
        caption_text += f"━━━━━━━━━━━━━━━━━━━━\n"
        caption_text += f"☠️ **{sm('EXTRACTED BY SIGMA KERNEL')}**"
        
        await client.send_video(
            chat_id=message.chat.id,
            video=file_path,
            caption=caption_text,
            supports_streaming=True,
            progress=upload_progress,
            progress_args=(status, start_time)
        )
        
        # 3. ERASE EVIDENCE
        os.remove(file_path)
        await status.delete()

    except Exception as e:
        error_msg = str(e).lower()
        if "ffmpeg" in error_msg:
            await status.edit(f"❌ **{sm('SYSTEM KI GAND PHAT GAYI')}!**\n`FFMPEG Missing. Terminal me 'apt install ffmpeg' pel de.`")
        elif "video is unavailable" in error_msg:
            await status.edit(f"❌ **{sm('MISSION FAILED')}**\n`Video private ya delete ho chuki hai.`")
        else:
            await status.edit(f"❌ **{sm('UNKNOWN ERROR')}**\n`{str(e)[:100]}...`")
        
        if os.path.exists(file_path): os.remove(file_path)

