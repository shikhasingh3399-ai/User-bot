import asyncio
import random
import unicodedata
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait

# ==========================================
# 🎨 ZARA MULTI-FONT ENGINE
# ==========================================
def apply_font(text, font_type):
    if not text: return ""
    text = str(text)
    normalized = unicodedata.normalize('NFKC', text)
    
    # Font 1: Small Caps (ZARA DEFAULT)
    f1 = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
    
    # Font 2: Gothic Dark
    f2 = {'a': '𝔞', 'b': '𝔟', 'c': '𝔠', 'd': '𝔡', 'e': '𝔢', 'f': '𝔣', 'g': '𝔤', 'h': '𝔥', 'i': '𝔦', 'j': '𝔧', 'k': '𝔨', 'l': '𝔩', 'm': '𝔪', 'n': '𝔫', 'o': '𝔬', 'p': '𝔭', 'q': '𝔮', 'r': '𝔯', 's': '𝔰', 't': '𝔱', 'u': '𝔲', 'v': '𝔳', 'w': '𝔴', 'x': '𝔵', 'y': '𝔶', 'z': '𝔷', 'A': '𝔄', 'B': '𝔅', 'C': 'ℭ', 'D': '𝔇', 'E': '𝔈', 'F': '𝔉', 'G': '𝔊', 'H': 'ℌ', 'I': 'ℑ', 'J': '𝔍', 'K': '𝔎', 'L': '𝔏', 'M': '𝔐', 'N': '𝔑', 'O': '𝔒', 'P': '𝔓', 'Q': '𝔔', 'R': 'ℜ', 'S': '𝔖', 'T': '𝔗', 'U': '𝔘', 'V': '𝔙', 'W': '𝔚', 'X': '𝔛', 'Y': '𝔜', 'Z': 'ℨ'}
    
    # Font 3: Double Struck (VIP)
    f3 = {'a': '𝕒', 'b': '𝕓', 'c': '𝕔', 'd': '𝕕', 'e': '𝕖', 'f': '𝕗', 'g': '𝕘', 'h': '𝕙', 'i': '𝕚', 'j': '𝕛', 'k': '𝕜', 'l': '𝕝', 'm': '𝕞', 'n': '𝕟', 'o': '𝕠', 'p': '𝕡', 'q': '𝕢', 'r': '𝕣', 's': '𝕤', 't': '𝕥', 'u': '𝕦', 'v': '𝕧', 'w': '𝕨', 'x': '𝕩', 'y': '𝕪', 'z': '𝕫', 'A': '𝔸', 'B': '𝔹', 'C': 'ℂ', 'D': '𝔻', 'E': '𝔼', 'F': '𝔽', 'G': '𝔾', 'H': 'ℍ', 'I': '𝕀', 'J': '𝕁', 'K': '𝕂', 'L': '𝕃', 'M': '𝕄', 'N': 'ℕ', 'O': '𝕆', 'P': 'ℙ', 'Q': 'ℚ', 'R': 'ℝ', 'S': '𝕊', 'T': '𝕋', 'U': '𝕌', 'V': '𝕍', 'W': '𝕎', 'X': '𝕏', 'Y': '𝕐', 'Z': 'ℤ'}

    if font_type == "2":
        return "".join(f2.get(c, c) for c in normalized)
    elif font_type == "3":
        return "".join(f3.get(c, c) for c in normalized)
    else: # Default is Font 1
        return "".join(f1.get(c.lower(), c) for c in normalized)


# ==========================================
# ⌨️ 1. ZARA TERMINAL TYPEWRITER (.ttype)
# ==========================================
@Client.on_message(filters.command("ttype", prefixes=".") & filters.me)
async def terminal_typewriter(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.edit(apply_font("⚠️ usage: .ttype <font_number> <text>\nExample: .ttype 2 hello baby", "1"))

    # Check if user provided a font number (1, 2, or 3)
    font_choice = "1"
    text_start_index = 1

    if message.command[1] in ["1", "2", "3"]:
        font_choice = message.command[1]
        text_start_index = 2
        
    if len(message.command) <= text_start_index:
         return await message.edit(apply_font("❌ error: where is the text?", "1"))

    raw_text = " ".join(message.command[text_start_index:])
    styled_text = apply_font(raw_text, font_choice)

    # 🚀 The Hard Animation (No extra loading bars, just pure typing)
    typing_symbol = "█"
    typed_so_far = ""
    
    # Edit in chunks to prevent Telegram FloodWait limits (Safe & Fast)
    chunk_size = 2 if len(styled_text) > 20 else 1 
    
    for i in range(0, len(styled_text), chunk_size):
        typed_so_far += styled_text[i:i+chunk_size]
        try:
            await message.edit(f"{typed_so_far}{typing_symbol}")
            await asyncio.sleep(0.15) # Smooth speed
        except FloodWait as e:
            await asyncio.sleep(e.value)
        except:
            pass
            
    # Final output without the block cursor
    await message.edit(typed_so_far)


# ==========================================
# 🔥 2. SIGMA ROASTER (.roast)
# ==========================================
@Client.on_message(filters.command("roast", prefixes=".") & filters.me)
async def sigma_roaster(client: Client, message: Message):
    if not message.reply_to_message:
        return await message.edit(apply_font("❌ error: reply to a message to roast them!", "1"))

    roasts = [
        "beta, tumhare dimaag ka RAM 2MB ka hai kya? lag kar raha hai tera logic. 💀",
        "tere message padhne se acha main captcha solve kar loon, kam se kam sense toh banega! 🔥",
        "tujhe block nahi karunga, teri baatein dekh ke mujhe free ki comedy milti hai. 😂",
        "beta tu keyboard warrior hai, aur main system administrator... aukaat mein reh! ⚡",
        "teri aukaat utni hi hai, jitna telegram bina internet ke chalta hai... zero! 🗑️",
        "error 404: your brain not found! 🤖"
    ]
    
    selected_roast = random.choice(roasts)
    styled_roast = apply_font(selected_roast, "1")
    
    await message.edit(f"🔥 {styled_roast}")


# ==========================================
# ⏱️ 3. DYNAMIC MATRIX BIO (.livebio on / off)
# ==========================================
LIVE_BIO_RUNNING = False

async def bio_updater(client: Client):
    global LIVE_BIO_RUNNING
    
    quotes = [
        "SYSTEM_COMPROMISED_//",
        "SUPREME_COMMANDER_ONLINE",
        "LIVING_IN_THE_TERMINAL",
        "BYPASSING_FIREWALLS...",
        "GHOST_IN_THE_MACHINE",
        "ZARA_ENGINE_ACTIVE_⚡"
    ]
    
    while LIVE_BIO_RUNNING:
        try:
            # Get current time
            now = datetime.now()
            time_str = now.strftime("%I:%M %p")
            quote = random.choice(quotes)
            
            # Format: ⌚ 12:45 PM | 💻 ZARA_ENGINE_ACTIVE_⚡
            new_bio = apply_font(f"⌚ {time_str} | 💻 {quote}", "1")
            
            # Telegram bio limit is 70 chars, making sure it fits
            await client.update_profile(bio=new_bio[:70])
            
            # Safe Delay: 60 seconds to prevent Telegram ban
            await asyncio.sleep(60)
        except FloodWait as e:
            await asyncio.sleep(e.value + 10)
        except Exception:
            await asyncio.sleep(60)

@Client.on_message(filters.command("livebio", prefixes=".") & filters.me)
async def toggle_livebio(client: Client, message: Message):
    global LIVE_BIO_RUNNING
    
    if len(message.command) < 2 or message.command[1].lower() not in ["on", "off"]:
         return await message.edit(apply_font("⚠️ usage: .livebio on | .livebio off", "1"))
         
    cmd = message.command[1].lower()
    
    if cmd == "on":
        if LIVE_BIO_RUNNING:
            return await message.edit(apply_font("✅ live bio is already running!", "1"))
            
        LIVE_BIO_RUNNING = True
        asyncio.create_task(bio_updater(client)) # Start background task
        await message.edit(apply_font("⏱️ live bio activated! your profile is now dynamic.", "1"))
        
    elif cmd == "off":
        LIVE_BIO_RUNNING = False
        await message.edit(apply_font("🛑 live bio deactivated.", "1"))
        # Reset to default bio
        try:
            await client.update_profile(bio=apply_font("supreme commander offline.", "1"))
        except: pass

