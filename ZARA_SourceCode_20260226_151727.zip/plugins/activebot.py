import asyncio
from pyrogram import Client, filters
from config import ZARA_CLIENTS, OWNER_ID

# ==========================================
# 📡 ZARA KERNEL: TREE-STYLE SWARM RADAR [V3.0]
# ==========================================

@Client.on_message(filters.command("activebot", prefixes=".") & filters.user(OWNER_ID))
async def tree_active_bots(client: Client, message):
    
    # 🔥 MASTER FIX: Sirf TERI ID se message aayega! Baaki 27 bots chup rahenge.
    if client.me.id != OWNER_ID:
        return

    # Check agar matrix khali hai
    if not ZARA_CLIENTS:
        return await message.reply("⚠️ **[SYSTEM ALERT]:** `ZARA_CLIENTS` radar is empty!")

    status_msg = await message.reply("📡 `[ SCANNING ZARA MATRIX... ]`")

    alive_list = []
    dead_list = []

    # Har ek node ko scan karna
    for bot in ZARA_CLIENTS:
        try:
            me = await bot.get_me()
            # Clicky Name ban raha hai yahan
            alive_list.append(f"[{me.first_name}](tg://user?id={me.id}) ⇛ `{me.id}`")
        except Exception:
            uid = getattr(bot, "user_id", "UNKNOWN_ID")
            dead_list.append(f"`{uid}`")

    total_bots = len(ZARA_CLIENTS)
    alive_count = len(alive_list)
    dead_count = len(dead_list)

    # 🌲 TREE STYLE GENERATOR FOR ACTIVE BOTS 🌲
    alive_text = ""
    for i, text in enumerate(alive_list):
        if i == alive_count - 1: # Last item ke liye └──
            alive_text += f"    └── 👤 {text}\n"
        else: # Baaki items ke liye ├──
            alive_text += f"    ├── 👤 {text}\n"

    # 🌲 TREE STYLE GENERATOR FOR DEAD BOTS 🌲
    dead_text = ""
    for i, text in enumerate(dead_list):
        if i == dead_count - 1: # Last item
            dead_text += f"    └── 🪦 {text}\n"
        else:
            dead_text += f"    ├── 🪦 {text}\n"

    # ☠️ CLEAN & PREMIUM REPORT DESIGN ☠️
    final_report = (
        f"💀 **ZARA KERNEL : NODE RADAR**\n"
        f"  ├── 📊 **Total Nodes:** `{total_bots}`\n"
        f"  ├── ✅ **Active:** `{alive_count}`\n"
        f"  └── ❌ **Dead:** `{dead_count}`\n\n"
        f"🟢 **ACTIVE MATRIX:**\n"
        f"{alive_text if alive_text else '    └── `No active bots found!` 😭\n'}\n"
        f"🔴 **DEAD NODES:**\n"
        f"{dead_text if dead_text else '    └── `0 Dead! All Nodes Are Perfect.` 🔥\n'}"
    )

    await status_msg.edit(final_report, disable_web_page_preview=True)

