import os
import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message

# Required for resizing images to Telegram standard (512x512)
try:
    from PIL import Image
except ImportError:
    Image = None

# ==========================================
# 🎨 ZARA KANG ENGINE (STICKER THIEF V2)
# ==========================================
@Client.on_message(filters.command("kang", prefixes=".") & filters.me)
async def kang_sticker(client: Client, message: Message):
    if not message.reply_to_message:
        return await message.edit("❌ **Error:** Reply to a sticker or image to kang it!")

    anim = await message.edit("⏳ `Extracting target media...`")
    reply = message.reply_to_message
    
    # 1. Determine Emoji
    emoji = "😎"
    if len(message.command) > 1:
        emoji = message.command[1]
    elif reply.sticker and reply.sticker.emoji:
        emoji = reply.sticker.emoji

    # 2. Check Media Type
    is_anim = False
    is_video = False
    file_id = None
    
    if reply.sticker:
        is_anim = reply.sticker.is_animated
        is_video = reply.sticker.is_video
        file_id = reply.sticker.file_id
    elif reply.photo:
        file_id = reply.photo.file_id
    elif reply.document and reply.document.mime_type in ["image/png", "image/jpeg", "image/webp"]:
        file_id = reply.document.file_id
    else:
        return await anim.edit("❌ **Error:** Unsupported format! Reply to a photo or sticker.")

    # 3. Download Media
    await anim.edit("📥 `Downloading media...`")
    try:
        # Download as a temp file first
        downloaded_file = await client.download_media(file_id, file_name="kanged_temp_media")
    except Exception as e:
        return await anim.edit(f"❌ **Download failed:** `{e}`")

    # 4. Strict File Formatting (THE FIX)
    if is_video:
        final_file = "kang_video.webm"
    elif is_anim:
        final_file = "kang_anim.tgs"
    else:
        final_file = "kang_static.webp"

    # Image Processing for static stickers
    if not is_anim and not is_video:
        if Image is None:
            return await anim.edit("❌ **Error:** `Pillow` library is missing! Run `pip install Pillow`.")
        await anim.edit("⚙️ `Resizing image to 512x512 pixels...`")
        img = Image.open(downloaded_file)
        img.thumbnail((512, 512))
        img.save(final_file, "WEBP")
        os.remove(downloaded_file)
    else:
        # Rename the file to the strict format Telegram expects
        os.rename(downloaded_file, final_file)

    # 5. Connect to official @Stickers bot
    await anim.edit("💬 `Connecting to @Stickers database...`")
    try:
        await client.unblock_user("Stickers")
    except:
        pass
        
    me = await client.get_me()
    
    # Pack Naming Logic
    pack_type = "animated" if is_anim else "video" if is_video else "static"
    pack_short_name = f"zara_{pack_type}_{me.id}"
    pack_title = f"ZARA {pack_type.title()} | {me.first_name}"
    
    # Auto-Interaction Function
    async def interact(send_msg=None, document=None):
        if document:
            await client.send_document("Stickers", document=document)
        else:
            await client.send_message("Stickers", send_msg)
        await asyncio.sleep(2.5) # Extra 0.5s delay to ensure @Stickers replies
        async for m in client.get_chat_history("Stickers", limit=1):
            return m.text.lower() if m.text else ""

    # 6. Execute @Stickers Bot Logic Flow
    cmd_add = "/addtgs" if is_anim else "/addvideo" if is_video else "/addsticker"
    cmd_new = "/newanimated" if is_anim else "/newvideo" if is_video else "/newpack"
    
    response = await interact(cmd_add)
    
    if "choose" in response:
        response = await interact(pack_short_name)
        if "invalid" in response or "doesn't exist" in response:
            response = await interact(cmd_new)
            if "choose a name" in response or "yay" in response:
                response = await interact(pack_title)
    else:
        response = await interact(cmd_new)
        if "choose a name" in response or "yay" in response:
            response = await interact(pack_title)

    # Upload Sticker
    response = await interact(document=final_file)
    
    # Handle Emoji & Publish
    if "emoji" in response:
        response = await interact(emoji)
        if "publish" in response or "done" in response or "added" in response:
            await interact("/publish")
            await interact("/skip")
            response = await interact(pack_short_name)
            
            await anim.edit(f"✅ **Sticker Kanged Successfully!**\n\n📦 **Pack:** [Click Here to View](https://t.me/addstickers/{pack_short_name})\n🎭 **Emoji:** {emoji}")
        else:
            await anim.edit(f"❌ **Failed at emoji phase:**\n`{response}`")
    else:
        await anim.edit(f"❌ **Upload rejected by @Stickers:**\n`{response}`")

    # 7. Cleanup Local Files
    if os.path.exists(final_file):
        os.remove(final_file)

