import os
import asyncio
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🛑 SIGMA SECURITY: THE VAULT
# ==========================================
BLOCKED_FILES = [
    "config.py", "config.ini", ".env", "session", 
    "zara.session", "zara.session-journal", "token.json",
    "pyrogram.session", "tdata", "config", "mongodb"
]

HARDCODED_OWNER = 8036881129  # 🔥 SUPREME COMMANDER ID

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🧠 SMART FILE SEARCH ENGINE
# ==========================================
def find_file_recursive(target_name):
    ignore_dirs = {'.git', '__pycache__', 'venv', 'env', '.cache', 'downloads'}
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]
        if target_name in files:
            return os.path.join(root, target_name)
    return None

def get_size(bytes_size):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024.0

# ==========================================
# 📂 SIGMA DEMAND COMMAND (STRICTLY OWNER)
# ==========================================
@Client.on_message(filters.command(["demand", ], prefixes=[".", "!", "/"]) & filters.me)
async def demand_file(client, message: Message):
    try:
        # 🔥 THE ULTIMATE AUKAAT CHECK
        if message.from_user.id != HARDCODED_OWNER:
            return await eor(message, f"🛑 **{sm('AUKAAT ME REH LUDE')}!**\n`{sm('YE COMMAND SIRF TERA BAAP (OWNER) USE KAR SAKTA HAI')} 💀`")

        # 1. Check Input
        if len(message.command) < 2:
            return await eor(message, f"⚠️ **{sm('USAGE')}**: `.demand <filename.py>`")
        
        target_input = message.text.split(None, 1)[1].strip()
        
        # 2. 🛡️ SIGMA SECURITY PROTOCOL (Double Check)
        target_lower = target_input.lower()
        if any(blocked in target_lower for blocked in BLOCKED_FILES):
             return await eor(message, f"🛑 **{sm('ACCESS DENIED')}!**\n`{sm('SYSTEM FILES KO HATH MAT LAGA')} 💀`")

        status_msg = await eor(message, f"🔍 **{sm('SCANNING ENEMY TERRITORY...')}**")
        
        # 3. 🧠 PATH LOGIC
        file_path = None
        if os.path.exists(target_input) and os.path.isfile(target_input):
            file_path = target_input
        else:
            file_path = find_file_recursive(target_input)
            
        # 4. DATA EXTRACTION
        if file_path:
            # Savage Animation
            await status_msg.edit(f"⚡ **{sm('TARGET LOCKED')}**: `{file_path}`")
            await asyncio.sleep(0.5)
            await status_msg.edit(f"📤 **{sm('STEALING DATA')}...**\n`[████████░░] 85%`")
            
            file_size = os.path.getsize(file_path)
            formatted_size = get_size(file_size)
            
            # 🔥 CODE PREVIEW ENGINE
            snippet = ""
            if file_path.endswith(('.py', '.txt', '.json', '.sh', '.md', '.yml')):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        lines = f.readlines()[:5] 
                        if lines:
                            code_text = "".join(lines).strip()
                            snippet = f"\n\n**{sm('PREVIEW')} 👁️:**\n```{code_text}\n...```"
                except: pass

            caption_text = (
                f"🩸 **{sm('SYSTEM COMPROMISED')}** 🩸\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📄 **{sm('TARGET')}**: `{os.path.basename(file_path)}`\n"
                f"📍 **{sm('COORDS')}**: `{file_path}`\n"
                f"📦 **{sm('WEIGHT')}**: `{formatted_size}`\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"💀 **{sm('EXTRACTED BY SIGMA KERNEL')}**"
            )
            
            if snippet: caption_text += snippet
            
            # Send Document
            await client.send_document(
                chat_id=message.chat.id,
                document=file_path,
                caption=caption_text
            )
            
            await status_msg.delete()
        else:
            await status_msg.edit(f"❌ **{sm('ERROR 404')}**: `{sm('FILE NOT FOUND OR DELETED')}`")
            
    except Exception as e:
        await eor(message, f"❌ **{sm('SYSTEM CRASH')}**: `{str(e)}`")

