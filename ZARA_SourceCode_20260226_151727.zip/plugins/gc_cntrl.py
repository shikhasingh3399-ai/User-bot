import os
from pyrogram import Client, filters
from pyrogram.types import Message

# ==========================================
# 🛠️ ZARA SYSTEM: GROUP ADMIN CORE
# ==========================================

# 1. SETGNAME - Group ka naam change karna
@Client.on_message(filters.command("setgname", prefixes=".") & filters.group & filters.me)
async def set_gname(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.edit_text("❌ ɴᴀʏᴀ ɴᴀᴀᴍ ᴛᴏ ʙᴀᴛᴀ ʙʜᴀɪ! ᴇxᴀᴍᴘʟᴇ: `.setgname ZARA EMPIRE`")
    
    new_name = message.text.split(None, 1)[1]
    try:
        await client.set_chat_title(message.chat.id, new_name)
        await message.edit_text(f"✅ ɢʀᴏᴜᴩ ɴᴀᴀᴍ ᴄʜᴀɴɢᴇ ʜᴏ ɢᴀʏᴀ:\n**{new_name}**")
    except Exception as e:
        await message.edit_text(f"⚠️ ᴇʀʀᴏʀ (ᴀᴅᴍɪɴ ʜᴀɪ ᴋʏᴀ ᴛᴜ?): `{e}`")

# 2. SETGBIO - Group ka Bio/Description change karna
@Client.on_message(filters.command("setgbio", prefixes=".") & filters.group & filters.me)
async def set_gbio(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.edit_text("❌ ɴᴀʏᴀ ʙɪᴏ ᴛᴏ ʙᴀᴛᴀ! ᴇxᴀᴍᴘʟᴇ: `.setgbio ZARA System is Online`")
    
    new_bio = message.text.split(None, 1)[1]
    try:
        await client.set_chat_description(message.chat.id, new_bio)
        await message.edit_text("✅ ɢʀᴏᴜᴩ ʙɪᴏ ᴜᴩᴅᴀᴛᴇᴅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ! 🔥")
    except Exception as e:
        await message.edit_text(f"⚠️ ᴇʀʀᴏʀ: `{e}`")

# 3. SETGPIC - Group ki DP set karna (Kisi photo pe reply karke)
@Client.on_message(filters.command("setgpic", prefixes=".") & filters.group & filters.me)
async def set_gpic(client: Client, message: Message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.edit_text("❌ ᴋɪꜱɪ ᴩʜᴏᴛᴏ ᴩᴇ ʀᴇᴩʟʏ ᴋᴀʀᴋᴇ `.setgpic` ʟɪᴋʜ!")
    
    msg = await message.edit_text("⚙️ ᴩʜᴏᴛᴏ ᴅᴏᴡɴʟᴏᴀᴅ ᴋᴀʀ ʀᴀʜᴀ ʜᴜɴ...")
    try:
        photo_path = await message.reply_to_message.download()
        await client.set_chat_photo(message.chat.id, photo=photo_path)
        await msg.edit_text("✅ ɢʀᴏᴜᴩ ᴅᴩ ᴄʜᴀɴɢᴇ ʜᴏ ɢᴀʏɪ ʙʜᴀɪ! 💀")
        os.remove(photo_path) # Storage clear karne ke liye
    except Exception as e:
        await msg.edit_text(f"⚠️ ᴇʀʀᴏʀ: `{e}`")

