import time
import asyncio
import sys
import unicodedata
from datetime import datetime
from pyrogram import Client, filters, __version__ as pyrover
from platform import python_version

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

# ==========================================
# ⏳ UPTIME ENGINE
# ==========================================
START_TIME = time.time()

def get_uptime():
    seconds = int(time.time() - START_TIME)
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h {minutes}m {seconds}s"

# ==========================================
# 📶 SIGMA PING COMMAND
# ==========================================
@Client.on_message(filters.command(["ping", "p"], prefixes=[".", "!", "/"]) & filters.me)
async def ping_cmd(client, message):
    # 1. Start Calculation
    start = datetime.now()
    msg = await message.edit(f"⚡ **{sm('checking server aukaat...')}**")
    
    # 2. Savage Animation
    await asyncio.sleep(0.3)
    await msg.edit(f"🖕 **{sm('gand faad pinging...')}**")
    
    end = datetime.now()
    # 🔥 FIXED LOGIC: total_seconds() gives the exact accurate ping
    ms = round((end - start).total_seconds() * 1000, 2)
    
    # 3. Final Toxic Result
    final_text = f"💀 **{sm('SYSTEM KI GAND FAAD DI!')}**\n`📶 {ms} ms` │ `🟢 {sm('BAAP LEVEL SPEED')}`"
    await msg.edit(final_text)

# ==========================================
# 💀 SAVAGE ALIVE COMMAND
# ==========================================
@Client.on_message(filters.command(["alive", "a"], prefixes=[".", "!", "/"]) & filters.me)
async def alive_cmd(client, message):
    # 1. Toxic Boot Animation
    msg = await message.edit(f"⚡ **{sm('WAKING UP THE DEMON...')}**")
    await asyncio.sleep(0.5)
    
    steps = [
        f"🖕 **{sm('KICKING CHHAPRIS OUT...')}**",
        f"☠️ **{sm('LOADING SIGMA PROTOCOLS...')}**",
        f"✅ **{sm('TERA BAAP ONLINE HAI')}**"
    ]
    for step in steps:
        await msg.edit(step)
        await asyncio.sleep(0.3)

    # 2. Data Fetch
    uptime = get_uptime()
    user_link = f"[{message.from_user.first_name}](tg://user?id={message.from_user.id})"
    pyver = python_version()
    
    # 3. Final Compact Layout (Sigma Vibe)
    text = f"╭── ☠️ **{sm('ZARA SIGMA KERNEL')}**\n"
    text += f"│\n"
    text += f"├── 👑 **{sm('SYSTEM KA BAAP')}:** {user_link}\n"
    text += f"├── ⏳ **{sm('JINDA KAB SE')}:** `{uptime}`\n"
    text += f"├── 🐍 **{sm('PYTHON AUKAAT')}:** `{pyver}`\n"
    text += f"├── 📡 **{sm('PYROGRAM')}:** `{pyrover}`\n"
    text += f"│\n"
    text += f"╰── 🟢 **{sm('BHAUKAL')}:** **{sm('GAND FAAD RUNNING')}** 🔥"
    
    # Check for Media
    if message.reply_to_message and message.reply_to_message.media:
        await message.delete()
        try:
            await message.reply_to_message.reply(text)
        except:
            await msg.edit(text)
    else:
        await msg.edit(text)

