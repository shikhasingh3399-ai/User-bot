import asyncio
import unicodedata
from pyrogram import Client, filters, enums
from pyrogram.types import Message
from pyrogram.errors import UserNotParticipant, PeerIdInvalid, ChannelInvalid, FloodWait

# 🛠️ CONFIG IMPORT
try:
    from config import OWNER_ID
except ImportError:
    OWNER_ID = 0

# ==========================================
# ⚙️ GLOBAL CONTROLLER
# ==========================================
SPAM_STATUS = {} 

# ==========================================
# 🎨 HACKER FONT ENGINE
# ==========================================
def sm(text):
    try:
        text = str(text)
        normalized = unicodedata.normalize('NFKC', text)
        mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
        return "".join(mapping.get(c.lower(), c) for c in normalized)
    except: return text

async def eor(message: Message, text: str):
    try:
        if message.from_user.is_self: return await message.edit(text)
        else: return await message.reply(text)
    except: return await message.reply(text)

# ==========================================
# 🔫 MACHINE GUN WORKER (ULTRA FAST - SUICIDE MODE)
# ==========================================
async def spam_worker(client_instance, chat_id, text, count, reply_to_id=None):
    i = 0
    while i < count:
        if not SPAM_STATUS.get(chat_id, False): 
            break
        
        try:
            if reply_to_id:
                await client_instance.send_message(chat_id, text, reply_to_message_id=reply_to_id)
            else:
                await client_instance.send_message(chat_id, text)
                
            i += 1
            # 🔥 SUICIDE SPEED: 0.05 Seconds! Phat ke haath me aayegi samne wale ki!
            await asyncio.sleep(0.05) 
            
        except FloodWait as e:
            # Agar Telegram ne speed pakad li aur ban mara, to ye chup-chap wait kar lega
            await asyncio.sleep(e.value + 1) 
        except Exception:
            await asyncio.sleep(0.5)

# ==========================================
# ☢️ COMMAND: SIGMA SPAM
# ==========================================
@Client.on_message(filters.command("spam", prefixes=[".", "!", "/"]) & filters.me)
async def start_spam(client, message: Message):
    if len(message.command) < 3 and not message.reply_to_message:
        return await eor(message, f"❌ **{sm('ABE LAUDE FORMAT DEKH')}**:\n`.spam 10 Hello` (Reply)\n`.spam @user 10 Hello` (New)")

    count = 0
    text = ""
    reply_id = None
    target_mention = ""

    # CASE A: REPLY TO MESSAGE
    if message.reply_to_message:
        try:
            count = int(message.command[1])
            text = " ".join(message.command[2:])
            reply_id = message.reply_to_message.id
        except:
            return await eor(message, f"❌ **{sm('GINTI TERA BAAP LIKHEGA?')}** `.spam 10 msg`")

    # CASE B: TARGET USER
    else:
        try:
            user_arg = message.command[1]
            target = None
            
            if user_arg.isdigit():
                try: target = await client.get_users(int(user_arg))
                except: pass
            else:
                try: target = await client.get_users(user_arg)
                except: pass

            if target:
                count = int(message.command[2])
                raw_msg = " ".join(message.command[3:])
                
                if target.username:
                    target_mention = f"@{target.username}"
                else:
                    target_mention = f"[{target.first_name}](tg://user?id={target.id})"
                
                text = f"{target_mention} {raw_msg}"
                reply_id = None 
            else:
                count = int(message.command[1])
                text = " ".join(message.command[2:])
                reply_id = None

        except Exception as e:
            return await eor(message, f"❌ **{sm('SYNTAX ERROR BE')}**: `{e}`")

    # --- 2. TOXIC DELHI VIBE ANIMATION ---
    SPAM_STATUS[message.chat.id] = True 
    
    anim = await eor(message, f"⚡ **{sm('SYSTEM HANG KARNE KI TAIYARI...')}**")
    await asyncio.sleep(0.2)
    await anim.edit(f"☠️ **{sm('TARGET LOCKED! AUKAAT DIKHATE HAIN...')}**")
    await asyncio.sleep(0.2)
    await anim.edit(f"🖕 **{sm('BHASAD MACHA DI! MAA CH*D DO SYSTEM KI!')}** 💥")
    await asyncio.sleep(0.2)
    await anim.delete() 

    # --- 3. ULTRA FAST MODE ---
    asyncio.create_task(spam_worker(client, message.chat.id, text, count, reply_id))


# ==========================================
# 🛑 COMMAND: STOP SPAM
# ==========================================
@Client.on_message(filters.command(["stopspam", ], prefixes=[".", "!", "/"]) & filters.me)
async def stop_spam(client, message: Message):
    if SPAM_STATUS.get(message.chat.id, False):
        SPAM_STATUS[message.chat.id] = False 
        await eor(message, f"🛑 **{sm('SPAM ROK DIYA BAAP NE!')}**")
    else:
        await eor(message, f"⚠️ **{sm('ABE KUCH CHAL HI NAHI RAHA LAUDE')}**")

