import os
import asyncio
import unicodedata
from pyrogram import Client, filters
from pyrogram.types import Message

# Required for Ultra-Clear Human-like Voice Generation
try:
    import edge_tts
except ImportError:
    edge_tts = None

# ==========================================
# 🎨 ZARA HACKER FONT ENGINE & REVERSE DECODER
# ==========================================
# The dictionary we use to make fonts fancy
FONT_MAPPING = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}

# The dictionary to force-decode fancy fonts back to normal
REVERSE_MAPPING = {v: k for k, v in FONT_MAPPING.items()}

def sm(text):
    if not text: return ""
    text = str(text)
    normalized = unicodedata.normalize('NFKC', text)
    return "".join(FONT_MAPPING.get(c.lower(), c) for c in normalized)

def clean_text_for_tts(text):
    if not text: return ""
    # 1. First, forcefully replace our specific hacker fonts
    cleaned_text = "".join(REVERSE_MAPPING.get(c, c) for c in text)
    # 2. Then run standard NFKC normalization for other weird symbols
    return unicodedata.normalize('NFKC', cleaned_text)

# ==========================================
# 🎙️ ZARA NEURAL TTS ENGINE (.speak)
# ==========================================
@Client.on_message(filters.command("speak", prefixes=".") & filters.me)
async def neural_tts(client: Client, message: Message):
    if not edge_tts:
        return await message.edit(sm("❌ error: edge-tts module is missing! run 'pip install edge-tts' in your terminal."))

    reply = message.reply_to_message
    raw_text = ""
    voice_gender = "girl" # Default Zara voice

    # Parse arguments for Gender and Text
    args = message.command[1:]
    
    # Check if user specified gender
    if args and args[0].lower() in ["boy", "male", "m"]:
        voice_gender = "boy"
        args = args[1:]
    elif args and args[0].lower() in ["girl", "female", "f"]:
        voice_gender = "girl"
        args = args[1:]
        
    # Get the text to speak
    if args:
        raw_text = " ".join(args)
    elif reply and reply.text:
        raw_text = reply.text
        
    if not raw_text:
        return await message.edit(sm("⚠️ usage:\n.speak <text>\n.speak boy <text>\nOr reply to a message with .speak"))

    # 🧹 Decode fancy fonts into normal readable text for the TTS engine
    text_to_speak = clean_text_for_tts(raw_text)

    anim = await message.edit(sm(f"🎙️ generating {voice_gender} neural voice... [▓▓▓░░]"))
    
    # Microsoft Neural Voices (Pure Conversational Hindi-English)
    voice_id = "hi-IN-MadhurNeural" if voice_gender == "boy" else "hi-IN-SwaraNeural"
    
    # 🎛️ ZARA'S CUSTOM VOICE TUNING (To make it sound younger and sweeter)
    voice_pitch = "+5Hz" if voice_gender == "boy" else "+15Hz"
    voice_rate = "+5%"
    
    file_path = f"zara_voice_{message.id}.ogg"

    try:
        # Generate the audio asynchronously with custom pitch and rate
        communicate = edge_tts.Communicate(
            text=text_to_speak, 
            voice=voice_id, 
            rate=voice_rate, 
            pitch=voice_pitch
        )
        await communicate.save(file_path)
        
        await anim.edit(sm("📤 uploading voice note... [▓▓▓▓▓]"))
        
        # Send as a voice note
        await client.send_voice(
            chat_id=message.chat.id,
            voice=file_path,
            reply_to_message_id=reply.id if reply else None
        )
        await anim.delete() # Clean up the terminal text

    except Exception as e:
        await anim.edit(sm(f"❌ tts engine crashed: {e}"))
        
    finally:
        # Always delete the audio file from local storage to save space
        if os.path.exists(file_path):
            os.remove(file_path)

