import asyncio
import unicodedata
from pyrogram import Client, filters, enums
from pyrogram.types import Message
from pyrogram.errors import FloodWait

# ==========================================
# 🎨 ZARA HACKER FONT ENGINE (iOS MEDIUM)
# ==========================================
def sm(text):
    if not text: return ""
    text = str(text)
    normalized = unicodedata.normalize('NFKC', text)
    mapping = {'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴩ', 'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'}
    return "".join(mapping.get(c.lower(), c) for c in normalized)

from config import OWNER_ID # Make sure OWNER_ID is imported

# ==========================================
# 🚀 SIGMA PARALLEL BROADCAST WORKER
# ==========================================
async def node_caster(node: Client, cast_type: str, msg_to_send):
    success = 0
    fail = 0
    
    async for dialog in node.get_dialogs():
        chat_type = dialog.chat.type
        
        # Filter Groups vs DMs
        if cast_type == "GROUP" and chat_type not in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
            continue
        if cast_type == "DM" and chat_type != enums.ChatType.PRIVATE:
            continue
            
        # Security: Don't let bots spam the Owner, Themselves, or Telegram official
        if cast_type == "DM" and dialog.chat.id in [OWNER_ID, node.me.id, 777000]:
            continue

        try:
            if isinstance(msg_to_send, str):
                await node.send_message(dialog.chat.id, msg_to_send)
            else:
                await msg_to_send.copy(dialog.chat.id) # Copies media perfectly without forward tag
                
            success += 1
            await asyncio.sleep(2.5) # 🛡️ SIGMA ANTI-BAN DELAY
            
        except FloodWait as e:
            # Smart Bypass: If Telegram asks to wait, the bot sleeps and retries safely
            await asyncio.sleep(e.value + 1)
            try:
                if isinstance(msg_to_send, str):
                    await node.send_message(dialog.chat.id, msg_to_send)
                else:
                    await msg_to_send.copy(dialog.chat.id)
                success += 1
                await asyncio.sleep(2.5)
            except:
                fail += 1
        except Exception:
            fail += 1
            
    return node, success, fail

# ==========================================
# 📡 ZARA GLOBAL CAST ENGINE (.gcast / .dmcast)
# ==========================================
@Client.on_message(filters.command(["gcast", "dmcast"], prefixes=".") & filters.me)
async def global_cast(client: Client, message: Message):
    command = message.command[0].lower()
    cast_type = "GROUP" if command == "gcast" else "DM"
    
    # 📝 1. Extract Payload (Text or Media)
    msg_to_send = None
    if message.reply_to_message:
        msg_to_send = message.reply_to_message
    elif len(message.command) > 1:
        msg_to_send = message.text.split(None, 1)[1]
        
    if not msg_to_send:
        return await message.edit(sm("❌ error: reply to a message or type some text to cast."))

    anim = await message.edit(sm(f"`[ ◐ ]` initiating {cast_type} network..."))

    # 🤖 2. Identify Target Nodes
    clients_to_cast = []
    
    if message.from_user.id == OWNER_ID:
        # Supreme Commander triggered it: Cast on ALL nodes (except Owner's ID)
        all_bots = []
        if hasattr(client, "userbots"):
            all_bots = client.userbots
        elif hasattr(client, "manager") and hasattr(client.manager, "userbots"):
            all_bots = client.manager.userbots
            
        for b in all_bots:
            if b.me and b.me.id != OWNER_ID:
                clients_to_cast.append(b)
                
        if not clients_to_cast:
            return await anim.edit(sm("⚠️ no active infected nodes found in the grid!"))
            
        await anim.edit(sm(f"`[ ◓ ]` commander verified. dispatching payload to {len(clients_to_cast)} nodes..."))
        
    else:
        # Normal Node triggered it for itself
        clients_to_cast = [client]
        await anim.edit(sm("`[ ◓ ]` local broadcast initiated..."))

    # 🚀 3. Execute Parallel Broadcast
    await anim.edit(sm("`[ ◑ ]` broadcasting payload... this may take a while. [anti-ban active]"))
    
    # Run all node casts simultaneously for maximum speed
    tasks = [node_caster(node, cast_type, msg_to_send) for node in clients_to_cast]
    results = await asyncio.gather(*tasks)

    # 📊 4. Generate Final Dossier (Report)
    total_success = 0
    total_fail = 0
    node_stats = ""

    for node, success, fail in results:
        total_success += success
        total_fail += fail
        node_name = node.me.first_name if getattr(node, "me", None) else "Ghost Node"
        node_stats += f"👤 **{node_name}**: ✅ `{success}` | ❌ `{fail}`\n"

    report = (
        f"📡 **{sm('broadcast complete')}** 📡\n"
        f"━━━━━━━━━━━━━━━\n"
        f"🛠️ **{sm('mode')}**: `{cast_type} CAST`\n"
        f"🤖 **{sm('nodes deployed')}**: `{len(clients_to_cast)}`\n"
        f"━━━━━━━━━━━━━━━\n"
        f"{node_stats}\n"
        f"📊 **{sm('total sent')}**: ✅ `{total_success}` | ❌ `{total_fail}`"
    )
    
    await anim.edit(report)

