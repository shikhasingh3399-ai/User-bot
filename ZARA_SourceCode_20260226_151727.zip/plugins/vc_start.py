from pyrogram import Client, filters
from pyrogram.enums import ChatMemberStatus
from pyrogram.raw.functions.phone import CreateGroupCall, DiscardGroupCall, EditGroupCallTitle
from pyrogram.raw.functions.channels import GetFullChannel
from pyrogram.types import Message
import random
import json

# 🚨 HACKER FIX: '& filters.me' add kar diya hai. Ab sirf wahi account chalega jisne command type ki hai!
@Client.on_message(filters.command("startvc", prefixes=".") & filters.group & filters.me)
async def start_vc(client: Client, message: Message):
    # 1. Stealth Mode: User ka command delete kar do
    try:
        await message.delete()
    except:
        pass

    # 2. Admin Check
    user = await client.get_chat_member(message.chat.id, message.from_user.id)
    
    if user.status not in [ChatMemberStatus.OWNER, ChatMemberStatus.ADMINISTRATOR]:
        # ⚠️ ADVANCE JSON FLEX FOR NON-ADMINS
        fake_data = {
            "𝗦𝘆𝘀𝘁𝗲𝗺_𝗘𝗿𝗿𝗼𝗿": "𝗔𝗖𝗖𝗘𝗦𝗦_𝗗𝗘𝗡𝗜𝗘𝗗",
            "𝗨𝘀𝗲𝗿_𝗜𝗗": message.from_user.id,
            "𝗔𝘁𝘁𝗲𝗺𝗽𝘁": "𝗦𝗧𝗔𝗥𝗧_𝗩𝗖",
            "𝗦𝘁𝗮𝘁𝘂𝘀": "𝗡𝗢𝗡_𝗔𝗗𝗠𝗜𝗡 (𝗔𝘂𝗸𝗮𝗮𝘁 𝗢𝘂𝘁 𝗼𝗳 𝗕𝗼𝘂𝗻𝗱𝘀)",
            "𝗙𝘂𝗹𝗹_𝗗𝘂𝗺𝗽": "Message_Data_Intercepted"
        }
        json_dump = json.dumps(fake_data, indent=4)
        await message.reply_text(
            f"❌ ᴀᴜᴋᴀᴀᴛ ᴇʀʀᴏʀ: ᴛᴜ ᴀᴅᴍɪɴ ɴᴀʜɪ ʜᴀɪ ᴄʜᴏᴛᴇ! ʏᴇ ʟᴇ ᴛᴇʀᴀ ᴅᴀᴛᴀ:\n\n`{json_dump}`\n\n`{str(message)[:2000]}`"
        )
        return

    # 3. Dynamic Processing Message
    processing_msg = await message.reply_text("⚙️ ɪɴɪᴛɪᴀᴛɪɴɢ ᴠᴄ ꜱᴇʀᴠᴇʀꜱ...")
    
    # 4. Advance Raw API Call (VC Start & Title Change)
    try:
        peer = await client.resolve_peer(message.chat.id)
        
        # VC Start karo
        await client.invoke(
            CreateGroupCall(
                peer=peer,
                random_id=random.randint(10000, 999999999)
            )
        )
        
        # VC ka Title Change karo (ADVANCE HACK)
        full_chat_data = await client.invoke(GetFullChannel(channel=peer))
        if full_chat_data.full_chat.call:
            await client.invoke(
                EditGroupCallTitle(
                    call=full_chat_data.full_chat.call,
                    title="🎙️ 𝗭𝗔𝗥𝗔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗩𝗖 🔥"
                )
            )

        # Message ko edit karke success dikhao
        await processing_msg.edit_text(
            "🎙️ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ ꜱᴛᴀʀᴛᴇᴅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ!\n\n"
            "‣ ᴛɪᴛʟᴇ: 𝗭𝗔𝗥𝗔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗩𝗖 🔥\n"
            "‣ ꜱᴛᴀᴛᴜꜱ: ᴏɴʟɪɴᴇ 🟢\n\n"
            "⚡ ᴀᴀᴊᴀᴏ ꜱᴀʙ ᴍɪᴄ ᴩᴇ!"
        )
    except Exception as e:
        if "GROUPCALL_ALREADY_STARTED" in str(e):
            await processing_msg.edit_text("🗣️ ᴠᴄ ᴩᴇʜʟᴇ ꜱᴇ ᴄʜᴀʟᴜ ʜᴀɪ ʙʜᴀɪ, ᴀᴀᴊᴀ ᴀɴᴅᴀʀ!")
        else:
            await processing_msg.edit_text(f"⚠️ ᴇʀʀᴏʀ: `{e}`")


# 🚨 Yahan bhi '& filters.me' laga diya hai!
@Client.on_message(filters.command("stopvc", prefixes=".") & filters.group & filters.me)
async def stop_vc(client: Client, message: Message):
    try:
        await message.delete()
    except:
        pass

    user = await client.get_chat_member(message.chat.id, message.from_user.id)
    
    if user.status not in [ChatMemberStatus.OWNER, ChatMemberStatus.ADMINISTRATOR]:
        await message.reply_text("❌ ʙᴀᴅᴀ ᴀᴀʏᴀ ᴠᴄ ʙᴀɴᴅ ᴋᴀʀɴᴇ ᴡᴀʟᴀ, ᴀᴅᴍɪɴ ᴋᴏ ʙᴜʟᴀ ᴩᴇʜʟᴇ!")
        return

    processing_msg = await message.reply_text("⚙️ ᴅɪꜱᴄᴏɴɴᴇᴄᴛɪɴɢ ᴠᴄ ꜱᴇʀᴠᴇʀꜱ...")

    try:
        peer = await client.resolve_peer(message.chat.id)
        full_chat_data = await client.invoke(GetFullChannel(channel=peer))
        
        if not full_chat_data.full_chat.call:
            return await processing_msg.edit_text("❌ ᴋᴏɪ ᴠᴄ ᴄʜᴀʟ ʜɪ ɴᴀʜɪ ʀᴀʜɪ ʜᴀɪ ʙʜᴀɪ!")
            
        await client.invoke(DiscardGroupCall(call=full_chat_data.full_chat.call))
        
        await processing_msg.edit_text(
            "🔇 ᴠᴏɪᴄᴇ ᴄʜᴀᴛ ᴇɴᴅᴇᴅ!\n\n"
            "‣ ꜱᴛᴀᴛᴜꜱ: ᴏꜰꜰʟɪɴᴇ 🔴\n\n"
            "⚡ ᴋʜᴇʟ ᴋʜᴀᴛᴀᴍ, ꜱᴀʙ ᴀᴩɴᴇ ɢʜᴀʀ ᴊᴀᴏ."
        )
    except Exception as e:
        await processing_msg.edit_text(f"⚠️ ᴇʀʀᴏʀ: `{e}`")

