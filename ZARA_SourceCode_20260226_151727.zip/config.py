import os
import time
from motor.motor_asyncio import AsyncIOMotorClient
from pyrogram import filters

# ==========================================
# 💀 ZARA SYSTEM: KERNEL CONFIGURATION [V15.0 - GOD MODE]
# ==========================================
START_TIME = time.time()

# ------------------------------------------
# ⚡ SECTOR 1: IDENTITY & CREDENTIALS
# ------------------------------------------
API_ID = 22002688
API_HASH = "0c3bee507e2ea7621b903b12ef11fba9"
BOT_TOKEN = "8273113571:AAEX5faESB67TR-EkZudZKNt5qMJXn4xAkc"
OWNER_ID = 8036881129

# ------------------------------------------
# 👑 SECTOR 2: SYSTEM ADMINS
# ------------------------------------------
DEFAULT_SUDO = [OWNER_ID, 6867864688]

# 🔥 GLOBAL MEMORY RADAR (ActiveBot Plugin Ke Liye)
ZARA_CLIENTS = [] 

# ------------------------------------------
# 🧠 SECTOR 3: NEURAL NETWORK (MONGO DB)
# ------------------------------------------
# [FIXED] MongoDB URI ko poora band kiya
MONGO_URI = "mongodb+srv://Billa:ZARA838180@billa.0srztoh.mongodb.net"
DB_NAME = "ZARA_HACK_BOT"

# ------------------------------------------
# 📡 SECTOR 4: CUSTOM TERMINAL ENGINE
# ------------------------------------------
class ZaraConsole:
    def info(self, text):
        print(f"\033[1;36m[ZARA-SYS]\033[0m \033[1;32m[INFO]\033[0m {text}")
    def error(self, text):
        print(f"\033[1;36m[ZARA-SYS]\033[0m \033[1;31m[ERROR]\033[0m {text}")
    def warning(self, text):
        print(f"\033[1;36m[ZARA-SYS]\033[0m \033[1;33m[WARN]\033[0m {text}")

LOGS = ZaraConsole()

# ------------------------------------------
# 🚀 SECTOR 5: PERFORMANCE TUNING
# ------------------------------------------
WATCHDOG_INTERVAL = 180
MAX_FLOOD_WAIT = 300
TEMP_DOWNLOAD_DIRECTORY = "./zara_cache/"
if not os.path.exists(TEMP_DOWNLOAD_DIRECTORY):
    os.makedirs(TEMP_DOWNLOAD_DIRECTORY)

# ------------------------------------------
# 🎨 THE SPEED HACK: ULTRA-FAST FONT ENGINE
# ------------------------------------------
# [FIXED] Pura dictionary wapas banaya jo cut gaya tha
HACKER_DICT = {
    'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ',
    'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴘ',
    'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x',
    'y': 'ʏ', 'z': 'ᴢ', '0': '𝟶', '1': '𝟷', '2': '𝟸', '3': '𝟹', '4': '𝟺', '5': '𝟻',
    '6': '𝟼', '7': '𝟽', '8': '𝟾', '9': '𝟿'
}
TRANSLATOR = str.maketrans(HACKER_DICT)

def hacker_font(text: str) -> str:
    return str(text).lower().translate(TRANSLATOR)

# ------------------------------------------
# 🛡️ DYNAMIC SUDO LOGIC (RAM CACHE)
# ------------------------------------------
SUDO_CACHE = set(DEFAULT_SUDO)

# [FIXED] Indentation aur dot error hata diya
try:
    db_client = AsyncIOMotorClient(MONGO_URI)
    db = db_client[DB_NAME]
    sudo_collection = db["auth_users"]
    LOGS.info(hacker_font("DATABASE SECURED & CONNECTED!"))
except Exception as e:
    db = None
    sudo_collection = None
    LOGS.error(f"DB ERROR: {e}")

async def refresh_sudo_cache():
    global SUDO_CACHE
    if sudo_collection is None: return
    try:
        SUDO_CACHE = set(DEFAULT_SUDO)
        async for user in sudo_collection.find({}):
            SUDO_CACHE.add(user["user_id"])
        LOGS.info(hacker_font(f"CACHE UPDATED: {len(SUDO_CACHE)} ELITE USERS"))
    except Exception as e:
        LOGS.error(f"Cache Refresh Error: {e}")

async def add_sudo_db(user_id: int):
    if user_id not in SUDO_CACHE and sudo_collection is not None:
        await sudo_collection.insert_one({"user_id": user_id})
        SUDO_CACHE.add(user_id)
        return True
    return False

# [FIXED] Cut line poori kar di
async def del_sudo_db(user_id: int):
    if user_id in SUDO_CACHE and user_id != OWNER_ID and sudo_collection is not None:
        await sudo_collection.delete_one({"user_id": user_id})
        SUDO_CACHE.discard(user_id)
        return True
    return False

def is_sudo(user_id: int) -> bool:
    return user_id in SUDO_CACHE or user_id == OWNER_ID

# ------------------------------------------
# ⚡ THE ZARA SUDO FILTER
# ------------------------------------------
async def sudo_check(_, client, message):
    if not message.from_user: return False
    return is_sudo(message.from_user.id)

zara_sudo = filters.create(sudo_check)

